-- AlphaLens AI Database Schema
-- Institutional-grade trading agent with AI reasoning and risk controls

CREATE DATABASE IF NOT EXISTS alphalens_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE alphalens_db;

-- =====================================================
-- EARNINGS & NEWS DATA
-- =====================================================

-- Store earnings transcripts
CREATE TABLE IF NOT EXISTS earnings_transcripts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticker VARCHAR(10) NOT NULL,
    company_name VARCHAR(255),
    quarter VARCHAR(10),
    fiscal_year INT,
    earnings_date DATETIME NOT NULL,
    transcript_text LONGTEXT,
    guidance_text TEXT,
    raw_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ticker (ticker),
    INDEX idx_earnings_date (earnings_date)
) ENGINE=InnoDB;

-- Store financial news articles
CREATE TABLE IF NOT EXISTS news_articles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticker VARCHAR(10),
    headline VARCHAR(500) NOT NULL,
    summary TEXT,
    full_text LONGTEXT,
    source VARCHAR(100),
    published_at DATETIME NOT NULL,
    url VARCHAR(500),
    raw_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ticker (ticker),
    INDEX idx_published_at (published_at)
) ENGINE=InnoDB;

-- =====================================================
-- AI ANALYSIS & SENTIMENT
-- =====================================================

-- Store AI sentiment analysis results
CREATE TABLE IF NOT EXISTS ai_sentiment_analysis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_type ENUM('earnings', 'news') NOT NULL,
    source_id INT NOT NULL,
    ticker VARCHAR(10) NOT NULL,
    sentiment ENUM('bullish', 'neutral', 'bearish') NOT NULL,
    sentiment_score DECIMAL(5,2), -- -100 to +100
    confidence_level DECIMAL(5,2), -- 0 to 100
    key_insights JSON, -- Array of extracted insights
    key_quotes JSON, -- Array of management quotes
    forward_looking_statements JSON, -- Array of future guidance
    trade_thesis TEXT, -- Human-readable explanation
    tone_shift VARCHAR(50), -- e.g., "positive", "cautious", "defensive"
    narrative_risk TEXT,
    prompt_version_id INT,
    gemini_response JSON, -- Full AI response for audit
    analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ticker (ticker),
    INDEX idx_source (source_type, source_id),
    INDEX idx_analyzed_at (analyzed_at)
) ENGINE=InnoDB;

-- =====================================================
-- TRADING SIGNALS & EXECUTION
-- =====================================================

-- Store generated trade signals
CREATE TABLE IF NOT EXISTS trade_signals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticker VARCHAR(10) NOT NULL,
    signal_type ENUM('buy', 'sell', 'hold') NOT NULL,
    sentiment_analysis_id INT,
    ai_confidence DECIMAL(5,2),
    trade_thesis TEXT,
    rule_validation_status ENUM('pending', 'passed', 'failed') DEFAULT 'pending',
    risk_check_results JSON,
    rule_validation_notes TEXT,
    risk_validation_status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    risk_validation_notes TEXT,
    final_status ENUM('pending', 'approved', 'rejected', 'executed', 'cancelled', 'scheduled') DEFAULT 'pending',
    scheduled_at DATETIME DEFAULT NULL,
    suggested_position_size DECIMAL(15,2),
    suggested_entry_price DECIMAL(15,4),
    suggested_stop_loss DECIMAL(15,4),
    suggested_take_profit DECIMAL(15,4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP NULL,
    executed_at TIMESTAMP NULL,
    FOREIGN KEY (sentiment_analysis_id) REFERENCES ai_sentiment_analysis(id),
    INDEX idx_ticker (ticker),
    INDEX idx_status (final_status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Store executed trades
CREATE TABLE IF NOT EXISTS trade_executions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    signal_id INT NOT NULL,
    ticker VARCHAR(10) NOT NULL,
    side ENUM('buy', 'sell') NOT NULL,
    quantity DECIMAL(15,4) NOT NULL,
    entry_price DECIMAL(15,4) NOT NULL,
    stop_loss DECIMAL(15,4),
    take_profit DECIMAL(15,4),
    alpaca_order_id VARCHAR(100),
    alpaca_response JSON,
    execution_status VARCHAR(50) DEFAULT 'pending',
    filled_qty DECIMAL(15,4) DEFAULT 0,
    filled_avg_price DECIMAL(15,4),
    commission DECIMAL(10,2) DEFAULT 0,
    executed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP NULL,
    pnl DECIMAL(15,2),
    FOREIGN KEY (signal_id) REFERENCES trade_signals(id),
    INDEX idx_ticker (ticker),
    INDEX idx_status (execution_status),
    INDEX idx_executed_at (executed_at)
) ENGINE=InnoDB;

-- Store current and historical positions
CREATE TABLE IF NOT EXISTS positions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticker VARCHAR(10) NOT NULL UNIQUE,
    sector VARCHAR(50) DEFAULT 'Unknown',
    quantity DECIMAL(15,4) NOT NULL,
    avg_entry_price DECIMAL(15,4) NOT NULL,
    current_price DECIMAL(15,4),
    market_value DECIMAL(15,2),
    cost_basis DECIMAL(15,2),
    unrealized_pnl DECIMAL(15,2),
    unrealized_pnl_pct DECIMAL(5,2),
    stop_loss DECIMAL(15,4),
    take_profit DECIMAL(15,4),
    opened_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_ticker (ticker)
) ENGINE=InnoDB;

-- Store performance metrics for analytics
CREATE TABLE IF NOT EXISTS performance_metrics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    date DATE UNIQUE NOT NULL,
    equity DECIMAL(15,2),
    daily_return DECIMAL(10,4),
    cumulative_return DECIMAL(10,4),
    drawdown_pct DECIMAL(10,4),
    trades_count INT DEFAULT 0,
    wins_count INT DEFAULT 0,
    losses_count INT DEFAULT 0,
    total_pnl DECIMAL(15,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_date (date)
) ENGINE=InnoDB;

-- =====================================================
-- RISK MANAGEMENT
-- =====================================================

-- Store risk metrics and limits
CREATE TABLE IF NOT EXISTS risk_metrics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    metric_date DATE NOT NULL UNIQUE,
    total_portfolio_value DECIMAL(15,2),
    total_exposure DECIMAL(15,2),
    exposure_pct DECIMAL(5,2),
    cash_balance DECIMAL(15,2),
    daily_pnl DECIMAL(15,2),
    daily_pnl_pct DECIMAL(5,2),
    cumulative_pnl DECIMAL(15,2),
    cumulative_pnl_pct DECIMAL(5,2),
    max_drawdown_pct DECIMAL(5,2),
    current_drawdown_pct DECIMAL(5,2),
    peak_equity DECIMAL(15,2),
    volatility_30d DECIMAL(5,2),
    sharpe_ratio DECIMAL(5,2),
    win_rate DECIMAL(5,2),
    total_trades INT DEFAULT 0,
    winning_trades INT DEFAULT 0,
    losing_trades INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_metric_date (metric_date)
) ENGINE=InnoDB;

-- Store risk rule configurations
CREATE TABLE IF NOT EXISTS risk_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL UNIQUE,
    rule_type ENUM('position_size', 'exposure', 'drawdown', 'volatility', 'timing', 'other') NOT NULL,
    rule_value DECIMAL(10,2) NOT NULL,
    rule_unit VARCHAR(20), -- e.g., 'percent', 'dollars', 'hours'
    is_active BOOLEAN DEFAULT TRUE,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert default risk rules
INSERT INTO risk_rules (rule_name, rule_type, rule_value, rule_unit, description) VALUES
('max_position_size_pct', 'position_size', 5.00, 'percent', 'Maximum position size as % of portfolio'),
('max_portfolio_exposure_pct', 'exposure', 30.00, 'percent', 'Maximum total portfolio exposure'),
('max_daily_drawdown_pct', 'drawdown', 2.00, 'percent', 'Maximum daily drawdown limit'),
('max_cumulative_drawdown_pct', 'drawdown', 10.00, 'percent', 'Maximum cumulative drawdown limit'),
('volatility_multiplier', 'volatility', 1.50, 'multiplier', 'Position size adjustment based on volatility'),
('cooldown_hours_after_loss', 'timing', 24.00, 'hours', 'Cooldown period after losing trade'),
('min_liquidity_volume', 'other', 1000000.00, 'shares', 'Minimum average daily volume required')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- =====================================================
-- AUDIT & LOGGING
-- =====================================================

-- Store complete decision audit trail
CREATE TABLE IF NOT EXISTS decision_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticker VARCHAR(10),
    decision_type ENUM('ai_analysis', 'rule_validation', 'risk_check', 'trade_execution', 'manual_override') NOT NULL,
    decision_outcome ENUM('approved', 'rejected', 'pending', 'error') NOT NULL,
    decision_reason TEXT,
    decision_data JSON, -- Full context and parameters
    related_signal_id INT,
    related_execution_id INT,
    created_by VARCHAR(50) DEFAULT 'system',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_ticker (ticker),
    INDEX idx_decision_type (decision_type),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB;

-- Store AI prompt versions for reproducibility
CREATE TABLE IF NOT EXISTS prompt_versions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    prompt_name VARCHAR(100) NOT NULL,
    prompt_version VARCHAR(20) NOT NULL,
    prompt_template LONGTEXT NOT NULL,
    prompt_parameters JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_prompt_version (prompt_name, prompt_version),
    INDEX idx_active (is_active)
) ENGINE=InnoDB;

-- Insert default prompt template
INSERT INTO prompt_versions (prompt_name, prompt_version, prompt_template, is_active) VALUES
('earnings_sentiment_analysis', 'v1.0', 
'Analyze the following earnings transcript and provide a structured sentiment analysis.

COMPANY: {company_name}
TICKER: {ticker}
QUARTER: {quarter}
EARNINGS DATE: {earnings_date}

TRANSCRIPT:
{transcript_text}

GUIDANCE:
{guidance_text}

Please provide:
1. Overall sentiment (bullish/neutral/bearish)
2. Sentiment score (-100 to +100)
3. Confidence level (0-100)
4. Key insights (3-5 bullet points)
5. Trade thesis (2-3 sentences explaining potential trade opportunity)
6. Tone shift analysis (positive/neutral/negative/defensive)
7. Narrative risks (potential concerns or red flags)
8. Key quotes (2-3 direct impactful quotes from management/analysts)
9. Forward-looking statements (Specific guidance or predictive claims)

Format your response as JSON with these exact keys: sentiment, sentiment_score, confidence_level, key_insights, trade_thesis, tone_shift, narrative_risk, key_quotes, forward_looking_statements', 
TRUE)
ON DUPLICATE KEY UPDATE is_active = TRUE;

-- =====================================================
-- SYSTEM CONFIGURATION
-- =====================================================

-- Store system configuration and settings
CREATE TABLE IF NOT EXISTS system_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    config_key VARCHAR(100) NOT NULL UNIQUE,
    config_value TEXT,
    config_type ENUM('string', 'number', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Insert default system configuration
INSERT INTO system_config (config_key, config_value, config_type, description) VALUES
('trading_mode', 'semi_automated', 'string', 'Trading mode: semi_automated or fully_automated'),
('paper_trading', 'true', 'boolean', 'Whether to use paper trading (true) or live trading (false)'),
('max_concurrent_positions', '5', 'number', 'Maximum number of concurrent open positions'),
('default_portfolio_value', '100000', 'number', 'Default portfolio value for paper trading'),
('ai_analysis_enabled', 'true', 'boolean', 'Enable AI sentiment analysis'),
('risk_controls_enabled', 'true', 'boolean', 'Enable risk control framework'),
('system_halted', 'false', 'boolean', 'Global trading halt flag (Circuit Breaker)')
ON DUPLICATE KEY UPDATE updated_at = CURRENT_TIMESTAMP;

-- =====================================================
-- VIEWS FOR EASY QUERYING
-- =====================================================

-- View for active signals with full context
CREATE OR REPLACE VIEW v_active_signals AS
SELECT 
    ts.id,
    ts.ticker,
    ts.signal_type,
    ts.ai_confidence,
    ts.trade_thesis,
    ts.rule_validation_status,
    ts.risk_validation_status,
    ts.final_status,
    ts.suggested_position_size,
    ts.suggested_entry_price,
    ais.sentiment,
    ais.sentiment_score,
    ais.confidence_level,
    ais.key_insights,
    ts.created_at
FROM trade_signals ts
LEFT JOIN ai_sentiment_analysis ais ON ts.sentiment_analysis_id = ais.id
WHERE ts.final_status IN ('pending', 'approved')
ORDER BY ts.created_at DESC;

-- View for portfolio summary
CREATE OR REPLACE VIEW v_portfolio_summary AS
SELECT 
    COUNT(*) as total_positions,
    SUM(market_value) as total_market_value,
    SUM(cost_basis) as total_cost_basis,
    SUM(unrealized_pnl) as total_unrealized_pnl,
    AVG(unrealized_pnl_pct) as avg_unrealized_pnl_pct
FROM positions
WHERE quantity > 0;

-- =====================================================
-- INDEXES FOR PERFORMANCE
-- =====================================================

-- Additional composite indexes for common queries
CREATE INDEX idx_signals_ticker_status ON trade_signals(ticker, final_status);
CREATE INDEX idx_executions_ticker_status ON trade_executions(ticker, execution_status);
CREATE INDEX idx_sentiment_ticker_date ON ai_sentiment_analysis(ticker, analyzed_at);

-- =====================================================
-- COMPLETION MESSAGE
-- =====================================================

SELECT 'AlphaLens AI database schema created successfully!' AS status;
SHOW TABLES;
