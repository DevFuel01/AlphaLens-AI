<?php

/**
 * Migration: Add Sector Concentration Rule
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "--- Migration: Add Sector Concentration Rule ---\n";

    // 1. Check if rule already exists
    $stmt = $db->prepare("SELECT COUNT(*) FROM risk_rules WHERE rule_name = ?");
    $stmt->execute(['max_sector_concentration_pct']);
    $exists = $stmt->fetchColumn();

    if (!$exists) {
        $stmt = $db->prepare("
            INSERT INTO risk_rules (rule_name, description, rule_value, rule_unit, is_active)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            'max_sector_concentration_pct',
            'Maximum allowed exposure to any single sector (ETF, Technology, etc.) as % of total portfolio',
            25.0,
            'percent',
            1
        ]);
        echo "Successfully added 'max_sector_concentration_pct' rule (25%)\n";
    } else {
        echo "Rule 'max_sector_concentration_pct' already exists.\n";
    }

    echo "Migration complete.\n";
} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
