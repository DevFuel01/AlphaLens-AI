<?php

/**
 * Migration: Add Analyst Estimates Column
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "Adding analyst_estimates column...\n";

    try {
        $db->exec("ALTER TABLE ai_sentiment_analysis ADD COLUMN analyst_estimates JSON DEFAULT NULL AFTER market_keywords");
        echo "Added 'analyst_estimates' column.\n";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            echo "'analyst_estimates' column already exists.\n";
        } else {
            throw $e;
        }
    }

    echo "Migration completed successfully.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
