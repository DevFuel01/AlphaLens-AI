<?php
require_once __DIR__ . '/../../config/database.php';
$db = Database::getInstance()->getConnection();

$newPrompt = "Analyze the following earnings data and transcript for {company_name} ({ticker}).

QUARTER: {quarter}
EARNINGS DATE: {earnings_date}

TRANSCRIPT/SUMMARY:
{transcript_text}

GUIDANCE:
{guidance_text}

Please provide:
1. Overall sentiment (bullish/neutral/bearish)
2. Sentiment score (-100 to +100)
3. Confidence level (0-100)
4. Key insights (3-5 bullet points)
5. Trade thesis (2-3 sentences)
6. Tone shift (identifying management confidence, caution, or uncertainty)
7. Narrative risks (potential headwinds mentioned)
8. Key quotes (2-3 direct impactful quotes from management)

Format as JSON with keys: sentiment, sentiment_score, confidence_level, key_insights, trade_thesis, tone_shift, narrative_risk, key_quotes";

$stmt = $db->prepare("UPDATE prompt_versions SET prompt_template = ? WHERE prompt_name = 'earnings_sentiment_analysis' AND is_active = TRUE");
$stmt->execute([$newPrompt]);

echo "Prompt template updated successfully.\n";
