ALTER TABLE positions ADD COLUMN sector VARCHAR(50) DEFAULT 'Unknown' AFTER ticker;
