<?php

/**
 * Migration: Update trading_mode description in system_config
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "--- Migration: Update Trading Mode Descriptions ---\n";

    $stmt = $db->prepare("
        UPDATE system_config 
        SET description = 'Trading mode: fully_automated, semi_automated, or advisory' 
        WHERE config_key = 'trading_mode'
    ");
    $stmt->execute();

    echo "Description updated.\n";
    echo "Migration complete.\n";
} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
