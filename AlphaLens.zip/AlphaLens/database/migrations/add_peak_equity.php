<?php

/**
 * Migration: Add peak_equity to risk_metrics
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "--- Migration: Add peak_equity to risk_metrics ---\n";

    // Check if column exists
    $stmt = $db->query("SHOW COLUMNS FROM risk_metrics LIKE 'peak_equity'");
    $exists = $stmt->fetch();

    if (!$exists) {
        $db->exec("ALTER TABLE risk_metrics ADD COLUMN peak_equity DECIMAL(15,2) AFTER current_drawdown_pct");
        echo "Successfully added 'peak_equity' column to risk_metrics\n";
    } else {
        echo "Column 'peak_equity' already exists.\n";
    }

    echo "Migration complete.\n";
} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
