<?php

/**
 * Migration: Add key_quotes to ai_sentiment_analysis table
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "Starting migration: Adding key_quotes column...\n";

    $db->exec("ALTER TABLE ai_sentiment_analysis ADD COLUMN key_quotes JSON AFTER key_insights");

    echo "Migration successful!\n";
} catch (Exception $e) {
    if (strpos($e->getMessage(), 'Duplicate column name') !== false) {
        echo "Column key_quotes already exists. Skipping.\n";
    } else {
        echo "Migration failed: " . $e->getMessage() . "\n";
    }
}
