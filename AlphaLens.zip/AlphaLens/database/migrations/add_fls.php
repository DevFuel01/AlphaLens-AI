<?php

/**
 * Migration: Add forward_looking_statements to ai_sentiment_analysis
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    // Check if column exists
    $check = $db->query("SHOW COLUMNS FROM ai_sentiment_analysis LIKE 'forward_looking_statements'");
    if ($check->rowCount() == 0) {
        $db->exec("ALTER TABLE ai_sentiment_analysis ADD COLUMN forward_looking_statements JSON AFTER key_quotes");
        echo "Successfully added 'forward_looking_statements' column to 'ai_sentiment_analysis'.\n";
    } else {
        echo "Column 'forward_looking_statements' already exists.\n";
    }
} catch (Exception $e) {
    echo "Migration Error: " . $e->getMessage() . "\n";
    exit(1);
}
