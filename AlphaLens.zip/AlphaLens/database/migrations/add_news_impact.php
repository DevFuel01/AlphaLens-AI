<?php

/**
 * Migration: Add News Impact Score and Keywords
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "Adding news intelligence columns...\n";

    // Add impact_score column
    try {
        $db->exec("ALTER TABLE ai_sentiment_analysis ADD COLUMN impact_score INT DEFAULT NULL AFTER confidence_level");
        echo "Added 'impact_score' column.\n";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            echo "'impact_score' column already exists.\n";
        } else {
            throw $e;
        }
    }

    // Add market_keywords column
    try {
        $db->exec("ALTER TABLE ai_sentiment_analysis ADD COLUMN market_keywords JSON DEFAULT NULL AFTER key_insights");
        echo "Added 'market_keywords' column.\n";
    } catch (PDOException $e) {
        if (strpos($e->getMessage(), 'Duplicate column') !== false) {
            echo "'market_keywords' column already exists.\n";
        } else {
            throw $e;
        }
    }

    echo "Migration completed successfully.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
    exit(1);
}
