<?php
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "Adding risk_check_results column to trade_signals...\n";

    $sql = "ALTER TABLE trade_signals ADD COLUMN risk_check_results JSON AFTER rule_validation_status";
    $db->exec($sql);

    echo "✓ Migration successful!\n";
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'Duplicate column') !== false) {
        echo "✓ Column already exists!\n";
    } else {
        echo "✗ ERROR: " . $e->getMessage() . "\n";
    }
}
