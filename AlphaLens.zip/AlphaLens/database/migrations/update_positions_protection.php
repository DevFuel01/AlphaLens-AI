<?php

/**
 * Migration: Add SL/TP to positions table
 */
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    // Check if columns exist
    $stmt = $db->query("SHOW COLUMNS FROM positions LIKE 'stop_loss'");
    if (!$stmt->fetch()) {
        $db->exec("ALTER TABLE positions ADD COLUMN stop_loss DECIMAL(10, 2) DEFAULT NULL");
        echo "Added stop_loss to positions table.\n";
    }

    $stmt = $db->query("SHOW COLUMNS FROM positions LIKE 'take_profit'");
    if (!$stmt->fetch()) {
        $db->exec("ALTER TABLE positions ADD COLUMN take_profit DECIMAL(10, 2) DEFAULT NULL");
        echo "Added take_profit to positions table.\n";
    }

    // Also add opened_at if missing (ExpiryManager uses it)
    $stmt = $db->query("SHOW COLUMNS FROM positions LIKE 'opened_at'");
    if (!$stmt->fetch()) {
        $db->exec("ALTER TABLE positions ADD COLUMN opened_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
        echo "Added opened_at to positions table.\n";
    }
} catch (Exception $e) {
    echo "Migration Error: " . $e->getMessage() . "\n";
}
