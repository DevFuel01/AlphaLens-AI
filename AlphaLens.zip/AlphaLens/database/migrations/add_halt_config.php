<?php

/**
 * Migration: Add System Halt Config
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "--- Migration: Add System Halt Config ---\n";

    // 1. Check if rule already exists
    $stmt = $db->prepare("SELECT COUNT(*) FROM system_config WHERE config_key = ?");
    $stmt->execute(['system_halted']);
    $exists = $stmt->fetchColumn();

    if (!$exists) {
        $stmt = $db->prepare("
            INSERT INTO system_config (config_key, config_value, config_type, description)
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([
            'system_halted',
            'false',
            'boolean',
            'Global trading halt flag (Circuit Breaker)'
        ]);
        echo "Successfully added 'system_halted' config (false)\n";
    } else {
        echo "Config 'system_halted' already exists.\n";
    }

    echo "Migration complete.\n";
} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
