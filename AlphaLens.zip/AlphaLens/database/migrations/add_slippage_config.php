<?php
/**
 * Migration: Add Slippage Configuration
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();
    
    $stmt = $db->prepare("INSERT IGNORE INTO system_config (config_key, config_value, config_type, description) VALUES (?, ?, ?, ?)");
    
    $stmt->execute([
        'max_slippage_pct',
        '1.0',
        'number',
        'Maximum allowed deviation from suggested entry price (%)'
    ]);
    
    echo "SUCCESS: max_slippage_pct added to system_config\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
