ALTER TABLE trade_signals ADD COLUMN risk_check_results JSON AFTER rule_validation_status;
