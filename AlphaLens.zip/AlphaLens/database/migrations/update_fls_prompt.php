<?php

/**
 * Update earnings analysis prompt to include forward-looking statements
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    $promptName = 'earnings_sentiment_analysis';

    $template = "Analyze the following earnings transcript for {ticker} ({quarter} {fiscal_year}).
Reported Date: {earnings_date}

TRANSCRIPT:
{transcript_text}

GUIDANCE:
{guidance_text}

Please provide a detailed sentiment analysis including:
1. Overall sentiment (bullish/neutral/bearish)
2. Sentiment score (-100 to +100)
3. Confidence level (0-100)
4. Key insights (3-5 bullet points)
5. Trade thesis (2-3 sentences justifying a trade decision)
6. Tone shift (positive/neutral/negative)
7. Narrative risks (key risks mentioned by management)
8. Key quotes (2-3 direct impactful quotes from management/analysts)
9. Forward-looking statements (Specific guidance or predictive claims)

Format the output as a clean JSON object with the following keys:
sentiment, sentiment_score, confidence_level, key_insights, trade_thesis, tone_shift, narrative_risk, key_quotes, forward_looking_statements";

    $stmt = $db->prepare("
        UPDATE prompt_versions 
        SET prompt_template = ? 
        WHERE prompt_name = ? AND is_active = TRUE
    ");

    $stmt->execute([$template, $promptName]);

    echo "Successfully updated earnings prompt template.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
