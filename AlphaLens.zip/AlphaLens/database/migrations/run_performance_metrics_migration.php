<?php
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "Creating performance_metrics table...\n";

    $sql = file_get_contents(__DIR__ . '/create_performance_metrics.sql');
    $db->exec($sql);

    echo "✓ Table created successfully!\n";
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'already exists') !== false) {
        echo "✓ Table already exists!\n";
    } else {
        echo "✗ ERROR: " . $e->getMessage() . "\n";
    }
}
