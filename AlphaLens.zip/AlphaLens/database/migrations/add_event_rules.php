<?php

/**
 * Migration: Add Volatility and Earnings filters to risk_rules
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "--- Migration: Add Event & Volatility Rules ---\n";

    $rules = [
        [
            'name' => 'volatility_spike_threshold',
            'type' => 'volatility',
            'value' => 2.00,
            'unit' => 'multiplier',
            'description' => 'Veto trade if current volatility exceeds X times historical average'
        ],
        [
            'name' => 'pre_earnings_buffer_days',
            'type' => 'timing',
            'value' => 3.00,
            'unit' => 'days',
            'description' => 'No trading X days before an earnings report'
        ],
        [
            'name' => 'post_earnings_wait_days',
            'type' => 'timing',
            'value' => 1.00,
            'unit' => 'days',
            'description' => 'Wait X days after earnings before trading news related to that ticker'
        ]
    ];

    $stmt = $db->prepare("
        INSERT INTO risk_rules (rule_name, rule_type, rule_value, rule_unit, description) 
        VALUES (?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE rule_value = VALUES(rule_value), description = VALUES(description)
    ");

    foreach ($rules as $rule) {
        $stmt->execute([
            $rule['name'],
            $rule['type'],
            $rule['value'],
            $rule['unit'],
            $rule['description']
        ]);
        echo "Rule '{$rule['name']}' synchronized.\n";
    }

    echo "Migration complete.\n";
} catch (Exception $e) {
    echo "Migration failed: " . $e->getMessage() . "\n";
    exit(1);
}
