<?php

/**
 * Migration: Expand execution_status field
 */

require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    // Change ENUM to VARCHAR for flexibility with Alpaca statuses
    $db->exec("ALTER TABLE trade_executions MODIFY COLUMN execution_status VARCHAR(50) DEFAULT 'pending'");

    echo "SUCCESS: trade_executions.execution_status changed to VARCHAR(50)\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
