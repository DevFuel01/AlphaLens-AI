<?php
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    // Check if column exists
    $stmt = $db->query("SHOW COLUMNS FROM trade_signals LIKE 'scheduled_at'");
    if ($stmt->fetch()) {
        echo "Column 'scheduled_at' already exists.\n";
    } else {
        $db->exec("ALTER TABLE trade_signals ADD COLUMN scheduled_at DATETIME NULL DEFAULT NULL");
        echo "Column 'scheduled_at' added successfully.\n";
    }
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
