-- Performance Metrics Table for Historical Tracking
CREATE TABLE IF NOT EXISTS performance_metrics (
    id INT PRIMARY KEY AUTO_INCREMENT,
    date DATE UNIQUE NOT NULL,
    equity DECIMAL(15,2),
    daily_return DECIMAL(10,4),
    cumulative_return DECIMAL(10,4),
    drawdown_pct DECIMAL(10,4),
    trades_count INT DEFAULT 0,
    wins_count INT DEFAULT 0,
    losses_count INT DEFAULT 0,
    total_pnl DECIMAL(15,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_date (date)
);
