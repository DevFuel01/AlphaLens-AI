<?php

/**
 * Alpaca Trading API Configuration
 * Paper trading sandbox for AlphaLens AI
 */

return [
    // API Credentials (User will add their own after registration)
    'api_key' => 'Your_API_Key',
    'secret_key' => 'Your_Secret_Key',

    // API Endpoints
    'base_url' => 'https://paper-api.alpaca.markets', // Paper trading
    'data_url' => 'https://data.alpaca.markets',

    // Trading Settings
    'paper_trading' => true,
    'default_cash' => 100000, // $100k virtual cash

    // API Settings
    'timeout' => 30,
    'retry_attempts' => 3,
    'retry_delay' => 2
];
