<?php

/**
 * Gemini AI Configuration for AlphaLens AI
 * API credentials and settings
 */

return [
    'api_key' => 'Your API Key',
    'api_endpoint' => 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent',
    'model' => 'gemini-2.5-flash',
    'temperature' => 0.3, // Lower temperature for more consistent analysis
    'max_tokens' => 2048,
    'timeout' => 30, // seconds
    'retry_attempts' => 3,
    'retry_delay' => 2 // seconds
];
