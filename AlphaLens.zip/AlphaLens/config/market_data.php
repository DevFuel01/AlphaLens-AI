<?php

/**
 * Market Data API Configuration
 * Alpha Vantage, Polygon.io, and NewsAPI
 */

return [
    // Alpha Vantage (for stock data and earnings)
    'alpha_vantage' => [
        'api_key' => 'A9K43E5JNHSVQ06S',
        'base_url' => 'https://www.alphavantage.co/query',
        'rate_limit' => 5, // calls per minute for free tier
        'timeout' => 30
    ],

    // Polygon.io (for real-time market data)
    'polygon' => [
        'api_key' => 'epvKRvnwo7Q9KZ4ZdCh74Q0kZxIaleRE',
        'base_url' => 'https://api.polygon.io',
        'timeout' => 30
    ],

    // NewsAPI (for financial news)
    'newsapi' => [
        'api_key' => '2eeb9933c7b046e1bd2c9c8c0ecd9ac1',
        'base_url' => 'https://newsapi.org/v2',
        'sources' => '', // Leave empty for broader discovery (previous sources were too restrictive)
        'language' => 'en',
        'timeout' => 30
    ]
];
