# AI Safeguards Documentation

## AlphaLens AI - Explainable AI Integration

This document explains how AlphaLens AI uses Gemini AI responsibly and transparently.

---

## Core Principle

**AI is a reasoning engine, not an autonomous trader.**

AlphaLens AI treats Gemini as a sophisticated analysis tool that:
- Reads and interprets complex financial documents
- Extracts sentiment and key insights
- Generates human-readable explanations
- Assigns confidence scores

**AI does NOT:**
- Execute trades
- Override risk controls
- Make final decisions
- Allocate capital

---

## AI Responsibilities

### 1. Sentiment Analysis

**Input**: Earnings transcript or news article  
**Process**: Gemini analyzes text and extracts:
- Overall sentiment (bullish/neutral/bearish)
- Sentiment score (-100 to +100)
- Confidence level (0-100%)
- Key insights (3-5 bullet points)
- Trade thesis (2-3 sentences)
- Tone shift analysis
- Narrative risks

**Output**: Structured JSON response stored in database

**Explainability**: Every field has clear meaning and justification

### 2. Factor Discovery

AI helps identify patterns in earnings calls:
- Management tone changes
- Guidance revisions
- Unexpected risks mentioned
- Positive/negative language shifts

These factors are presented to human traders for validation.

### 3. Thesis Generation

AI generates a plain-language trade thesis explaining:
- Why the sentiment is bullish/bearish/neutral
- What key factors support this view
- What risks exist
- What the confidence level means

---

## What AI Cannot Do

### ❌ Execute Trades Directly

AI output goes through:
1. **Rule Validator** - Deterministic checks
2. **Risk Controller** - Hard limits that can veto
3. **Manual Approval** (semi-auto mode) - Human decision

AI has **zero direct access** to trading execution.

### ❌ Override Risk Controls

The Risk Controller operates independently:

```php
// Risk Controller can VETO any trade
if ($positionSize > $maxAllowed) {
    return ['approved' => false, 'veto_reason' => 'Position too large'];
}
```

AI confidence level does NOT influence risk limits.

### ❌ Allocate Position Sizes

Position sizing is calculated by deterministic rules:

```php
$basePositionPct = 3; // 3% base
$confidenceMultiplier = $aiConfidence / 100;
$positionPct = $basePositionPct * $confidenceMultiplier;
```

AI provides confidence; rules calculate size.

### ❌ Bypass Validation

Every AI output must pass:
- Confidence threshold check (≥60%)
- Event window validation (within 48 hours)
- Liquidity check
- Signal quality assessment

Failed checks = rejected signal, regardless of AI confidence.

---

## Explainability Mechanisms

### 1. Structured Prompts

AI receives structured prompts with clear instructions:

```
Analyze the following earnings transcript and provide:
1. Overall sentiment (bullish/neutral/bearish)
2. Sentiment score (-100 to +100)
3. Confidence level (0-100)
4. Key insights (3-5 bullet points)
5. Trade thesis (2-3 sentences explaining opportunity)
...

Format as JSON with exact keys: sentiment, sentiment_score, ...
```

This ensures consistent, parseable output.

### 2. Prompt Versioning

All prompts are versioned in the database:

```sql
SELECT * FROM prompt_versions 
WHERE prompt_name = 'earnings_sentiment_analysis' 
AND is_active = TRUE;
```

This allows:
- Reproducibility (same prompt = same analysis)
- A/B testing (compare prompt versions)
- Audit trail (know which prompt generated which analysis)

### 3. Full Response Storage

Every Gemini API response is stored:

```sql
INSERT INTO ai_sentiment_analysis (..., gemini_response) 
VALUES (..., json_encode($rawResponse));
```

This enables:
- Debugging (what did AI actually say?)
- Verification (did we parse correctly?)
- Compliance (full audit trail)

### 4. Human-Readable Output

AI output is presented in plain language:

**Example Trade Thesis:**
> "Company beat earnings expectations by 12% and raised full-year guidance. Management tone was confident, highlighting strong demand in core markets. However, margin pressure from supply chain costs presents a risk. Overall bullish with 75% confidence."

No black-box scores without explanation.

---

## Audit Trail Structure

Every AI decision is logged:

```sql
INSERT INTO decision_logs (
    ticker, 
    decision_type, 
    decision_outcome, 
    decision_reason, 
    decision_data
) VALUES (
    'AAPL',
    'ai_analysis',
    'approved',
    'AI sentiment analysis completed successfully',
    json_encode($fullAnalysis)
);
```

**Logged Information:**
- Ticker symbol
- Decision type (AI analysis, rule check, risk check)
- Outcome (approved/rejected/error)
- Reason (human-readable explanation)
- Full data (complete context)
- Timestamp
- Related signal ID

**Accessibility:**
- View in Audit Trail page
- Filter by type, ticker, date
- Expand to see full JSON
- Export for compliance

---

## Risk Override Protection

### Scenario: AI is 95% confident, but risk limits exceeded

**AI Output:**
```json
{
    "sentiment": "bullish",
    "confidence_level": 95,
    "trade_thesis": "Strong buy signal..."
}
```

**Rule Validator:** ✓ Passed (confidence ≥ 60%)

**Risk Controller:**
```php
// Check position size
if ($proposedSize > $maxPositionSize) {
    return [
        'approved' => false,
        'veto_reason' => 'Position size exceeds 5% limit'
    ];
}
```

**Result:** ❌ Trade VETOED

**Logged:**
```
Decision Type: risk_check
Outcome: rejected
Reason: RISK VETO - Position size exceeds 5% limit
```

**AI cannot override this veto.**

---

## Confidence Calibration

AI confidence scores are used for:
1. **Filtering**: Signals below 60% confidence are rejected
2. **Position Sizing**: Higher confidence = slightly larger position (within limits)
3. **Transparency**: Users see why AI is confident/uncertain

AI confidence does NOT:
- Override risk limits
- Bypass rule validation
- Guarantee execution

---

## Continuous Monitoring

### 1. Prompt Performance Tracking

Track which prompts generate best signals:

```sql
SELECT 
    pv.prompt_version,
    AVG(ais.confidence_level) as avg_confidence,
    COUNT(*) as total_analyses
FROM ai_sentiment_analysis ais
JOIN prompt_versions pv ON ais.prompt_version_id = pv.id
GROUP BY pv.prompt_version;
```

### 2. AI Accuracy Validation

Compare AI sentiment to actual trade outcomes:

```sql
SELECT 
    ais.sentiment,
    AVG(te.pnl) as avg_pnl,
    COUNT(*) as trade_count
FROM ai_sentiment_analysis ais
JOIN trade_signals ts ON ts.sentiment_analysis_id = ais.id
JOIN trade_executions te ON te.signal_id = ts.id
GROUP BY ais.sentiment;
```

### 3. Error Logging

All AI errors are logged:

```php
if (!$response['success']) {
    $this->logDecision(
        $ticker,
        'ai_analysis',
        'error',
        'AI analysis failed: ' . $response['error'],
        []
    );
}
```

---

## Ethical Considerations

### 1. No Black-Box Decisions

Every AI output includes:
- Clear sentiment classification
- Numerical score with range
- Human-readable explanation
- Key supporting evidence
- Identified risks

### 2. Human Oversight

Semi-automated mode requires:
- Human review of AI thesis
- Manual approval before execution
- Ability to reject AI recommendations

### 3. Transparency

Users can:
- View full AI reasoning
- See rule/risk check results
- Access complete audit trail
- Understand why trades were approved/rejected

### 4. Accountability

Every decision is traceable:
- Who: System or manual override
- What: AI analysis, rule check, risk check
- When: Timestamp
- Why: Detailed reason
- How: Full decision data

---

## Summary

AlphaLens AI uses Gemini responsibly by:

✅ **Limiting AI Role**: Analysis and explanation only  
✅ **Enforcing Safeguards**: Rules and risk controls cannot be overridden  
✅ **Ensuring Explainability**: Every output has clear reasoning  
✅ **Maintaining Audit Trail**: Complete transparency  
✅ **Requiring Human Oversight**: Manual approval option  
✅ **Versioning Prompts**: Reproducibility and testing  
✅ **Logging Everything**: Full accountability  

**AI assists. Rules validate. Risk controls veto. Humans decide.**
