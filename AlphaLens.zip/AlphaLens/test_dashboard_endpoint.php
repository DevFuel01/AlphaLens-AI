<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Testing dashboard data endpoint...\n\n";

try {
    // Simulate the dashboard data request
    $_SERVER['REQUEST_METHOD'] = 'GET';

    ob_start();
    include __DIR__ . '/api/endpoints/get_dashboard_data.php';
    $output = ob_get_clean();

    echo "Response:\n";
    echo $output;
    echo "\n";
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
    echo "Stack trace:\n" . $e->getTraceAsString() . "\n";
}
