/**
 * Dashboard JavaScript for AlphaLens AI
 * Fetches and displays portfolio data, positions, and signals
 */

// Auto-refresh interval (30 seconds)
const REFRESH_INTERVAL = 30000;

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    loadDashboardData();
    loadRecentSignals();
    
    // Auto-refresh
    setInterval(() => {
        loadDashboardData();
        loadRecentSignals();
    }, REFRESH_INTERVAL);
});

/**
 * Load dashboard data from API
 */
async function loadDashboardData() {
    try {
        const response = await fetch('api/endpoints/get_dashboard_data.php');
        const data = await response.json();
        
        if (data.success) {
            updateAccountStats(data.account);
            updateRiskMetrics(data.risk_metrics, data.today_trades);
            updatePositionsTable(data.positions);
            updateExposure(data.total_exposure, data.account.portfolio_value);
            updateSectorExposure(data.sector_exposure, data.account.portfolio_value);
            loadPendingOrders(); // New function
        } else {
            console.error('Failed to load dashboard data:', data.error);
        }
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

/**
 * Update account statistics
 */
function updateAccountStats(account) {
    document.getElementById('portfolio-value').textContent = formatCurrency(account.portfolio_value);
    document.getElementById('cash-balance').textContent = formatCurrency(account.cash);
    
    // Calculate change (placeholder - would need historical data)
    const change = 0;
    const changeEl = document.getElementById('portfolio-change');
    changeEl.textContent = formatPercent(change);
    changeEl.className = 'stat-change ' + (change >= 0 ? 'positive' : 'negative');
}

/**
 * Update risk metrics
 */
function updateRiskMetrics(metrics, todayTrades) {
    // Daily P&L
    const dailyPnl = metrics.daily_pnl || 0;
    const dailyPnlPct = metrics.daily_pnl_pct || 0;
    document.getElementById('daily-pnl').textContent = formatCurrency(dailyPnl);
    
    const dailyPnlPctEl = document.getElementById('daily-pnl-pct');
    dailyPnlPctEl.textContent = formatPercent(dailyPnlPct);
    dailyPnlPctEl.className = 'stat-change ' + (dailyPnl >= 0 ? 'positive' : 'negative');
    
    // Cumulative P&L
    const cumulativePnl = metrics.cumulative_pnl || 0;
    const cumulativePnlPct = metrics.cumulative_pnl_pct || 0;
    document.getElementById('cumulative-pnl').textContent = formatCurrency(cumulativePnl);
    
    const cumulativePnlPctEl = document.getElementById('cumulative-pnl-pct');
    cumulativePnlPctEl.textContent = formatPercent(cumulativePnlPct);
    cumulativePnlPctEl.className = 'stat-change ' + (cumulativePnl >= 0 ? 'positive' : 'negative');
    
    // Max Drawdown
    const maxDrawdown = metrics.max_drawdown_pct || 0;
    document.getElementById('max-drawdown').textContent = formatPercent(maxDrawdown);
    
    // Today's Trades
    const tradesCount = todayTrades.count || 0;
    const wins = todayTrades.wins || 0;
    const winRate = tradesCount > 0 ? (wins / tradesCount) * 100 : 0;
    
    document.getElementById('today-trades').textContent = tradesCount;
    document.getElementById('win-rate').textContent = formatPercent(winRate) + ' Win Rate';
}

/**
 * Update positions table
 */
function updatePositionsTable(positions) {
    const tbody = document.getElementById('positions-table');
    document.getElementById('position-count').textContent = positions.length;
    
    if (positions.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">No open positions</td></tr>';
        return;
    }
    
    tbody.innerHTML = positions.map(pos => `
        <tr>
            <td><strong>${pos.ticker}</strong></td>
            <td>${formatNumber(pos.quantity)}</td>
            <td>${formatCurrency(pos.avg_entry_price)}</td>
            <td>${formatCurrency(pos.current_price)}</td>
            <td>${formatCurrency(pos.market_value)}</td>
            <td class="${pos.unrealized_pnl >= 0 ? 'positive' : 'negative'}">
                ${formatCurrency(pos.unrealized_pnl)}
            </td>
            <td class="${pos.unrealized_pnl_pct >= 0 ? 'positive' : 'negative'}">
                ${formatPercent(pos.unrealized_pnl_pct)}
            </td>
        </tr>
    `).join('');
}

/**
 * Update exposure metrics
 */
function updateExposure(totalExposure, portfolioValue) {
    document.getElementById('total-exposure').textContent = formatCurrency(totalExposure);
    
    const exposurePct = portfolioValue > 0 ? (totalExposure / portfolioValue) * 100 : 0;
    const exposurePctEl = document.getElementById('exposure-pct');
    exposurePctEl.textContent = formatPercent(exposurePct);
    
    // Color code based on exposure level
    if (exposurePct > 50) {
        exposurePctEl.className = 'stat-change negative';
    } else if (exposurePct > 30) {
        exposurePctEl.className = 'stat-change warning';
    } else {
        exposurePctEl.className = 'stat-change positive';
    }
}

/**
 * Load recent signals
 */
async function loadRecentSignals() {
    try {
        const response = await fetch('api/endpoints/get_signals.php?limit=5');
        const data = await response.json();
        
        if (data.success) {
            displayRecentSignals(data.signals);
        }
    } catch (error) {
        console.error('Error loading signals:', error);
    }
}

/**
 * Display recent signals
 */
function displayRecentSignals(signals) {
    const container = document.getElementById('recent-signals');
    
    if (signals.length === 0) {
        container.innerHTML = '<p class="empty-state">No recent signals</p>';
        return;
    }
    
    container.innerHTML = signals.map(signal => `
        <div class="signal-card">
            <div class="signal-header">
                <div>
                    <span class="signal-ticker">${signal.ticker}</span>
                    <span class="badge badge-${signal.sentiment}">${signal.sentiment}</span>
                    <span class="badge badge-${signal.final_status}">${signal.final_status}</span>
                </div>
                <div>
                    <span class="stat-change ${signal.sentiment_score >= 0 ? 'positive' : 'negative'}">
                        ${signal.sentiment_score > 0 ? '+' : ''}${signal.sentiment_score}
                    </span>
                </div>
            </div>
            <div class="signal-body">
                <p class="signal-thesis">${signal.trade_thesis}</p>
                <div class="signal-meta">
                    <span>Confidence: ${signal.confidence_level || signal.ai_confidence || 0}%</span>
                    <span>Signal: ${signal.signal_type.toUpperCase()}</span>
                    <span>${formatDate(signal.created_at)}</span>
                </div>
            </div>
        </div>
    `).join('');
}

/**
 * Load pending orders from API
 */
async function loadPendingOrders() {
    try {
        const response = await fetch('api/endpoints/get_pending_orders.php');
        const data = await response.json();
        
        if (data.success) {
            updateOrdersTable(data.orders);
        }
    } catch (error) {
        console.error('Error loading pending orders:', error);
    }
}

/**
 * Update pending orders table
 */
function updateOrdersTable(orders) {
    const tbody = document.getElementById('orders-table');
    
    if (!orders || orders.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="empty-state">No pending orders</td></tr>';
        return;
    }
    
    tbody.innerHTML = orders.map(order => `
        <tr>
            <td><strong>${order.symbol}</strong></td>
            <td><span class="badge badge-${order.side}">${order.side.toUpperCase()}</span></td>
            <td>${order.qty}</td>
            <td>${order.limit_price ? formatCurrency(order.limit_price) : 'MARKET'}</td>
            <td>${order.type.toUpperCase()}</td>
            <td><span class="badge badge-pending">${order.status.toUpperCase()}</span></td>
            <td>${formatDate(order.created_at)}</td>
        </tr>
    `).join('');
}

/**
 * Format currency
 */
function formatCurrency(value) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(Number(value));
}

/**
 * Format percentage
 */
function formatPercent(value) {
    const num = Number(value);
    return (num >= 0 ? '+' : '') + num.toFixed(2) + '%';
}

/**
 * Format number
 */
function formatNumber(value) {
    return new Intl.NumberFormat('en-US').format(Number(value));
}

/**
 * Format date
 */
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}
