/**
 * Update sector exposure breakdown
 */
function updateSectorExposure(sectorData, portfolioValue) {
    const container = document.getElementById('sector-exposure-container');
    
    if (!sectorData || sectorData.length === 0) {
        container.innerHTML = '<p class="empty-state">No sector data available</p>';
        return;
    }
    
    container.innerHTML = sectorData.map(sector => {
        const percentage = (sector.total_value / portfolioValue) * 100;
        const barWidth = Math.min(percentage, 100);
        
        // Color code based on concentration
        let colorClass = 'low';
        if (percentage > 30) colorClass = 'medium';
        if (percentage > 50) colorClass = 'high';
        
        return `
            <div class="sector-item" style="margin-bottom: 15px;">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <span style="font-weight: 600;">${sector.sector}</span>
                    <span>${formatCurrency(sector.total_value)} (${percentage.toFixed(1)}%)</span>
                </div>
                <div style="background: #2d3748; height: 20px; border-radius: 4px; overflow: hidden;">
                    <div class="sector-bar sector-bar-${colorClass}" style="width: ${barWidth}%; height: 100%; background: ${colorClass === 'high' ? '#ef4444' : colorClass === 'medium' ? '#f59e0b' : '#10b981'}; transition: width 0.3s ease;"></div>
                </div>
                <div style="font-size: 0.875rem; color: #9ca3af; margin-top: 3px;">
                    ${sector.position_count} position${sector.position_count > 1 ? 's' : ''} • P&L: ${formatCurrency(sector.total_pnl)}
                </div>
            </div>
        `;
    }).join('');
}
