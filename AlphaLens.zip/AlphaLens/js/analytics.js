/**
 * Analytics JavaScript for AlphaLens AI
 * Fetches and displays performance analytics with charts
 */

let winLossChart = null;
let drawdownChart = null;

// Initialize analytics on page load
document.addEventListener('DOMContentLoaded', () => {
    loadAnalytics();
});

/**
 * Load analytics data from API
 */
async function loadAnalytics() {
    try {
        const response = await fetch('api/endpoints/get_performance_analytics.php');
        const result = await response.json();
        
        if (result.success) {
            updateWinLossMetrics(result.data.win_loss);
            updateAverageReturnMetrics(result.data.average_return);
            updateRiskAdjustedMetrics(result.data.risk_adjusted);
            renderWinLossChart(result.data.win_loss.all_time);
            renderDrawdownChart(result.data.drawdown_history);
        } else {
            console.error('Failed to load analytics:', result.error);
        }
    } catch (error) {
        console.error('Error loading analytics:', error);
    }
}

/**
 * Update win/loss ratio metrics
 */
function updateWinLossMetrics(winLoss) {
    // All-time
    document.getElementById('all-time-win-rate').textContent = winLoss.all_time.win_rate + '%';
    document.getElementById('all-time-trades').textContent = 
        `${winLoss.all_time.wins}W / ${winLoss.all_time.losses}L`;
    
    // 30-day
    document.getElementById('30day-win-rate').textContent = winLoss.last_30_days.win_rate + '%';
    document.getElementById('30day-trades').textContent = 
        `${winLoss.last_30_days.wins}W / ${winLoss.last_30_days.losses}L`;
    
    // 7-day
    document.getElementById('7day-win-rate').textContent = winLoss.last_7_days.win_rate + '%';
    document.getElementById('7day-trades').textContent = 
        `${winLoss.last_7_days.wins}W / ${winLoss.last_7_days.losses}L`;
}

/**
 * Update average return metrics
 */
function updateAverageReturnMetrics(avgReturn) {
    // All-time
    document.getElementById('all-time-avg-return').textContent = formatCurrency(avgReturn.all_time.avg_pnl);
    document.getElementById('all-time-avg-pct').textContent = formatPercent(avgReturn.all_time.avg_pnl_pct);
    
    // 30-day
    document.getElementById('30day-avg-return').textContent = formatCurrency(avgReturn.last_30_days.avg_pnl);
    document.getElementById('30day-avg-pct').textContent = formatPercent(avgReturn.last_30_days.avg_pnl_pct);
    
    // 7-day
    document.getElementById('7day-avg-return').textContent = formatCurrency(avgReturn.last_7_days.avg_pnl);
    document.getElementById('7day-avg-pct').textContent = formatPercent(avgReturn.last_7_days.avg_pnl_pct);
    
    // Total
    document.getElementById('total-pnl').textContent = formatCurrency(avgReturn.all_time.total_pnl);
    document.getElementById('total-trades').textContent = avgReturn.all_time.trade_count + ' trades';
}

/**
 * Update risk-adjusted metrics
 */
function updateRiskAdjustedMetrics(riskAdjusted) {
    const sharpeRatio = riskAdjusted.sharpe_ratio;
    document.getElementById('sharpe-ratio').textContent = sharpeRatio !== null ? sharpeRatio.toFixed(2) : 'N/A';
    
    // Note: Best/worst trade and profit factor would require additional backend calculations
    // Placeholder for now
}

/**
 * Render win/loss pie chart
 */
function renderWinLossChart(data) {
    const ctx = document.getElementById('winLossChart').getContext('2d');
    
    if (winLossChart) {
        winLossChart.destroy();
    }
    
    winLossChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Wins', 'Losses', 'Breakeven'],
            datasets: [{
                data: [data.wins, data.losses, data.breakeven],
                backgroundColor: ['#10b981', '#ef4444', '#6b7280'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#e5e7eb',
                        font: { size: 12 }
                    }
                }
            }
        }
    });
}

/**
 * Render drawdown chart
 */
function renderDrawdownChart(history) {
    const ctx = document.getElementById('drawdownChart').getContext('2d');
    
    if (drawdownChart) {
        drawdownChart.destroy();
    }
    
    if (!history || history.length === 0) {
        ctx.fillStyle = '#9ca3af';
        ctx.font = '14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('No historical data available', ctx.canvas.width / 2, ctx.canvas.height / 2);
        return;
    }
    
    const dates = history.map(d => d.date);
    const equity = history.map(d => parseFloat(d.equity));
    const drawdown = history.map(d => parseFloat(d.drawdown_pct));
    
    drawdownChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: dates,
            datasets: [
                {
                    label: 'Equity',
                    data: equity,
                    borderColor: '#3b82f6',
                    backgroundColor: 'rgba(59, 130, 246, 0.1)',
                    yAxisID: 'y',
                    tension: 0.4
                },
                {
                    label: 'Drawdown %',
                    data: drawdown,
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    yAxisID: 'y1',
                    tension: 0.4,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            interaction: {
                mode: 'index',
                intersect: false
            },
            plugins: {
                legend: {
                    labels: {
                        color: '#e5e7eb'
                    }
                }
            },
            scales: {
                x: {
                    ticks: { color: '#9ca3af' },
                    grid: { color: '#374151' }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    ticks: { color: '#3b82f6' },
                    grid: { color: '#374151' }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    ticks: { color: '#ef4444' },
                    grid: { display: false }
                }
            }
        }
    });
}

/**
 * Format currency
 */
function formatCurrency(value) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(Number(value));
}

/**
 * Format percent
 */
function formatPercent(value) {
    const num = Number(value);
    return (num >= 0 ? '+' : '') + num.toFixed(2) + '%';
}
