# AlphaLens AI - Explainable Trading Agent

**An institutional-grade, AI-driven trading agent that analyzes U.S. earnings reports and financial news to generate disciplined, risk-controlled trading decisions.**

## 🎯 Core Principle

**AI is used strictly for reasoning and analysis. Deterministic rules and risk controls govern all execution decisions.**

- ✅ AI (Gemini) analyzes data and provides explanations
- ✅ All trade execution requires passing through rule and risk engines
- ❌ AI cannot override risk controls or execute trades directly
- ✅ Every AI decision is logged with full explanation trail

- ✅ Every AI decision is logged with full explanation trail

## 🏆 Key Differentiators (Hackathon Alignment)

### 1. Designed for Agent Track 🤖
- **Full Autonomy**: `DecisionOrchestrator` runs a closed-loop "OODA" cycle (Observe-Orient-Decide-Act).
- **Self-Correction**: `process_scheduled_trades` and `ResearchReplay` systems allow the agent to manage time and learn from history.

### 2. "Glass Box" Explainability 🔍
- **No Black Boxes**: Every trade comes with a `trade_thesis`, `confidence_score`, and `narrative_risk` explanation.
- **Visual Rationale**: The "Trade Rationale Viewer" shows exactly which rules passed or failed.

### 3. Institutional Risk Discipline 🛡️
- **Risk > AI**: A dedicated `RiskController` enforces hard limits (Position Size, Drawdown, Exposure) that the AI cannot override.
- **Safety First**: Features `halt_trading.php` (Kill-Switch) and `advisory` mode for safe paper trading.

### 4. Production Readiness 🏭
- **Live-Capital Ready**: Includes "Emergency Stop", "Slippage Protection", and "Execution Auditing".
- **Resilient**: Token throttling, error boundaries, and rigorous logging (System Quality 10.2).

### 5. Experimentation Depth 🧪
- **Research Replay Mode**: Backtest AI logic against historical data.
- **Prompt Versioning**: A/B test prompt strategies with `manage_prompts.php`.

---

## 🏗️ System Architecture

```
Data Sources (Earnings/News)
    ↓
AI Sentiment Analyzer (Gemini)
    ↓
Rule Validator (Deterministic Checks)
    ↓
Risk Controller (Can Veto Any Trade)
    ↓
Manual Approval (Semi-Auto) / Auto-Execute (Full-Auto)
    ↓
Alpaca Paper Trading Sandbox
```

**Key Components:**
- **AI Layer** (Blue): Analyzes and explains
- **Risk Controller** (Red): Can veto any trade
- **Audit Trail** (Green): Full transparency

---

## 🚀 Quick Start

### Prerequisites

- **XAMPP** (Apache + MySQL + PHP)
- **Gemini API Key** (Already configured: `YOUR_GEMINI_API_KEY_HERE`)
- **Alpaca Paper Trading Account** (Free - see setup guide below)
- **Market Data API Keys** (Optional: Alpha Vantage, Polygon.io, NewsAPI)

### Installation Steps

#### 1. Set Up Database

```bash
# Start XAMPP MySQL
# Open phpMyAdmin or MySQL command line

# Import database schema
mysql -u root -p < c:\xampp\htdocs\AlphaLens\database\schema.sql
```

This creates:
- 15+ tables for earnings, news, AI analysis, trades, risk metrics
- Default risk rules (position limits, drawdown limits, etc.)
- Prompt versioning system
- Complete audit trail infrastructure

#### 2. Configure Alpaca Paper Trading

**Register for Free Alpaca Account:**

1. Go to: https://app.alpaca.markets/signup
2. Fill in: Name, Country, Email, Password
3. Switch to **Paper Trading** mode in dashboard
4. Click **"Generate API Key"**
5. Copy your **API Key ID** and **Secret Key**

**Update Configuration:**

Edit `c:\xampp\htdocs\AlphaLens\config\alpaca.php`:

```php
return [
    'api_key' => 'YOUR_API_KEY_ID_HERE',
    'secret_key' => 'YOUR_SECRET_KEY_HERE',
    // ... rest of config
];
```

#### 3. (Optional) Configure Market Data APIs

Edit `c:\xampp\htdocs\AlphaLens\config\market_data.php`:

```php
return [
    'alpha_vantage' => [
        'api_key' => 'YOUR_ALPHA_VANTAGE_KEY',
        // ...
    ],
    'polygon' => [
        'api_key' => 'YOUR_POLYGON_KEY',
        // ...
    ],
    'newsapi' => [
        'api_key' => 'YOUR_NEWSAPI_KEY',
        // ...
    ]
];
```

**Get Free API Keys:**
- Alpha Vantage: https://www.alphavantage.co/support/#api-key
- Polygon.io: https://polygon.io/
- NewsAPI: https://newsapi.org/register

#### 4. Start Application

```bash
# Start XAMPP (Apache + MySQL)

# Navigate to:
http://localhost/AlphaLens/
```

---

## 📊 Features

### 1. AI Sentiment Analysis
- Analyzes earnings transcripts and financial news
- Extracts sentiment (bullish/neutral/bearish)
- Generates human-readable trade thesis
- Assigns confidence scores
- Identifies tone shifts and narrative risks

### 2. Rule-Based Validation
- Confidence threshold checks
- Event window validation (only trade around earnings/news)
- Liquidity requirements
- Signal quality assessment

### 3. Risk-First Guardian Layer
**Can veto ANY trade - AI cannot override:**
- ✓ Maximum position size (5% of portfolio)
- ✓ Maximum portfolio exposure (30%)
- ✓ Daily drawdown limit (2%)
- ✓ Cumulative drawdown limit (10%)
- ✓ Cooldown period after losses (24 hours)
- ✓ Maximum concurrent positions (5)

### 4. Trading Modes
- **Semi-Automated**: AI analyzes → Rules check → Risk check → **Manual approval required**
- **Fully Automated**: AI analyzes → Rules check → Risk check → Auto-execute

### 5. Complete Audit Trail
- Every AI decision logged
- Rule validation results stored
- Risk check outcomes recorded
- Full transparency and explainability

---

## 🎨 User Interface

### Dashboard
- Portfolio value and P&L
- Risk metrics (drawdown, exposure)
- Open positions table
- Recent signals

### Signals Page
- All trade signals with AI reasoning
- Rule and risk validation results
- Manual approval controls
- Detailed trade thesis and insights

### News & Earnings Feed
- Chronological feed of analyzed content
- AI sentiment badges
- Confidence scores
- Trade thesis summaries

### Audit Trail
- Complete decision logs
- Filterable by type (AI analysis, rules, risk, execution)
- Expandable details
- Full JSON data available

---

## 🔒 AI Safeguards

### What AI Does:
✅ Analyze earnings transcripts  
✅ Extract sentiment from news  
✅ Generate trade thesis  
✅ Assign confidence scores  
✅ Identify key insights  

### What AI Cannot Do:
❌ Execute trades directly  
❌ Override risk controls  
❌ Allocate position sizes (calculated by rules)  
❌ Bypass validation checks  

### Explainability:
- Every AI output includes reasoning
- Sentiment scores are justified
- Key insights extracted and displayed
- Trade thesis in plain language
- Full Gemini response stored for audit

---

## 📁 Project Structure

```
AlphaLens/
├── config/
│   ├── database.php          # Database connection
│   ├── gemini.php             # Gemini AI config
│   ├── alpaca.php             # Alpaca trading API
│   └── market_data.php        # Market data APIs
├── api/
│   ├── ai/
│   │   ├── gemini_client.php      # Gemini API client
│   │   └── sentiment_analyzer.php # AI sentiment analysis
│   ├── engine/
│   │   ├── rule_validator.php         # Rule validation
│   │   ├── risk_controller.php        # Risk-First Guardian
│   │   └── decision_orchestrator.php  # Main decision flow
│   ├── trading/
│   │   ├── alpaca_client.php      # Alpaca integration
│   │   └── position_manager.php   # Position tracking
│   ├── data/
│   │   ├── earnings_ingest.php    # Earnings data ingestion
│   │   └── news_ingest.php        # News data ingestion
│   └── endpoints/
│       ├── get_dashboard_data.php # Dashboard API
│       ├── get_signals.php        # Signals API
│       ├── get_news_feed.php      # Feed API
│       ├── approve_trade.php      # Manual approval
│       ├── get_audit_trail.php    # Audit logs API
│       ├── get_config.php         # Config settings API
│       └── save_config.php        # Config update API
├── database/
│   └── schema.sql             # Complete database schema
├── css/
│   └── styles.css             # Clean professional styling
├── js/
│   └── dashboard.js           # Dashboard logic
├── index.html                 # Main dashboard
├── signals.html               # Signals page
├── feed.html                  # News & earnings feed
├── audit.html                 # Audit trail
├── settings.html              # System configuration
└── README.md                  # This file
```

---

## 🧪 Testing

### 1. Database Setup Test

```bash
# Verify tables created
mysql -u root -p -e "USE alphalens_db; SHOW TABLES;"

# Should show 15+ tables
```

### 2. Test Gemini AI Connection

Create `c:\xampp\htdocs\AlphaLens\tests\test_gemini.php`:

```php
<?php
require_once '../api/ai/gemini_client.php';

$gemini = new GeminiClient();
$result = $gemini->generateContent("Test prompt: What is 2+2?");

if ($result['success']) {
    echo "✓ Gemini AI connected successfully\n";
    echo "Response: " . $result['content'] . "\n";
} else {
    echo "✗ Error: " . $result['error'] . "\n";
}
?>
```

Run: `php c:\xampp\htdocs\AlphaLens\tests\test_gemini.php`

### 3. Test Alpaca Connection

After configuring your API keys, create `tests/test_alpaca.php`:

```php
<?php
require_once '../api/trading/alpaca_client.php';

$alpaca = new AlpacaClient();
$result = $alpaca->getAccount();

if ($result['success']) {
    echo "✓ Alpaca connected successfully\n";
    echo "Portfolio Value: $" . $result['data']['portfolio_value'] . "\n";
} else {
    echo "✗ Error: " . $result['error'] . "\n";
}
?>
```

### 4. Test Risk Controller

The risk controller should veto trades that exceed limits:

```php
<?php
require_once '../api/engine/risk_controller.php';

$riskController = new RiskController();
// Test with a signal ID
$result = $riskController->checkRisk(1);

if ($result['approved']) {
    echo "✓ Risk check passed\n";
} else {
    echo "⚠ Risk VETO: " . $result['veto_reason'] . "\n";
}
?>
```

---

## 🎯 Usage Workflow

### Adding Earnings Transcript

1. Insert earnings data into `earnings_transcripts` table
2. System automatically triggers AI analysis
3. AI generates sentiment and trade thesis
4. Rule validator checks signal quality
5. Risk controller validates against limits
6. Signal appears in dashboard for approval

### Manual Approval (Semi-Auto Mode)

1. Navigate to **Signals** page
2. Review AI trade thesis and insights
3. Check rule validation results
4. Check risk validation results
5. Click **"Execute Trade"** or **"Reject"**
6. Decision logged in audit trail

### Viewing Audit Trail

1. Navigate to **Audit Trail** page
2. Filter by decision type
3. Expand details to see full context
4. Verify AI reasoning and risk checks

---

## ⚙️ Configuration
### ⚡ Strategy Configuration Panel (New)
The system now includes a visual configuration panel at `settings.html` to manage:
-   **Trading Mode**: Toggle between Fully Automated and Semi-Automated
-   **Risk Rules**: Set Max Position Size, Drawdown Limits, etc.
-   **Asset Groups**: Enable/Disable entire sectors (Asset Whitelist)

Navigate to **Configuration** in the sidebar to adjust these settings without SQL queries.

### 🕒 Event-Driven Updates
-   **Signal Expiry**: Pending signals older than 48h are automatically expired.
-   **Time-Based Exits**: Positions held > 72h are automatically closed (Market Order).
-   *Note: These checks run automatically whenever the Dashboard is refreshed.*

---

## 🔐 Security Best Practices

1. **Never commit API keys** to version control
2. **Use environment variables** for production
3. **Enable HTTPS** for production deployment
4. **Restrict database access** to localhost only
5. **Implement user authentication** before production use

---

## 📈 Next Steps

1. **Register for Alpaca** (see `ALPACA_SETUP.md`)
2. **Get market data API keys** (optional but recommended)
3. **Import sample earnings data** for testing
4. **Configure risk rules** to your preferences
5. **Test decision flow** with sample data
6. **Deploy to production** when ready

---

## 🏆 Evaluation Alignment

This project demonstrates:

✅ **Strategic Creativity**: Novel AI-assisted factor discovery  
✅ **Real AI Experimentation**: Gemini for sentiment analysis  
✅ **Robust Technical Execution**: Institutional-grade architecture  
✅ **Professional Risk Discipline**: Risk-First Guardian Layer  
✅ **Readiness for Live Trading**: Complete audit trail and safeguards  

---

## 📝 License

This project is for educational and demonstration purposes.

---

## 🤝 Support

For issues or questions:
1. Check the audit trail for decision logs
2. Review `docs/AI_SAFEGUARDS.md` for AI integration details
3. Verify database schema is properly imported
4. Ensure all API keys are correctly configured

---

**Built with institutional-grade discipline. AI analyzes. Rules validate. Risk controls veto. Humans decide.**
