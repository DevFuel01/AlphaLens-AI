# Alpaca Paper Trading Setup Guide

## Overview
Alpaca provides a **FREE** paper trading environment perfect for AlphaLens AI. You get $100,000 in virtual cash to test your trading strategies with real-time market data.

---

## Step 1: Create Your Alpaca Account

### Registration URL
👉 **[Sign up here: https://app.alpaca.markets/signup](https://app.alpaca.markets/signup)**

### Required Information
- **First Name** and **Last Name**
- **Country of Tax Residence**
- **Email Address**
- **Password**

### Registration Screenshot
![Alpaca Registration Page](./alpaca_registration_page_1768360039718.png)

---

## Step 2: Access Paper Trading Dashboard

1. After signing up, log in to your Alpaca account
2. You'll see a toggle to switch between **"Live"** and **"Paper"** trading modes
3. Select **"Paper"** mode (this is free and requires no financial information)

---

## Step 3: Generate API Keys

1. In the Paper Trading dashboard, look for **"Generate API Key"** button
2. Click it to create your credentials
3. You'll receive:
   - **API Key ID** (like a username)
   - **Secret Key** (like a password - save this securely!)

> [!CAUTION]
> **Save your Secret Key immediately!** Alpaca only shows it once. If you lose it, you'll need to generate new keys.

---

## Step 4: Configure AlphaLens AI

Once you have your API keys, you'll add them to the AlphaLens AI configuration file:

**File**: `c:/xampp/htdocs/AlphaLens/config/alpaca.php`

```php
<?php
return [
    'api_key' => 'YOUR_API_KEY_ID_HERE',
    'secret_key' => 'YOUR_SECRET_KEY_HERE',
    'base_url' => 'https://paper-api.alpaca.markets', // Paper trading endpoint
    'data_url' => 'https://data.alpaca.markets'
];
?>
```

---

## What You Get with Alpaca Paper Trading

✅ **$100,000 virtual cash** (resetable anytime)  
✅ **Real-time market data** for U.S. stocks and ETFs  
✅ **Commission-free** simulated trading  
✅ **All order types** (market, limit, stop, bracket)  
✅ **Fractional shares** support  
✅ **Options trading** (up to level 3)  
✅ **No credit card required**  
✅ **Available globally**

---

## Next Steps

1. ✅ Register at [https://app.alpaca.markets/signup](https://app.alpaca.markets/signup)
2. ✅ Switch to Paper Trading mode
3. ✅ Generate API keys
4. ✅ Save your API Key ID and Secret Key
5. ⏳ Provide keys to configure AlphaLens AI

---

## Resources

- **Alpaca Documentation**: https://alpaca.markets/docs/
- **Paper Trading Guide**: https://alpaca.markets/docs/trading/paper-trading/
- **API Reference**: https://alpaca.markets/docs/api-references/trading-api/
