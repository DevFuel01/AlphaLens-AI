<?php

/**
 * API Endpoint: Trigger Ingestion for Ticker
 * Used by UI to analyze a specific stock
 */

// Increase execution time for AI processing
set_time_limit(300);
header('Content-Type: application/json');
require_once __DIR__ . '/../data/news_ingest.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    $input = json_decode(file_get_contents('php://input'), true);
    $ticker = strtoupper($input['ticker'] ?? '');

    if (empty($ticker)) {
        throw new Exception('Ticker is required');
    }

    $ingest = new NewsIngest();
    $result = $ingest->fetchNews($ticker);

    echo json_encode($result);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
