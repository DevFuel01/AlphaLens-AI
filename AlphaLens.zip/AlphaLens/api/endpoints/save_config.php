<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

try {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!$input) throw new Exception('Invalid JSON input');

    $db = Database::getInstance()->getConnection();

    // 1. Update System Config
    if (isset($input['system'])) {
        $stmt = $db->prepare("UPDATE system_config SET config_value = ? WHERE config_key = ?");
        foreach ($input['system'] as $key => $value) {
            // Convert arrays/booleans back to string/json for DB
            if (is_array($value)) $valStr = json_encode($value);
            elseif (is_bool($value)) $valStr = $value ? 'true' : 'false';
            else $valStr = (string)$value;

            $stmt->execute([$valStr, $key]);
        }
    }

    // 2. Update Risk Rules
    if (isset($input['risk'])) {
        $stmt = $db->prepare("UPDATE risk_rules SET rule_value = ?, is_active = ? WHERE rule_name = ?");
        foreach ($input['risk'] as $key => $data) {
            $stmt->execute([
                $data['value'],
                $data['is_active'] ? 1 : 0,
                $key
            ]);
        }
    }

    echo json_encode(['success' => true, 'message' => 'Configuration saved successfully']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
