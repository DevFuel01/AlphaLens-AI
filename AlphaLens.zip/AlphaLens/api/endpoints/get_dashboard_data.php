<?php

/**
 * API Endpoint: Get Dashboard Data
 * Returns P&L, positions, exposure, and risk metrics
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../trading/alpaca_client.php';
require_once __DIR__ . '/../trading/position_manager.php';
require_once __DIR__ . '/../engine/risk_controller.php';
require_once __DIR__ . '/../engine/expiry_manager.php';
require_once __DIR__ . '/../engine/exit_manager.php';
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();
    $alpaca = new AlpacaClient();
    $positionManager = new PositionManager();
    $riskController = new RiskController();
    $expiryManager = new ExpiryManager();
    $exitManager = new ExitManager();

    // Get account info from Alpaca
    $accountResult = $alpaca->getAccount();
    $account = $accountResult['success'] ? $accountResult['data'] : null;

    // DEBUG: Log raw account data to help identify why balance is $0
    if ($account) {
        file_put_contents(__DIR__ . '/../../logs/alpaca_account_debug.json', json_encode($account, JSON_PRETTY_PRINT));
    }

    // Sync state
    $positionManager->syncPositions();

    require_once __DIR__ . '/../trading/trade_executor.php';
    $tradeExecutor = new TradeExecutor();
    $tradeExecutor->syncOrders();

    // Get positions
    $positions = $positionManager->getOpenPositions();

    // Update and get latest risk metrics
    $currentEquity = $account['equity'] ?? 100000;
    $riskMetrics = $riskController->updateRiskMetrics($currentEquity);

    // Run expiry and time-based exit checks
    $expiryResults = $expiryManager->runChecks();

    // Run price-based exit triggers (SL/TP)
    $exitResults = $exitManager->runChecks();

    // Get today's trades
    $stmt = $db->query("
        SELECT COUNT(*) as count, 
               SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins,
               SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losses
        FROM trade_executions 
        WHERE DATE(executed_at) = CURDATE()
    ");
    $todayTrades = $stmt->fetch();

    $response = [
        'success' => true,
        'account' => [
            'equity' => $account['equity'] ?? 100000,
            'cash' => $account['cash'] ?? 100000,
            'buying_power' => $account['buying_power'] ?? 100000,
            'portfolio_value' => $account['portfolio_value'] ?? 100000
        ],
        'positions' => $positions,
        'position_count' => count($positions),
        'total_exposure' => $positionManager->getTotalExposure(),
        'sector_exposure' => $positionManager->getSectorExposure(),
        'risk_metrics' => $riskMetrics ?: [
            'daily_pnl' => 0,
            'daily_pnl_pct' => 0,
            'cumulative_pnl' => 0,
            'max_drawdown_pct' => 0
        ],
        'today_trades' => $todayTrades,
        'expiry_stats' => $expiryResults,
        'exit_stats' => $exitResults
    ];

    echo json_encode($response);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
