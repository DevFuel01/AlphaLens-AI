<?php

/**
 * API Endpoint: Get Performance Analytics
 * Returns comprehensive performance metrics and historical data
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../analytics/performance_analyzer.php';
require_once __DIR__ . '/../trading/alpaca_client.php';

try {
    $analyzer = new PerformanceAnalyzer();
    $alpaca = new AlpacaClient();

    // Get current equity from Alpaca
    $accountResult = $alpaca->getAccount();
    $currentEquity = $accountResult['success'] ? $accountResult['data']['equity'] : 100000;

    // Update today's metrics
    $analyzer->updateDailyMetrics($currentEquity);

    // Get comprehensive analytics
    $analytics = $analyzer->getPerformanceAnalytics();

    echo json_encode([
        'success' => true,
        'data' => $analytics,
        'current_equity' => $currentEquity
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
