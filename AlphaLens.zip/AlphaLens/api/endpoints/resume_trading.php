<?php

/**
 * API Endpoint: Resume Trading
 * Clears the global circuit breaker (system_halted flag)
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    $stmt = $db->prepare("
        UPDATE system_config 
        SET config_value = 'false' 
        WHERE config_key = 'system_halted'
    ");
    $stmt->execute();

    // Log the manual override
    $stmt = $db->prepare("
        INSERT INTO decision_logs (
            ticker, decision_type, decision_outcome, decision_reason, 
            decision_data
        ) VALUES ('SYSTEM', 'manual_override', 'approved', 'Manual resume: Trading reactivated by user.', ?)
    ");
    $stmt->execute([json_encode(['action' => 'resume_trading'])]);

    echo json_encode(['success' => true, 'message' => 'Trading has been resumed successfully.']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
