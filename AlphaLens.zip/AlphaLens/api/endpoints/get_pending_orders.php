<?php

/**
 * API Endpoint: Get Pending Orders
 * Returns open orders from Alpaca
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../trading/alpaca_client.php';

try {
    $alpaca = new AlpacaClient();
    $result = $alpaca->getOpenOrders();

    if (!$result['success']) {
        throw new Exception($result['error']);
    }

    echo json_encode([
        'success' => true,
        'orders' => $result['data']
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
