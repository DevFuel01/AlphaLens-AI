<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    // 1. Fetch System Config (Trading Mode, Asset Groups, etc.)
    $stmt = $db->query("SELECT config_key, config_value, config_type FROM system_config");
    $systemConfig = [];
    while ($row = $stmt->fetch()) {
        $value = $row['config_value'];
        // Cast types
        if ($row['config_type'] === 'boolean') $value = filter_var($value, FILTER_VALIDATE_BOOLEAN);
        elseif ($row['config_type'] === 'number') $value = (float)$value;
        elseif ($row['config_type'] === 'json') $value = json_decode($value, true);

        $systemConfig[$row['config_key']] = $value;
    }

    // 2. Fetch Risk Rules (Thresholds, Limits)
    $stmt = $db->query("SELECT rule_name, rule_value, rule_unit, is_active FROM risk_rules");
    $riskRules = [];
    while ($row = $stmt->fetch()) {
        $riskRules[$row['rule_name']] = [
            'value' => (float)$row['rule_value'],
            'unit' => $row['rule_unit'],
            'is_active' => (bool)$row['is_active']
        ];
    }

    echo json_encode([
        'success' => true,
        'system' => $systemConfig,
        'risk' => $riskRules
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
