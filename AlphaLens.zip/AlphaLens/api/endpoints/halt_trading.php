<?php

/**
 * API Endpoint: Halt Trading (Emergency Stop)
 * Sets global circuit breaker to stop all new trade executions.
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();

    // 1. Set system_halted config
    $stmt = $db->prepare("
        INSERT INTO system_config (config_key, config_value) 
        VALUES ('system_halted', 'true')
        ON DUPLICATE KEY UPDATE config_value = 'true'
    ");
    $stmt->execute();

    // 2. Log the event
    $stmt = $db->prepare("
        INSERT INTO decision_logs (
            ticker, decision_type, decision_outcome, decision_reason, decision_data
        ) VALUES (?, 'emergency_stop', 'halted', 'Manual emergency stop triggered', ?)
    ");

    $userFn = 'Admin User'; // In real system, get from session

    $stmt->execute([
        'SYSTEM',
        json_encode(['triggered_by' => $userFn, 'timestamp' => date('Y-m-d H:i:s')])
    ]);

    echo json_encode([
        'success' => true,
        'message' => '🚨 EMERGENCY STOP: Trading halted immediately. No new orders will be processed.'
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
