<?php

/**
 * API Endpoint: Get News Feed
 * Returns news and earnings with AI sentiment tags
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    // 1. Get total count
    $countStmt = $db->query("
        SELECT (SELECT COUNT(*) FROM earnings_transcripts) + (SELECT COUNT(*) FROM news_articles) as total
    ");
    $totalCount = (int)$countStmt->fetch()['total'];

    // 2. Get combined feed with UNION
    $query = "
        SELECT * FROM (
            SELECT 
                'earnings' as type,
                et.id,
                et.ticker,
                et.company_name,
                et.quarter,
                NULL as headline,
                NULL as summary,
                NULL as source,
                et.earnings_date as date,
                ais.sentiment,
                ais.sentiment_score,
                ais.confidence_level,
                ais.impact_score,
                ais.market_keywords,
                ais.analyst_estimates,
                ais.trade_thesis
            FROM earnings_transcripts et
            LEFT JOIN ai_sentiment_analysis ais ON ais.source_type = 'earnings' AND ais.source_id = et.id
            
            UNION ALL
            
            SELECT 
                'news' as type,
                na.id,
                na.ticker,
                NULL as company_name,
                NULL as quarter,
                na.headline,
                na.summary,
                na.source,
                na.published_at as date,
                ais.sentiment,
                ais.sentiment_score,
                ais.confidence_level,
                ais.impact_score,
                ais.market_keywords,
                ais.analyst_estimates,
                ais.trade_thesis
            FROM news_articles na
            LEFT JOIN ai_sentiment_analysis ais ON ais.source_type = 'news' AND ais.source_id = na.id
        ) combined_feed
        ORDER BY date DESC
        LIMIT :limit OFFSET :offset
    ";

    $stmt = $db->prepare($query);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $feed = $stmt->fetchAll();

    // Decode JSON fields
    foreach ($feed as &$item) {
        if (isset($item['market_keywords'])) {
            $item['market_keywords'] = json_decode($item['market_keywords'], true);
        }
        if (isset($item['analyst_estimates'])) {
            $item['analyst_estimates'] = json_decode($item['analyst_estimates'], true);
        }
    }

    echo json_encode([
        'success' => true,
        'feed' => $feed,
        'total' => $totalCount,
        'page' => $page,
        'limit' => $limit,
        'total_pages' => ceil($totalCount / $limit)
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
