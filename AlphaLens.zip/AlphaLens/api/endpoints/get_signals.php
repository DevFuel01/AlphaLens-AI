<?php

/**
 * API Endpoint: Get Trade Signals
 * Returns all trade signals with AI reasoning and status
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    // Get filter parameters
    $status = $_GET['status'] ?? 'all';
    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    // 1. Get total count for pagination
    $countQuery = "SELECT COUNT(*) as total FROM trade_signals ts";
    if ($status !== 'all') {
        $countQuery .= " WHERE ts.final_status = :status";
    }

    $countStmt = $db->prepare($countQuery);
    if ($status !== 'all') {
        $countStmt->bindValue(':status', $status, PDO::PARAM_STR);
    }
    $countStmt->execute();
    $totalCount = (int)$countStmt->fetch()['total'];

    // 2. Build list query
    $query = "
        SELECT 
            ts.*,
            COALESCE(ais.source_type, 'system') as source_type,
            COALESCE(ais.sentiment, CASE WHEN ts.signal_type = 'buy' THEN 'bullish' ELSE 'bearish' END) as sentiment,
            COALESCE(ais.sentiment_score, CASE WHEN ts.signal_type = 'buy' THEN 100 ELSE -100 END) as sentiment_score,
            COALESCE(ais.confidence_level, ts.ai_confidence) as confidence_level,
            ais.key_insights,
            ais.key_quotes,
            ais.forward_looking_statements,
            ais.impact_score,
            ais.market_keywords,
            ais.analyst_estimates,
            ais.tone_shift,
            ais.narrative_risk
        FROM trade_signals ts
        LEFT JOIN ai_sentiment_analysis ais ON ts.sentiment_analysis_id = ais.id
    ";

    if ($status !== 'all') {
        $query .= " WHERE ts.final_status = :status";
    }

    $query .= " ORDER BY ts.created_at DESC LIMIT :limit OFFSET :offset";

    $stmt = $db->prepare($query);

    if ($status !== 'all') {
        $stmt->bindValue(':status', $status, PDO::PARAM_STR);
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);

    $stmt->execute();
    $signals = $stmt->fetchAll();

    // Parse JSON fields
    foreach ($signals as &$signal) {
        if ($signal['key_insights']) {
            $signal['key_insights'] = json_decode($signal['key_insights'], true);
        }
        if ($signal['key_quotes']) {
            $signal['key_quotes'] = json_decode($signal['key_quotes'], true);
        }
        if ($signal['market_keywords']) {
            $signal['market_keywords'] = json_decode($signal['market_keywords'], true);
        }
        if ($signal['analyst_estimates']) {
            $signal['analyst_estimates'] = json_decode($signal['analyst_estimates'], true);
        }
        if ($signal['forward_looking_statements']) {
            $signal['forward_looking_statements'] = json_decode($signal['forward_looking_statements'], true);
        }
        if ($signal['rule_validation_notes']) {
            $signal['rule_validation_notes'] = json_decode($signal['rule_validation_notes'], true);
        }
        if ($signal['risk_validation_notes']) {
            $signal['risk_validation_notes'] = json_decode($signal['risk_validation_notes'], true);
        }
        if ($signal['risk_check_results']) {
            $signal['risk_check_results'] = json_decode($signal['risk_check_results'], true);
        }
    }

    echo json_encode([
        'success' => true,
        'signals' => $signals,
        'total' => $totalCount,
        'page' => $page,
        'limit' => $limit,
        'total_pages' => ceil($totalCount / $limit)
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
