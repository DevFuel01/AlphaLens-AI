<?php

/**
 * API Endpoint: Approve Trade
 * Manual approval for semi-automated mode
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    $db = Database::getInstance()->getConnection();

    $input = json_decode(file_get_contents('php://input'), true);
    $signalId = $input['signal_id'] ?? null;
    $action = $input['action'] ?? null; // 'approve' or 'reject'

    if (!$signalId || !$action) {
        throw new Exception('Missing required parameters');
    }

    // Get signal
    $stmt = $db->prepare("SELECT * FROM trade_signals WHERE id = ?");
    $stmt->execute([$signalId]);
    $signal = $stmt->fetch();

    if (!$signal) {
        throw new Exception('Signal not found');
    }

    // Check if signal is valid for execution
    // It should be 'pending' (awaiting user) or 'approved' (ready but failed previously)
    // It cannot be 'executed', 'rejected', or 'cancelled'
    if (in_array($signal['final_status'], ['executed', 'rejected', 'cancelled'])) {
        throw new Exception('Signal is already ' . $signal['final_status']);
    }

    // Check for scheduling
    $scheduledFor = $input['scheduled_for'] ?? null;

    if ($action === 'approve') {
        if ($scheduledFor) {
            // Schedule for later
            $stmt = $db->prepare("
                UPDATE trade_signals 
                SET final_status = 'scheduled', scheduled_at = ?
                WHERE id = ?
            ");
            $stmt->execute([$scheduledFor, $signalId]);

            // Log decision
            $stmt = $db->prepare("
                INSERT INTO decision_logs (
                    ticker, decision_type, decision_outcome, decision_reason, decision_data, related_signal_id
                ) VALUES (?, 'manual_override', 'scheduled', 'User scheduled trade for later execution', ?, ?)
            ");
            $stmt->execute([
                $signal['ticker'],
                json_encode(['scheduled_for' => $scheduledFor]),
                $signalId
            ]);

            echo json_encode([
                'success' => true,
                'message' => "Trade scheduled for $scheduledFor",
                'signal_id' => $signalId,
                'status' => 'scheduled'
            ]);
            exit;
        }

        // Standard Immediate Approval
        // Update signal status to approved first
        $stmt = $db->prepare("
            UPDATE trade_signals 
            SET final_status = 'approved', approved_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$signalId]);

        // Trigger real execution
        require_once __DIR__ . '/../trading/trade_executor.php';
        $executor = new TradeExecutor();
        $executionResult = $executor->executeSignal($signalId);

        if (!$executionResult['success']) {
            throw new Exception("Approval saved, but execution failed: " . $executionResult['error']);
        }

        // Log manual approval
        $stmt = $db->prepare("
            INSERT INTO decision_logs (
                ticker, decision_type, decision_outcome, decision_reason,
                decision_data, related_signal_id
            ) VALUES (?, 'manual_override', 'approved', 'User manually approved signal', ?, ?)
        ");
        $stmt->execute([
            $signal['ticker'],
            json_encode($executionResult),
            $signalId
        ]);

        echo json_encode([
            'success' => true,
            'message' => $executionResult['message'],
            'signal_id' => $signalId,
            'execution' => $executionResult
        ]);
    } else {
        // Reject signal
        $stmt = $db->prepare("
            UPDATE trade_signals 
            SET final_status = 'cancelled'
            WHERE id = ?
        ");
        $stmt->execute([$signalId]);

        // Log decision
        $stmt = $db->prepare("
            INSERT INTO decision_logs (
                ticker, decision_type, decision_outcome, decision_reason,
                decision_data, related_signal_id
            ) VALUES (?, 'manual_override', 'rejected', 'User manually rejected signal', '{}', ?)
        ");
        $stmt->execute([$signal['ticker'], $signalId]);

        echo json_encode([
            'success' => true,
            'message' => 'Signal rejected',
            'signal_id' => $signalId
        ]);
    }
} catch (Exception $e) {
    http_response_code(400);
    $errorMsg = $e->getMessage();
    file_put_contents(__DIR__ . '/../../logs/approval_error.log', date('Y-m-d H:i:s') . " - Error: " . $errorMsg . "\n", FILE_APPEND);
    echo json_encode(['success' => false, 'error' => $errorMsg]);
}
