<?php

/**
 * API Endpoint: Get Audit Trail
 * Returns complete decision logs for transparency
 */

header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;
    $ticker = $_GET['ticker'] ?? null;
    $type = $_GET['type'] ?? null;

    // Build base query
    $whereConditions = ["1=1"];
    $params = [];

    if ($ticker) {
        $whereConditions[] = "ticker = ?";
        $params[] = $ticker;
    }

    if ($type) {
        $whereConditions[] = "decision_type = ?";
        $params[] = $type;
    }

    $whereClause = implode(" AND ", $whereConditions);

    // Get total count for pagination
    $countStmt = $db->prepare("SELECT COUNT(*) as total FROM decision_logs WHERE $whereClause");
    $countStmt->execute($params);
    $totalCount = $countStmt->fetch()['total'];

    // Get logs with LIMIT and OFFSET
    $query = "SELECT * FROM decision_logs WHERE $whereClause ORDER BY created_at DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $db->prepare($query);
    $stmt->execute($params);
    $logs = $stmt->fetchAll();

    // Parse JSON data
    foreach ($logs as &$log) {
        if ($log['decision_data']) {
            $log['decision_data'] = json_decode($log['decision_data'], true);
        }
    }

    echo json_encode([
        'success' => true,
        'logs' => $logs,
        'total' => (int)$totalCount,
        'page' => $page,
        'limit' => $limit,
        'total_pages' => ceil($totalCount / $limit)
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
