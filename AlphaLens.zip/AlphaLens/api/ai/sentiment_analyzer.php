<?php

/**
 * Sentiment Analyzer for AlphaLens AI
 * Uses Gemini AI to analyze earnings and news sentiment
 * AI ONLY analyzes - does NOT execute trades
 */

require_once __DIR__ . '/gemini_client.php';
require_once __DIR__ . '/../../config/database.php';

class SentimentAnalyzer
{
    private $gemini;
    private $db;

    public function __construct()
    {
        $this->gemini = new GeminiClient();
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Analyze earnings transcript sentiment
     * 
     * @param int $transcriptId Earnings transcript ID
     * @return array Analysis results
     */
    public function analyzeEarnings($transcriptId)
    {
        // Get earnings transcript
        $stmt = $this->db->prepare("
            SELECT * FROM earnings_transcripts WHERE id = ?
        ");
        $stmt->execute([$transcriptId]);
        $transcript = $stmt->fetch();

        if (!$transcript) {
            return ['success' => false, 'error' => 'Transcript not found'];
        }

        // Get prompt template
        $promptTemplate = $this->getPromptTemplate('earnings_sentiment_analysis');

        // Build prompt with actual data
        $prompt = $this->buildPrompt($promptTemplate, [
            'company_name' => $transcript['company_name'],
            'ticker' => $transcript['ticker'],
            'quarter' => $transcript['quarter'],
            'earnings_date' => $transcript['earnings_date'],
            'transcript_text' => substr($transcript['transcript_text'], 0, 30000), // Increase limit for full transcripts
            'guidance_text' => $transcript['guidance_text'] ?? 'No guidance provided'
        ]);

        // Send to Gemini AI for analysis
        $response = $this->gemini->generateContent($prompt);

        if (!$response['success']) {
            return [
                'success' => false,
                'error' => $response['error']
            ];
        }

        try {
            // Parse AI response
            $analysis = $this->gemini->parseJsonResponse($response['content']);

            // Validate required fields
            $this->validateAnalysis($analysis);

            // Store analysis in database
            $analysisId = $this->storeAnalysis(
                'earnings',
                $transcriptId,
                $transcript['ticker'],
                $analysis,
                $response['raw_response']
            );

            // Log decision
            $this->logDecision(
                $transcript['ticker'],
                'ai_analysis',
                'approved',
                'AI sentiment analysis completed successfully',
                $analysis
            );

            return [
                'success' => true,
                'analysis_id' => $analysisId,
                'analysis' => $analysis
            ];
        } catch (Exception $e) {
            // Log error
            $this->logDecision(
                $transcript['ticker'],
                'ai_analysis',
                'error',
                'AI analysis failed: ' . $e->getMessage(),
                []
            );

            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Analyze news article sentiment
     * 
     * @param int $articleId News article ID
     * @return array Analysis results
     */
    public function analyzeNews($articleId)
    {
        // Get news article
        $stmt = $this->db->prepare("
            SELECT * FROM news_articles WHERE id = ?
        ");
        $stmt->execute([$articleId]);
        $article = $stmt->fetch();

        if (!$article) {
            return ['success' => false, 'error' => 'Article not found'];
        }

        // Build news analysis prompt
        $prompt = $this->buildNewsPrompt($article);

        // Send to Gemini AI
        $response = $this->gemini->generateContent($prompt);

        if (!$response['success']) {
            return [
                'success' => false,
                'error' => $response['error']
            ];
        }

        try {
            $analysis = $this->gemini->parseJsonResponse($response['content']);
            $this->validateAnalysis($analysis);

            $analysisId = $this->storeAnalysis(
                'news',
                $articleId,
                $article['ticker'],
                $analysis,
                $response['raw_response']
            );

            $this->logDecision(
                $article['ticker'],
                'ai_analysis',
                'approved',
                'News sentiment analysis completed',
                $analysis
            );

            return [
                'success' => true,
                'analysis_id' => $analysisId,
                'analysis' => $analysis
            ];
        } catch (Exception $e) {
            $this->logDecision(
                $article['ticker'],
                'ai_analysis',
                'error',
                'News analysis failed: ' . $e->getMessage(),
                []
            );

            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Get prompt template from database
     */
    private function getPromptTemplate($promptName)
    {
        $stmt = $this->db->prepare("
            SELECT prompt_template 
            FROM prompt_versions 
            WHERE prompt_name = ? AND is_active = TRUE
            ORDER BY id DESC LIMIT 1
        ");
        $stmt->execute([$promptName]);
        $result = $stmt->fetch();

        return $result ? $result['prompt_template'] : null;
    }

    /**
     * Build prompt by replacing placeholders
     */
    private function buildPrompt($template, $data)
    {
        $prompt = $template;
        foreach ($data as $key => $value) {
            $prompt = str_replace('{' . $key . '}', $value, $prompt);
        }
        return $prompt;
    }

    /**
     * Build news analysis prompt
     */
    private function buildNewsPrompt($article)
    {
        return "Analyze the following financial news article and provide sentiment analysis.

TICKER: {$article['ticker']}
HEADLINE: {$article['headline']}
PUBLISHED: {$article['published_at']}
SOURCE: {$article['source']}

ARTICLE:
{$article['full_text']}

Please provide:
1. Overall sentiment (bullish/neutral/bearish)
2. Sentiment score (-100 to +100)
3. Confidence level (0-100)
4. Impact Score (0-100): Rate the potential market impact (0=Noise, 100=Major Market Mover)
5. Key insights (3-5 bullet points)
6. Market Keywords (3-5 short tags/themes e.g., 'Inventory', 'AI Demand', 'Inflation')
7. Trade thesis (2-3 sentences)
8. Tone shift (positive/neutral/negative)
9. Narrative risks
10. Key quotes (2-3 direct impactful quotes from management/source)
11. Forward-looking statements (Specific guidance or predictive claims)
12. Analyst Estimates (Did they beat/miss? Format: \"revenue\": \"beat\", \"eps\": \"miss\", \"details\": \"string\")

Format as JSON with keys: sentiment, sentiment_score, confidence_level, impact_score, key_insights, market_keywords, trade_thesis, tone_shift, narrative_risk, key_quotes, forward_looking_statements, analyst_estimates";
    }

    /**
     * Validate AI analysis response
     */
    private function validateAnalysis($analysis)
    {
        $required = ['sentiment', 'sentiment_score', 'confidence_level', 'key_insights', 'trade_thesis', 'narrative_risk'];

        foreach ($required as $field) {
            if (!isset($analysis[$field])) {
                throw new Exception("Missing required field: $field");
            }
        }

        // Validate sentiment
        if (!in_array($analysis['sentiment'], ['bullish', 'neutral', 'bearish'])) {
            throw new Exception("Invalid sentiment value");
        }

        // Validate ranges
        if ($analysis['sentiment_score'] < -100 || $analysis['sentiment_score'] > 100) {
            throw new Exception("Sentiment score out of range");
        }

        if ($analysis['confidence_level'] < 0 || $analysis['confidence_level'] > 100) {
            throw new Exception("Confidence level out of range");
        }
    }

    /**
     * Store analysis in database
     */
    private function storeAnalysis($sourceType, $sourceId, $ticker, $analysis, $rawResponse)
    {
        $stmt = $this->db->prepare("
            INSERT INTO ai_sentiment_analysis (
                source_type, source_id, ticker, sentiment, sentiment_score,
                confidence_level, impact_score, key_insights, market_keywords, analyst_estimates, key_quotes, forward_looking_statements, trade_thesis, tone_shift,
                narrative_risk, gemini_response
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $toneShift = is_array($analysis['tone_shift']) ? implode(', ', $analysis['tone_shift']) : ($analysis['tone_shift'] ?? null);
        $narrativeRisk = is_array($analysis['narrative_risk']) ? implode('. ', $analysis['narrative_risk']) : ($analysis['narrative_risk'] ?? null);

        $stmt->execute([
            $sourceType,
            $sourceId,
            $ticker,
            $analysis['sentiment'],
            $analysis['sentiment_score'],
            $analysis['confidence_level'],
            $analysis['impact_score'] ?? null,
            json_encode($analysis['key_insights']),
            json_encode($analysis['market_keywords'] ?? []),
            json_encode($analysis['analyst_estimates'] ?? []),
            json_encode($analysis['key_quotes'] ?? []),
            json_encode($analysis['forward_looking_statements'] ?? []),
            $analysis['trade_thesis'],
            $toneShift,
            $narrativeRisk,
            json_encode($rawResponse)
        ]);

        return $this->db->lastInsertId();
    }

    /**
     * Log decision to audit trail
     */
    private function logDecision($ticker, $type, $outcome, $reason, $data)
    {
        $stmt = $this->db->prepare("
            INSERT INTO decision_logs (
                ticker, decision_type, decision_outcome, decision_reason, decision_data
            ) VALUES (?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $ticker,
            $type,
            $outcome,
            $reason,
            json_encode($data)
        ]);
    }
}
