<?php

/**
 * Gemini AI Client for AlphaLens AI
 * Handles all communication with Google Gemini API
 */

require_once __DIR__ . '/../../config/gemini.php';

class GeminiClient
{
    private $config;
    private $apiKey;
    private $endpoint;

    public function __construct()
    {
        $this->config = require __DIR__ . '/../../config/gemini.php';
        $this->apiKey = $this->config['api_key'];
        $this->endpoint = $this->config['api_endpoint'];
    }

    /**
     * Send prompt to Gemini and get response
     * 
     * @param string $prompt The prompt to send
     * @param array $options Additional options (temperature, max_tokens, etc.)
     * @return array Response data or error
     */
    public function generateContent($prompt, $options = [])
    {
        $temperature = $options['temperature'] ?? $this->config['temperature'];
        $maxTokens = $options['max_tokens'] ?? $this->config['max_tokens'];

        $requestData = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => $temperature,
                'maxOutputTokens' => $maxTokens,
                'topP' => 0.8,
                'topK' => 40
            ]
        ];

        // Attempt with retries
        $attempts = 0;
        $maxAttempts = $this->config['retry_attempts'];

        while ($attempts < $maxAttempts) {
            try {
                $response = $this->makeRequest($requestData);

                if ($response['success']) {
                    return [
                        'success' => true,
                        'content' => $this->extractContent($response['data']),
                        'raw_response' => $response['data']
                    ];
                }

                // If not successful, retry
                $attempts++;
                if ($attempts < $maxAttempts) {
                    sleep($this->config['retry_delay']);
                }
            } catch (Exception $e) {
                $attempts++;
                if ($attempts >= $maxAttempts) {
                    return [
                        'success' => false,
                        'error' => $e->getMessage()
                    ];
                }
                sleep($this->config['retry_delay']);
            }
        }

        return [
            'success' => false,
            'error' => 'Max retry attempts reached'
        ];
    }

    /**
     * Make HTTP request to Gemini API
     */
    private function makeRequest($data)
    {
        $url = $this->endpoint . '?key=' . $this->apiKey;

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->config['timeout']);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            throw new Exception("cURL Error: " . $error);
        }

        if ($httpCode !== 200) {
            $errorData = json_decode($response, true);
            $errorMsg = $errorData['error']['message'] ?? 'Unknown API error';
            throw new Exception("API Error (HTTP $httpCode): " . $errorMsg);
        }

        return [
            'success' => true,
            'data' => json_decode($response, true)
        ];
    }

    /**
     * Extract text content from Gemini response
     */
    private function extractContent($responseData)
    {
        if (isset($responseData['candidates'][0]['content']['parts'][0]['text'])) {
            return $responseData['candidates'][0]['content']['parts'][0]['text'];
        }

        throw new Exception("Invalid response format from Gemini API");
    }

    /**
     * Parse JSON response from Gemini
     * Handles cases where JSON is wrapped in markdown code blocks
     */
    public function parseJsonResponse($content)
    {
        // Remove markdown code blocks if present
        $content = preg_replace('/```json\s*|\s*```/', '', $content);
        $content = trim($content);

        $decoded = json_decode($content, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Failed to parse JSON: " . json_last_error_msg());
        }

        return $decoded;
    }
}
