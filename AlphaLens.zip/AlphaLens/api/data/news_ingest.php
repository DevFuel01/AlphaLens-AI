<?php

/**
 * News Ingestion Service for AlphaLens AI
 * Fetches financial news and triggers AI analysis
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/market_data.php';
require_once __DIR__ . '/../engine/decision_orchestrator.php';

class NewsIngest
{
    private $db;
    private $config;
    private $orchestrator;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
        $this->config = require __DIR__ . '/../../config/market_data.php';
        $this->orchestrator = new DecisionOrchestrator();
    }

    /**
     * Fetch news for a specific ticker or general market news
     */
    public function fetchNews($ticker = null)
    {
        $apiKey = $this->config['newsapi']['api_key'];
        $baseUrl = $this->config['newsapi']['base_url'];
        $sources = $this->config['newsapi']['sources'];

        $endpoint = "$baseUrl/everything";
        $params = [
            'apiKey' => $apiKey,
            'language' => 'en',
            'sortBy' => 'publishedAt',
            'pageSize' => 10
        ];

        // Only restrict sources if we are NOT searching for a specific ticker
        // This allows broader coverage for specific company news
        if (!empty($sources) && !$ticker) {
            $params['sources'] = $sources;
        }

        if ($ticker) {
            // Search for ticker OR company name variations to improve hits
            $params['q'] = "($ticker OR \"$ticker Stock\")";
        } else {
            $params['q'] = 'finance OR stock market OR economy';
        }

        $url = $endpoint . '?' . http_build_query($params);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERAGENT, 'AlphaLensAI/1.0');
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->config['newsapi']['timeout']);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            return ['success' => false, 'error' => "NewsAPI Error (HTTP $httpCode): " . $response];
        }

        $data = json_decode($response, true);
        if (!isset($data['articles'])) {
            return ['success' => false, 'error' => "Unexpected NewsAPI response format"];
        }

        $count = 0;
        foreach ($data['articles'] as $article) {
            if ($this->saveAndProcessNews($article, $ticker)) {
                $count++;
            }
        }

        return ['success' => true, 'processed_count' => $count];
    }

    /**
     * Save news to database and trigger decision orchestration
     */
    private function saveAndProcessNews($article, $ticker)
    {
        // Skip if article already exists (by URL)
        $stmt = $this->db->prepare("SELECT id FROM news_articles WHERE url = ?");
        $stmt->execute([$article['url']]);
        if ($stmt->fetch()) {
            return false;
        }

        // Insert into news_articles
        $stmt = $this->db->prepare("
            INSERT INTO news_articles (
                ticker, headline, summary, full_text, source, published_at, url, raw_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $publishedAt = date('Y-m-d H:i:s', strtotime($article['publishedAt']));

        $stmt->execute([
            $ticker,
            $article['title'],
            $article['description'],
            $article['content'],
            $article['source']['name'],
            $publishedAt,
            $article['url'],
            json_encode($article)
        ]);

        $newsId = $this->db->lastInsertId();

        // Trigger AI analysis and decision flow
        $this->orchestrator->processNews($newsId);

        return true;
    }
}

// CLI Execution Support
if (php_sapi_name() === 'cli' && isset($argv[0]) && basename($argv[0]) === 'news_ingest.php') {
    $ingest = new NewsIngest();
    $ticker = $argv[1] ?? null;
    echo "Starting news ingestion" . ($ticker ? " for $ticker" : "") . "...\n";
    $result = $ingest->fetchNews($ticker);
    print_r($result);
}
