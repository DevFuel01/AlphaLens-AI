<?php

/**
 * Earnings Ingestion Service for AlphaLens AI
 * Fetches earnings transcripts using Alpha Vantage and triggers AI analysis
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/market_data.php';
require_once __DIR__ . '/../engine/decision_orchestrator.php';

class EarningsIngest
{
    private $db;
    private $config;
    private $orchestrator;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
        $this->config = require __DIR__ . '/../../config/market_data.php';
        $this->orchestrator = new DecisionOrchestrator();
    }

    /**
     * Fetch earnings transcript for a specific ticker and quarter
     */
    public function ingestEarnings($ticker, $year, $quarter)
    {
        $apiKey = $this->config['alpha_vantage']['api_key'];
        $baseUrl = $this->config['alpha_vantage']['base_url'];

        // 1. Get financial data summary first
        $params = [
            'function' => 'EARNINGS',
            'symbol' => $ticker,
            'apikey' => $apiKey
        ];

        $url = $baseUrl . '?' . http_build_query($params);
        $response = $this->fetchUrl($url);
        $data = json_decode($response, true);

        // Find the specific quarter in quarterlyEarnings
        $quarterData = null;
        if (isset($data['quarterlyEarnings'])) {
            foreach ($data['quarterlyEarnings'] as $report) {
                // Check if the fiscal date ending is in the requested year
                if (strpos($report['fiscalDateEnding'], $year) !== false) {
                    $reportMonth = date('n', strtotime($report['fiscalDateEnding']));
                    $reportQuarter = ceil($reportMonth / 3);

                    // If we find an exact quarter match (based on calendar month)
                    if ("Q$reportQuarter" === $quarter) {
                        $quarterData = $report;
                        break;
                    }
                }
            }

            // Fallback: If no perfect match, just take the first report from that year
            if (!$quarterData) {
                foreach ($data['quarterlyEarnings'] as $report) {
                    if (strpos($report['fiscalDateEnding'], $year) !== false) {
                        $quarterData = $report;
                        break;
                    }
                }
            }

            // Final fallback: just take the most recent one if we are in CLI and it failed
            if (!$quarterData && php_sapi_name() === 'cli' && !empty($data['quarterlyEarnings'])) {
                $quarterData = $data['quarterlyEarnings'][0];
                echo "Warning: Exact match failed. Using most recent: " . $quarterData['fiscalDateEnding'] . "\n";
            }
        }

        if (!$quarterData) {
            return ['success' => false, 'error' => "No earnings data found for $ticker $year $quarter"];
        }

        // 2. Fetch full transcript or high-fidelity summary
        $transcriptText = $this->fetchCallTranscript($ticker, $year, $quarter, $quarterData);

        return $this->saveAndProcessEarnings($ticker, $year, $quarter, $quarterData, $transcriptText);
    }

    /**
     * Intelligent transcript search with fallback
     */
    private function fetchCallTranscript($ticker, $year, $quarter, $quarterData)
    {
        // Source 1: Alpha Vantage (Premium/Pro Tier)
        $avTranscript = $this->fetchAlphaVantageTranscript($ticker, $year, $quarter);
        if ($avTranscript) return $avTranscript;

        // Source 2: Targeted NewsAPI Discovery
        $newsTranscript = $this->fetchNewsTranscriptDiscovery($ticker, $year, $quarter);
        if ($newsTranscript) return $newsTranscript;

        // Source 3: Basic Summary (Default Fallback)
        $summary = "Earnings Report Summary for $ticker ($year $quarter).\n";
        $summary .= "Reported Date: " . $quarterData['reportedDate'] . "\n";
        $summary .= "Reported EPS: " . $quarterData['reportedEPS'] . " (Surprise: " . $quarterData['surprisePercentage'] . "%)\n";
        $summary .= "Management Insights: Financial metrics are recorded, but full audio/text transcript was not found for this period. Sentiment based on reported surprises.";

        return $summary;
    }

    private function fetchAlphaVantageTranscript($ticker, $year, $quarter)
    {
        $apiKey = $this->config['alpha_vantage']['api_key'];
        $baseUrl = $this->config['alpha_vantage']['base_url'];

        $params = [
            'function' => 'EARNINGS_CALL_TRANSCRIPT',
            'symbol' => $ticker,
            'year' => $year,
            'quarter' => $quarter,
            'apikey' => $apiKey
        ];

        $resp = json_decode($this->fetchUrl($baseUrl . '?' . http_build_query($params)), true);

        if (!empty($resp['transcript'])) {
            // Handle array or string transcript
            return is_array($resp['transcript']) ? implode("\n", $resp['transcript']) : $resp['transcript'];
        }

        return null;
    }

    private function fetchNewsTranscriptDiscovery($ticker, $year, $quarter)
    {
        $apiKey = $this->config['newsapi']['api_key'];
        $query = urlencode("$ticker $year $quarter earnings transcript management comments");
        $url = "https://newsapi.org/v2/everything?q=$query&sortBy=relevancy&apiKey=$apiKey";

        $resp = json_decode($this->fetchUrl($url, ['User-Agent: AlphaLens-AI']), true);

        if (!empty($resp['articles'])) {
            $bestArticle = $resp['articles'][0]; // Relevancy sort
            return "SOURCE: {$bestArticle['source']['name']}\n" .
                "TITLE: {$bestArticle['title']}\n" .
                "CONTENT: {$bestArticle['content']}\n\n" .
                "(High-Fidelity Summary discovered via News Discovery)";
        }

        return null;
    }

    private function fetchUrl($url, $headers = [])
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        if ($headers) curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        $resp = curl_exec($ch);
        curl_close($ch);
        return $resp;
    }

    /**
     * Save earnings to database and trigger decision orchestration
     */
    private function saveAndProcessEarnings($ticker, $year, $quarter, $quarterData, $transcriptText)
    {
        // Extract company name if available in some sources, otherwise use ticker
        $companyName = $ticker;

        $stmt = $this->db->prepare("
            INSERT INTO earnings_transcripts (
                ticker, company_name, quarter, fiscal_year, earnings_date, transcript_text, raw_data
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $ticker,
            $companyName,
            $quarter,
            $year,
            $quarterData['reportedDate'],
            $transcriptText,
            json_encode($quarterData)
        ]);

        $transcriptId = $this->db->lastInsertId();

        // Trigger AI analysis and decision flow
        return $this->orchestrator->processEarnings($transcriptId);
    }
}
