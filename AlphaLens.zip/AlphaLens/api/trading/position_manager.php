<?php

/**
 * Position Manager for AlphaLens AI
 * Tracks and manages trading positions
 */

require_once __DIR__ . '/alpaca_client.php';
require_once __DIR__ . '/../../config/database.php';

class PositionManager
{
    private $db;
    private $alpaca;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
        $this->alpaca = new AlpacaClient();
    }

    /**
     * Sync positions from Alpaca to database
     */
    public function syncPositions()
    {
        $result = $this->alpaca->getPositions();

        if (!$result['success']) {
            return ['success' => false, 'error' => $result['error']];
        }

        $alpacaPositions = $result['data'];
        $alpacaTickers = [];

        // Update or insert positions from Alpaca
        foreach ($alpacaPositions as $pos) {
            $ticker = $pos['symbol'];
            $alpacaTickers[] = $ticker;

            // Fetch sector data from Alpaca (with caching to minimize API calls)
            $sector = $this->getSectorFallback($ticker);
            try {
                $assetResult = $this->alpaca->getAsset($ticker);
                if ($assetResult['success'] && !empty($assetResult['data']['sector'])) {
                    $sector = $assetResult['data']['sector'];
                }
            } catch (Exception $e) {
                // If sector fetch fails, continue with fallback
                error_log("Failed to fetch sector for {$ticker}: " . $e->getMessage());
            }

            $this->updatePosition([
                'ticker' => $ticker,
                'sector' => $sector,
                'quantity' => $pos['qty'],
                'avg_entry_price' => $pos['avg_entry_price'],
                'current_price' => $pos['current_price'],
                'market_value' => $pos['market_value'],
                'cost_basis' => $pos['cost_basis'],
                'unrealized_pnl' => $pos['unrealized_pl'],
                'unrealized_pnl_pct' => $pos['unrealized_plpc'] * 100
            ], true); // true = keep_protection
        }

        // Remove positions that are no longer at Alpaca
        if (!empty($alpacaTickers)) {
            $placeholders = implode(',', array_fill(0, count($alpacaTickers), '?'));
            $stmt = $this->db->prepare("DELETE FROM positions WHERE ticker NOT IN ($placeholders)");
            $stmt->execute($alpacaTickers);
        } else {
            // No positions at Alpaca, clear all
            $this->db->exec("DELETE FROM positions");
        }

        return ['success' => true, 'count' => count($alpacaPositions)];
    }

    /**
     * Update or insert position
     */
    public function updatePosition($data, $keepProtection = false)
    {
        $sql = "
            INSERT INTO positions (
                ticker, sector, quantity, avg_entry_price, current_price, market_value,
                cost_basis, unrealized_pnl, unrealized_pnl_pct" .
            ($keepProtection ? "" : ", stop_loss, take_profit") . "
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?" .
            ($keepProtection ? "" : ", ?, ?") . ")
            ON DUPLICATE KEY UPDATE
                sector = VALUES(sector),
                quantity = VALUES(quantity),
                avg_entry_price = VALUES(avg_entry_price),
                current_price = VALUES(current_price),
                market_value = VALUES(market_value),
                cost_basis = VALUES(cost_basis),
                unrealized_pnl = VALUES(unrealized_pnl),
                unrealized_pnl_pct = VALUES(unrealized_pnl_pct)";

        if (!$keepProtection) {
            $sql .= ", stop_loss = VALUES(stop_loss), take_profit = VALUES(take_profit)";
        }

        $stmt = $this->db->prepare($sql);

        $params = [
            $data['ticker'],
            $data['sector'] ?? 'Unknown',
            $data['quantity'],
            $data['avg_entry_price'],
            $data['current_price'],
            $data['market_value'],
            $data['cost_basis'],
            $data['unrealized_pnl'],
            $data['unrealized_pnl_pct']
        ];

        if (!$keepProtection) {
            $params[] = $data['stop_loss'] ?? null;
            $params[] = $data['take_profit'] ?? null;
        }

        $stmt->execute($params);
    }

    /**
     * Get all open positions
     */
    public function getOpenPositions()
    {
        $stmt = $this->db->query("
            SELECT * FROM positions WHERE quantity != 0 ORDER BY ABS(market_value) DESC
        ");
        return $stmt->fetchAll();
    }

    /**
     * Calculate total exposure
     */
    public function getTotalExposure()
    {
        $stmt = $this->db->query("
            SELECT COALESCE(SUM(ABS(market_value)), 0) as total_exposure 
            FROM positions WHERE quantity != 0
        ");
        $result = $stmt->fetch();
        return $result['total_exposure'];
    }

    /**
     * Get exposure breakdown by sector
     */
    public function getSectorExposure()
    {
        $stmt = $this->db->query("
            SELECT 
                sector,
                COUNT(*) as position_count,
                SUM(ABS(market_value)) as total_value,
                SUM(unrealized_pnl) as total_pnl
            FROM positions 
            WHERE quantity != 0
            GROUP BY sector
            ORDER BY total_value DESC
        ");
        return $stmt->fetchAll();
    }

    /**
     * Get a specific position by ticker
     */
    public function getPositionByTicker($ticker)
    {
        $stmt = $this->db->prepare("SELECT * FROM positions WHERE ticker = ?");
        $stmt->execute([$ticker]);
        return $stmt->fetch();
    }
    /**
     * Fallback mapping for common stock sectors
     */
    private function getSectorFallback($ticker)
    {
        $mapping = [
            'NVDA' => 'Technology',
            'AAPL' => 'Technology',
            'MSFT' => 'Technology',
            'GOOG' => 'Technology',
            'GOOGL' => 'Technology',
            'META' => 'Technology',
            'AMZN' => 'Consumer Discretionary',
            'TSLA' => 'Consumer Discretionary',
            'AMD'  => 'Technology',
            'INTC' => 'Technology',
            'NFLX' => 'Communication Services',
            'PYPL' => 'Financial Services',
            'SQ'   => 'Financial Services',
            'V'    => 'Financial Services',
            'MA'   => 'Financial Services',
            'JPM'  => 'Financial Services',
            'BAC'  => 'Financial Services',
            'WMT'  => 'Consumer Staples',
            'COST' => 'Consumer Staples'
        ];

        return $mapping[strtoupper($ticker)] ?? 'Unknown';
    }
}
