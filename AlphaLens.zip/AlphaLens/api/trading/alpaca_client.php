<?php

/**
 * Alpaca Trading Client for AlphaLens AI
 * Handles all communication with Alpaca Paper Trading API
 */

require_once __DIR__ . '/../../config/alpaca.php';

class AlpacaClient
{
    private $config;
    private $apiKey;
    private $secretKey;
    private $baseUrl;

    public function __construct()
    {
        $this->config = require __DIR__ . '/../../config/alpaca.php';
        $this->apiKey = $this->config['api_key'];
        $this->secretKey = $this->config['secret_key'];
        $this->baseUrl = $this->config['base_url'];
    }

    /**
     * Get account information
     */
    public function getAccount()
    {
        return $this->makeRequest('GET', '/v2/account');
    }

    /**
     * Get all positions
     */
    public function getPositions()
    {
        return $this->makeRequest('GET', '/v2/positions');
    }

    /**
     * Get specific position
     */
    public function getPosition($symbol)
    {
        return $this->makeRequest('GET', "/v2/positions/{$symbol}");
    }

    /**
     * Place market order
     */
    public function placeMarketOrder($symbol, $qty, $side, $clientOrderId = null)
    {
        $data = [
            'symbol' => $symbol,
            'qty' => $qty,
            'side' => $side, // 'buy' or 'sell'
            'type' => 'market',
            'time_in_force' => 'day'
        ];

        if ($clientOrderId) {
            $data['client_order_id'] = $clientOrderId;
        }

        return $this->makeRequest('POST', '/v2/orders', $data);
    }

    /**
     * Place limit order
     */
    public function placeLimitOrder($symbol, $qty, $side, $limitPrice, $clientOrderId = null)
    {
        $data = [
            'symbol' => $symbol,
            'qty' => $qty,
            'side' => $side,
            'type' => 'limit',
            'limit_price' => $limitPrice,
            'time_in_force' => 'day'
        ];

        if ($clientOrderId) {
            $data['client_order_id'] = $clientOrderId;
        }

        return $this->makeRequest('POST', '/v2/orders', $data);
    }

    /**
     * Place bracket order (with stop loss and take profit)
     * The base order must be a limit order for Alpaca bracket orders
     */
    public function placeBracketOrder($symbol, $qty, $side, $limitPrice, $stopLoss, $takeProfit, $clientOrderId = null)
    {
        $data = [
            'symbol' => $symbol,
            'qty' => $qty,
            'side' => $side,
            'type' => 'limit',
            'limit_price' => $limitPrice,
            'time_in_force' => 'gtc',
            'order_class' => 'bracket',
            'stop_loss' => [
                'stop_price' => $stopLoss
            ],
            'take_profit' => [
                'limit_price' => $takeProfit
            ]
        ];

        if ($clientOrderId) {
            $data['client_order_id'] = $clientOrderId;
        }

        return $this->makeRequest('POST', '/v2/orders', $data);
    }

    /**
     * Get order status
     */
    public function getOrder($orderId)
    {
        return $this->makeRequest('GET', "/v2/orders/{$orderId}");
    }

    /**
     * Get all open orders
     */
    public function getOpenOrders()
    {
        return $this->makeRequest('GET', '/v2/orders?status=open');
    }

    /**
     * Cancel order
     */
    public function cancelOrder($orderId)
    {
        return $this->makeRequest('DELETE', "/v2/orders/{$orderId}");
    }

    /**
     * Get latest quote for symbol
     */
    public function getQuote($symbol)
    {
        $url = $this->config['data_url'];
        $feed = $this->config['data_feed'] ?? 'iex';
        return $this->makeRequest('GET', "/v2/stocks/{$symbol}/quotes/latest?feed={$feed}", null, $url);
    }

    /**
     * Get snapshot (latest trade, quote, daily bar, prev daily bar)
     */
    public function getSnapshot($symbol)
    {
        $url = $this->config['data_url'];
        $feed = $this->config['data_feed'] ?? 'iex';
        return $this->makeRequest('GET', "/v2/stocks/{$symbol}/snapshot?feed={$feed}", null, $url);
    }

    /**
     * Get historical bars for a symbol
     */
    /**
     * Get historical bars for a symbol
     */
    public function getBars($symbol, $timeframe = '1Day', $limit = 100, $start = null, $end = null)
    {
        $url = $this->config['data_url'];
        $feed = $this->config['data_feed'] ?? 'iex';
        $endpoint = "/v2/stocks/{$symbol}/bars?timeframe={$timeframe}&limit={$limit}&adjustment=all&feed={$feed}";

        if ($start) {
            $endpoint .= "&start={$start}";
        }
        if ($end) {
            $endpoint .= "&end={$end}";
        }

        return $this->makeRequest('GET', $endpoint, null, $url);
    }

    /**
     * Get asset information (includes sector/industry data)
     */
    public function getAsset($symbol)
    {
        return $this->makeRequest('GET', "/v2/assets/{$symbol}");
    }

    /**
     * Make HTTP request to Alpaca API
     */
    private function makeRequest($method, $endpoint, $data = null, $baseUrl = null)
    {
        $url = ($baseUrl ?? $this->baseUrl) . $endpoint;

        $ch = curl_init($url);

        // Set headers
        $headers = [
            'APCA-API-KEY-ID: ' . $this->apiKey,
            'APCA-API-SECRET-KEY: ' . $this->secretKey,
            'Content-Type: application/json'
        ];

        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, $this->config['timeout'] ?? 30);

        // Set method and data
        if ($method === 'POST') {
            curl_setopt($ch, CURLOPT_POST, true);
            if ($data) {
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
            }
        } elseif ($method === 'DELETE') {
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
        }

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return [
                'success' => false,
                'error' => "cURL Error: " . $error . " for URL: " . $url
            ];
        }

        $responseData = json_decode($response, true);

        if ($httpCode >= 200 && $httpCode < 300) {
            return [
                'success' => true,
                'data' => $responseData
            ];
        } else {
            $msg = $responseData['message'] ?? (isset($responseData['error']) ? (json_encode($responseData['error'])) : 'Unknown API error');
            return [
                'success' => false,
                'error' => $msg . " (HTTP " . $httpCode . ") for URL: " . $url,
                'http_code' => $httpCode,
                'response' => $response
            ];
        }
    }
}
