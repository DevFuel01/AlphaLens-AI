<?php

/**
 * Trade Executor for AlphaLens AI
 * Handles actual execution of approved signals on Alpaca
 */

require_once __DIR__ . '/alpaca_client.php';
require_once __DIR__ . '/../../config/database.php';

class TradeExecutor
{
    private $alpaca;
    private $db;

    public function __construct()
    {
        $this->alpaca = new AlpacaClient();
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Execute an approved trade signal
     */
    public function executeSignal($signalId)
    {
        try {
            // JIT RISK CHECK: Final veto authority before execution
            require_once __DIR__ . '/../engine/risk_controller.php';
            $riskController = new RiskController();
            $riskResult = $riskController->checkRisk($signalId, true); // true = isJit

            if (!$riskResult['approved']) {
                throw new Exception("JIT RISK VETO: " . $riskResult['veto_reason']);
            }

            // Get signal details
            $stmt = $this->db->prepare("SELECT * FROM trade_signals WHERE id = ?");
            $stmt->execute([$signalId]);
            $signal = $stmt->fetch();

            if (!$signal) {
                throw new Exception("Signal $signalId not found");
            }

            $symbol = $signal['ticker'];

            // SLIPPAGE CHECK: Ensure live price hasn't moved too far
            $slippageResult = $this->checkSlippage($signal);
            if (!$slippageResult['passed']) {
                throw new Exception("SLIPPAGE VETO: " . $slippageResult['reason']);
            }

            // CALCULATE DELTA: How much do we need to buy/sell to reach target?
            require_once __DIR__ . '/position_manager.php';
            $posManager = new PositionManager();

            // Force sync to get ground truth from Alpaca
            $syncResult = $posManager->syncPositions();
            if (!$syncResult['success']) {
                throw new Exception("Position sync failed: " . ($syncResult['error'] ?? 'Unknown error'));
            }

            $currentPos = $posManager->getPositionByTicker($symbol);
            $currentQty = (float)($currentPos['quantity'] ?? 0);

            // Target quantity from signal (Short positions are negative)
            $targetQty = floor($signal['suggested_position_size'] / $signal['suggested_entry_price']);
            if ($signal['signal_type'] === 'sell') {
                $targetQty = -$targetQty;
            }

            // The amount we actually need to trade
            $deltaQty = $targetQty - $currentQty;

            if ($deltaQty == 0) {
                // Not an error, just nothing to do
                return [
                    'success' => true,
                    'message' => "Position already matches target (" . round($targetQty, 2) . "). No trade needed.",
                    'order_id' => null
                ];
            }

            // Generate a unique client order ID using microtime to prevent collisions
            $uniqueId = uniqid("alphalens_{$signalId}_", true);

            // GLOBAL CONFLICT RESOLUTION: Cancel ANY existing open orders for this symbol
            // This prevents "insufficient qty" (due to locking) and bracket rejections.
            $openOrdersResult = $this->alpaca->getOpenOrders();
            if ($openOrdersResult['success']) {
                $cancelledCount = 0;
                foreach ($openOrdersResult['data'] as $openOrder) {
                    if ($openOrder['symbol'] === $symbol) {
                        $this->alpaca->cancelOrder($openOrder['id']);
                        $cancelledCount++;
                    }
                }
                if ($cancelledCount > 0) {
                    usleep(1000000); // Wait 1s for Alpaca to clear the locks
                }
            }

            $isFlip = ($currentQty != 0 && $targetQty != 0 && ($currentQty > 0) !== ($targetQty > 0));

            if ($isFlip) {
                // FLIP LOGIC: Split into two orders (Close current + Open target)

                // 1. Close Current Position
                $qty1 = abs($currentQty);
                $side1 = $currentQty > 0 ? 'sell' : 'buy';

                // For close leg, never use brackets (it's an exit)
                $result1 = $this->alpaca->placeMarketOrder($symbol, $qty1, $side1, $uniqueId . "_close");

                if (!$result1['success']) {
                    throw new Exception("Flip Leg 1 (Close) Failed: " . ($result1['error'] ?? 'Unknown API error'));
                }

                // Track cost basis for P&L calculation on fill
                $this->logExecution($signalId, $result1['data'], $currentPos['avg_entry_price']);

                // Sequence delay
                usleep(1000000); // 1.0s to ensure internal Alpaca state updates

                // 2. Open New Position
                $qty2 = abs($targetQty);
                $side2 = $targetQty > 0 ? 'buy' : 'sell';

                // Alpaca bracket orders are ONLY for entry legs on zero position.
                // Since we just closed, we verify zero status.
                $useBracketOrder2 = ($side2 === 'buy' && !empty($signal['suggested_stop_loss']));

                if ($useBracketOrder2) {
                    $limitPrice = (float)($slippageResult['live_price'] ?? $signal['suggested_entry_price']);
                    $result = $this->alpaca->placeBracketOrder(
                        $symbol,
                        $qty2,
                        $side2,
                        round($limitPrice, 2),
                        round($signal['suggested_stop_loss'], 2),
                        round($signal['suggested_take_profit'], 2),
                        $uniqueId . "_open"
                    );
                } else {
                    $result = $this->alpaca->placeMarketOrder($symbol, $qty2, $side2, $uniqueId . "_open");
                }

                $absQty = $qty2;
                $side = $side2;
            } else {
                // NORMAL LOGIC (Entry, Exit, or Scale - No Flip)

                $absQty = abs($deltaQty);
                $side = $deltaQty > 0 ? 'buy' : 'sell';
                $isForcedExit = ($targetQty == 0);

                // BRACKET ORDER ELIGIBILITY:
                // 1. Must be a BUY (Long) order in this system (Short brackets validation is tricky).
                // 2. Must be an ENTRY order (currentQty must be 0) because Alpaca rejects brackets on additions/exits.
                // 3. Must not be a covering trade (isCovering should be false if currentQty == 0).
                $isEntry = ($currentQty == 0);
                $useBracketOrder = ($side === 'buy' && $isEntry && !$isForcedExit && !empty($signal['suggested_stop_loss']));

                if ($useBracketOrder) {
                    $limitPrice = (float)($slippageResult['live_price'] ?? $signal['suggested_entry_price']);
                    $result = $this->alpaca->placeBracketOrder(
                        $symbol,
                        $absQty,
                        $side,
                        round($limitPrice, 2),
                        round($signal['suggested_stop_loss'], 2),
                        round($signal['suggested_take_profit'], 2),
                        $uniqueId
                    );
                } else {
                    $result = $this->alpaca->placeMarketOrder($symbol, $absQty, $side, $uniqueId);
                }
            }

            if (!$result['success']) {
                $err = $result['error'] ?? 'Unknown API error';
                throw new Exception("Alpaca Order Failed: $err");
            }

            // Log execution
            // If this was a normal exit (closing part of a position), pass the current cost basis
            $costBasis = null;
            if (!$isFlip && ($currentQty != 0) && ($deltaQty < 0 && $currentQty > 0 || $deltaQty > 0 && $currentQty < 0)) {
                $costBasis = $currentPos['avg_entry_price'];
            }
            $this->logExecution($signalId, $result['data'], $costBasis);

            // Update local position tracking
            if ($targetQty != 0) {
                $posManager->updatePosition([
                    'ticker' => $symbol,
                    'quantity' => $targetQty,
                    'avg_entry_price' => $signal['suggested_entry_price'],
                    'current_price' => $slippageResult['live_price'] ?? $signal['suggested_entry_price'],
                    'market_value' => $targetQty * ($slippageResult['live_price'] ?? $signal['suggested_entry_price']),
                    'cost_basis' => $targetQty * $signal['suggested_entry_price'],
                    'unrealized_pnl' => 0,
                    'unrealized_pnl_pct' => 0,
                    'stop_loss' => $signal['suggested_stop_loss'],
                    'take_profit' => $signal['suggested_take_profit']
                ], false);
            }

            // Update signal status
            $stmt = $this->db->prepare("UPDATE trade_signals SET final_status = 'executed', executed_at = NOW() WHERE id = ?");
            $stmt->execute([$signalId]);

            return [
                'success' => true,
                'order_id' => $result['data']['id'] ?? 'executed',
                'message' => "Order executed successfully: $side " . round($absQty, 2) . " $symbol to reach target " . round($targetQty, 2)
            ];
        } catch (Exception $e) {
            $this->logError($signalId, $e->getMessage());
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * Synchronize local order statuses with Alpaca
     */
    public function syncOrders()
    {
        $stmt = $this->db->query("
            SELECT id, alpaca_order_id, ticker 
            FROM trade_executions 
            WHERE execution_status NOT IN ('filled', 'cancelled', 'rejected')
            LIMIT 10
        ");
        $orders = $stmt->fetchAll();

        $updatedCount = 0;
        foreach ($orders as $order) {
            try {
                $alpacaResult = $this->alpaca->getOrder($order['alpaca_order_id']);
                if ($alpacaResult['success']) {
                    $this->updateExecutionStatus($order['id'], $alpacaResult['data']);
                    $updatedCount++;
                }
            } catch (Exception $e) {
                continue;
            }
        }
        return ['success' => true, 'synced' => $updatedCount];
    }

    private function updateExecutionStatus($localId, $alpacaOrder)
    {
        $status = $alpacaOrder['status'];
        $filledQty = (float)($alpacaOrder['filled_qty'] ?? 0);
        $fillPrice = (float)($alpacaOrder['filled_avg_price'] ?? 0);
        $pnl = null;
        $pnlPct = null;

        // Calculate realized P&L if filled and we have a cost basis
        if ($status === 'filled' && $fillPrice > 0) {
            $stmt = $this->db->prepare("SELECT cost_basis_at_trade, side FROM trade_executions WHERE id = ?");
            $stmt->execute([$localId]);
            $exec = $stmt->fetch();

            if ($exec && $exec['cost_basis_at_trade'] !== null) {
                $costBasis = (float)$exec['cost_basis_at_trade'];
                $side = $exec['side']; // 'buy' or 'sell'

                if ($side === 'sell') { // Closing a long
                    $pnl = ($fillPrice - $costBasis) * $filledQty;
                    $pnlPct = ($fillPrice - $costBasis) / $costBasis * 100;
                } else { // side === 'buy', closing a short (covering)
                    $pnl = ($costBasis - $fillPrice) * $filledQty;
                    $pnlPct = ($costBasis - $fillPrice) / $costBasis * 100;
                }
            }
        }

        $stmt = $this->db->prepare("
            UPDATE trade_executions SET 
                execution_status = ?, filled_qty = ?, filled_avg_price = ?,
                pnl = ?, pnl_pct = ?,
                alpaca_response = ?, executed_at = ?
            WHERE id = ?
        ");
        $stmt->execute([
            $status,
            $filledQty,
            $fillPrice,
            $pnl,
            $pnlPct,
            json_encode($alpacaOrder),
            $alpacaOrder['filled_at'] ?? $alpacaOrder['created_at'],
            $localId
        ]);
    }

    private function logExecution($signalId, $alpacaOrder, $costBasis = null)
    {
        $stmt = $this->db->prepare("SELECT * FROM trade_signals WHERE id = ?");
        $stmt->execute([$signalId]);
        $signal = $stmt->fetch();

        $stmt = $this->db->prepare("
            INSERT INTO trade_executions (
                signal_id, ticker, side, quantity, entry_price, 
                cost_basis_at_trade,
                stop_loss, take_profit, alpaca_order_id, 
                alpaca_response, execution_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $signalId,
            $signal['ticker'],
            strtolower($alpacaOrder['side']),
            (float)($alpacaOrder['qty'] ?? 0),
            $signal['suggested_entry_price'],
            $costBasis,
            $signal['suggested_stop_loss'],
            $signal['suggested_take_profit'],
            $alpacaOrder['id'],
            json_encode($alpacaOrder),
            $alpacaOrder['status']
        ]);
    }

    private function checkSlippage($signal)
    {
        $symbol = $signal['ticker'];
        $suggestedPrice = (float)$signal['suggested_entry_price'];
        $snapshotResult = $this->alpaca->getSnapshot($symbol);

        if (!$snapshotResult['success']) {
            return ['passed' => false, 'reason' => 'Could not fetch live price'];
        }

        $latestPrice = (float)($snapshotResult['data']['latestTrade']['p'] ?? 0);
        if ($latestPrice <= 0) return ['passed' => false, 'reason' => 'Invalid live price'];

        $stmt = $this->db->prepare("SELECT config_value FROM system_config WHERE config_key = 'max_slippage_pct'");
        $stmt->execute();
        $maxSlippage = (float)($stmt->fetchColumn() ?: 1.0);

        $deviation = abs($latestPrice - $suggestedPrice) / $suggestedPrice * 100;
        if ($deviation > $maxSlippage) {
            return ['passed' => false, 'reason' => sprintf("Slippage too high: %.2f%%", $deviation)];
        }
        return ['passed' => true, 'live_price' => $latestPrice];
    }

    private function logError($signalId, $error)
    {
        $stmt = $this->db->prepare("
            INSERT INTO decision_logs (
                ticker, decision_type, decision_outcome, decision_reason, decision_data, related_signal_id
            ) SELECT ticker, 'execution_error', 'failed', ?, '{}', ? FROM trade_signals WHERE id = ?
        ");
        $stmt->execute([$error, $signalId, $signalId]);
    }
}
