<?php

/**
 * Performance Analyzer for AlphaLens AI
 * Calculates trading performance metrics and risk-adjusted returns
 */

require_once __DIR__ . '/../config/database.php';

class PerformanceAnalyzer
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Calculate win/loss ratio for a given period
     */
    public function calculateWinLossRatio($days = null)
    {
        $dateFilter = $days ? "AND DATE(executed_at) >= DATE_SUB(CURDATE(), INTERVAL ? DAY)" : "";

        $sql = "
            SELECT 
                COUNT(*) as total_trades,
                SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins,
                SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losses,
                SUM(CASE WHEN pnl = 0 THEN 1 ELSE 0 END) as breakeven
            FROM trade_executions
            WHERE execution_status = 'filled'
            AND pnl IS NOT NULL
            $dateFilter
        ";

        $stmt = $this->db->prepare($sql);
        if ($days) {
            $stmt->execute([$days]);
        } else {
            $stmt->execute();
        }

        $result = $stmt->fetch();

        $winRate = $result['total_trades'] > 0
            ? ($result['wins'] / $result['total_trades']) * 100
            : 0;

        return [
            'total_trades' => (int)$result['total_trades'],
            'wins' => (int)$result['wins'],
            'losses' => (int)$result['losses'],
            'breakeven' => (int)$result['breakeven'],
            'win_rate' => round($winRate, 2)
        ];
    }

    /**
     * Calculate average return per trade
     */
    public function calculateAverageReturn($days = null)
    {
        $dateFilter = $days ? "AND DATE(executed_at) >= DATE_SUB(CURDATE(), INTERVAL ? DAY)" : "";

        $sql = "
            SELECT 
                AVG(pnl) as avg_pnl,
                AVG(pnl_pct) as avg_pnl_pct,
                SUM(pnl) as total_pnl,
                COUNT(*) as trade_count
            FROM trade_executions
            WHERE execution_status = 'filled'
            AND pnl IS NOT NULL
            $dateFilter
        ";

        $stmt = $this->db->prepare($sql);
        if ($days) {
            $stmt->execute([$days]);
        } else {
            $stmt->execute();
        }

        $result = $stmt->fetch();

        return [
            'avg_pnl' => round($result['avg_pnl'] ?? 0, 2),
            'avg_pnl_pct' => round($result['avg_pnl_pct'] ?? 0, 2),
            'total_pnl' => round($result['total_pnl'] ?? 0, 2),
            'trade_count' => (int)$result['trade_count']
        ];
    }

    /**
     * Calculate Sharpe Ratio (risk-adjusted return)
     * Sharpe = (Average Return - Risk-Free Rate) / Standard Deviation of Returns
     */
    public function calculateSharpeRatio($riskFreeRate = 0.02)
    {
        // Get daily returns from performance_metrics
        $sql = "
            SELECT daily_return
            FROM performance_metrics
            WHERE daily_return IS NOT NULL
            ORDER BY date DESC
            LIMIT 252
        ";

        $stmt = $this->db->query($sql);
        $returns = $stmt->fetchAll(PDO::FETCH_COLUMN);

        if (count($returns) < 2) {
            return null; // Not enough data
        }

        $avgReturn = array_sum($returns) / count($returns);
        $stdDev = $this->calculateStandardDeviation($returns);

        if ($stdDev == 0) {
            return null;
        }

        // Annualize the Sharpe ratio (assuming 252 trading days)
        $dailyRiskFreeRate = $riskFreeRate / 252;
        $sharpeRatio = (($avgReturn - $dailyRiskFreeRate) / $stdDev) * sqrt(252);

        return round($sharpeRatio, 2);
    }

    /**
     * Calculate standard deviation of returns
     */
    private function calculateStandardDeviation($values)
    {
        $count = count($values);
        if ($count < 2) {
            return 0;
        }

        $mean = array_sum($values) / $count;
        $variance = array_sum(array_map(function ($x) use ($mean) {
            return pow($x - $mean, 2);
        }, $values)) / ($count - 1);

        return sqrt($variance);
    }

    /**
     * Get drawdown history for visualization
     */
    public function getDrawdownHistory($days = 90)
    {
        $sql = "
            SELECT 
                date,
                equity,
                drawdown_pct
            FROM performance_metrics
            WHERE date >= DATE_SUB(CURDATE(), INTERVAL ? DAY)
            ORDER BY date ASC
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([$days]);

        return $stmt->fetchAll();
    }

    /**
     * Update daily performance metrics
     * Should be called at end of each trading day
     */
    public function updateDailyMetrics($equity)
    {
        $today = date('Y-m-d');

        // Get yesterday's equity for return calculation
        $stmt = $this->db->prepare("
            SELECT equity FROM performance_metrics 
            WHERE date < ? 
            ORDER BY date DESC 
            LIMIT 1
        ");
        $stmt->execute([$today]);
        $yesterday = $stmt->fetch();

        $dailyReturn = 0;
        if ($yesterday && $yesterday['equity'] > 0) {
            $dailyReturn = (($equity - $yesterday['equity']) / $yesterday['equity']) * 100;
        }

        // Calculate cumulative return from initial equity
        $stmt = $this->db->query("
            SELECT equity FROM performance_metrics 
            ORDER BY date ASC 
            LIMIT 1
        ");
        $initial = $stmt->fetch();

        $cumulativeReturn = 0;
        if ($initial && $initial['equity'] > 0) {
            $cumulativeReturn = (($equity - $initial['equity']) / $initial['equity']) * 100;
        }

        // Calculate drawdown
        $stmt = $this->db->query("
            SELECT MAX(equity) as peak_equity 
            FROM performance_metrics
        ");
        $peak = $stmt->fetch();
        $peakEquity = max($peak['peak_equity'] ?? $equity, $equity);

        $drawdownPct = $peakEquity > 0 ? (($equity - $peakEquity) / $peakEquity) * 100 : 0;

        // Get today's trade stats
        $stmt = $this->db->query("
            SELECT 
                COUNT(*) as trades_count,
                SUM(CASE WHEN pnl > 0 THEN 1 ELSE 0 END) as wins_count,
                SUM(CASE WHEN pnl < 0 THEN 1 ELSE 0 END) as losses_count,
                SUM(pnl) as total_pnl
            FROM trade_executions
            WHERE DATE(executed_at) = CURDATE()
            AND execution_status = 'filled'
        ");
        $trades = $stmt->fetch();

        // Insert or update today's metrics
        $sql = "
            INSERT INTO performance_metrics (
                date, equity, daily_return, cumulative_return, drawdown_pct,
                trades_count, wins_count, losses_count, total_pnl
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                equity = VALUES(equity),
                daily_return = VALUES(daily_return),
                cumulative_return = VALUES(cumulative_return),
                drawdown_pct = VALUES(drawdown_pct),
                trades_count = VALUES(trades_count),
                wins_count = VALUES(wins_count),
                losses_count = VALUES(losses_count),
                total_pnl = VALUES(total_pnl)
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            $today,
            $equity,
            $dailyReturn,
            $cumulativeReturn,
            $drawdownPct,
            $trades['trades_count'] ?? 0,
            $trades['wins_count'] ?? 0,
            $trades['losses_count'] ?? 0,
            $trades['total_pnl'] ?? 0
        ]);

        return ['success' => true];
    }

    /**
     * Get comprehensive performance analytics
     */
    public function getPerformanceAnalytics()
    {
        return [
            'win_loss' => [
                'all_time' => $this->calculateWinLossRatio(),
                'last_30_days' => $this->calculateWinLossRatio(30),
                'last_7_days' => $this->calculateWinLossRatio(7)
            ],
            'average_return' => [
                'all_time' => $this->calculateAverageReturn(),
                'last_30_days' => $this->calculateAverageReturn(30),
                'last_7_days' => $this->calculateAverageReturn(7)
            ],
            'risk_adjusted' => [
                'sharpe_ratio' => $this->calculateSharpeRatio()
            ],
            'drawdown_history' => $this->getDrawdownHistory(90)
        ];
    }
}
