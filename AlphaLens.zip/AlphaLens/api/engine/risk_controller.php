<?php

/**
 * Risk Controller for AlphaLens AI
 * RISK-FIRST GUARDIAN LAYER - Can veto ANY trade
 * AI cannot override these risk controls
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../api/trading/alpaca_client.php';

class RiskController
{
    private $db;
    private $rules;
    private $alpacaClient;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
        $this->alpacaClient = new AlpacaClient();
        $this->loadRiskRules();
    }

    /**
     * Load active risk rules from database
     */
    private function loadRiskRules()
    {
        $stmt = $this->db->query("
            SELECT rule_name, rule_value, rule_unit 
            FROM risk_rules 
            WHERE is_active = TRUE
        ");

        $this->rules = [];
        while ($row = $stmt->fetch()) {
            $this->rules[$row['rule_name']] = [
                'value' => $row['rule_value'],
                'unit' => $row['rule_unit']
            ];
        }
    }

    /**
     * Validate signal against ALL risk controls
     * Returns approval or veto with detailed reasoning
     * 
     * @param int $signalId Trade signal ID
     * @return array Risk check result
     */
    public function checkRisk($signalId, $isJit = false)
    {
        // Check if global risk controls are enabled
        if (!$this->isRiskControlEnabled()) {
            return [
                'approved' => true,
                'reason' => 'Global risk controls disabled',
                'checks' => []
            ];
        }

        $signal = $this->getSignal($signalId);

        if (!$signal) {
            return [
                'approved' => false,
                'reason' => 'Signal not found'
            ];
        }

        $checks = [];
        $approved = true;
        $vetoReason = null;

        // RISK CHECK 1: Position Size Limit
        $positionSizeCheck = $this->checkPositionSize($signal);
        $positionSizeCheck['name'] = 'Position Size Limit';
        $checks[] = $positionSizeCheck;
        if (!$positionSizeCheck['passed']) {
            $approved = false;
            $vetoReason = $positionSizeCheck['reason'];
        }

        // RISK CHECK 2: Portfolio Exposure Limit
        $exposureCheck = $this->checkPortfolioExposure($signal);
        $exposureCheck['name'] = 'Portfolio Exposure Limit';
        $checks[] = $exposureCheck;
        if (!$exposureCheck['passed']) {
            $approved = false;
            $vetoReason = $vetoReason ?? $exposureCheck['reason'];
        }

        // RISK CHECK 3: Daily Drawdown Limit
        $dailyDrawdownCheck = $this->checkDailyDrawdown();
        $dailyDrawdownCheck['name'] = 'Daily Drawdown Limit';
        $checks[] = $dailyDrawdownCheck;
        if (!$dailyDrawdownCheck['passed']) {
            $approved = false;
            $vetoReason = $vetoReason ?? $dailyDrawdownCheck['reason'];
        }

        // RISK CHECK 4: Cumulative Drawdown Limit
        $cumulativeDrawdownCheck = $this->checkCumulativeDrawdown();
        $cumulativeDrawdownCheck['name'] = 'Cumulative Drawdown Limit';
        $checks[] = $cumulativeDrawdownCheck;
        if (!$cumulativeDrawdownCheck['passed']) {
            $approved = false;
            $vetoReason = $vetoReason ?? $cumulativeDrawdownCheck['reason'];
        }

        // RISK CHECK 5: Cooldown Period After Loss
        $cooldownCheck = $this->checkCooldownPeriod();
        $cooldownCheck['name'] = 'Cooldown Period';
        $checks[] = $cooldownCheck;
        if (!$cooldownCheck['passed']) {
            $approved = false;
            $vetoReason = $vetoReason ?? $cooldownCheck['reason'];
        }

        // RISK CHECK 6: Maximum Concurrent Positions
        $concurrentCheck = $this->checkConcurrentPositions();
        $concurrentCheck['name'] = 'Max Concurrent Positions';
        $checks[] = $concurrentCheck;
        if (!$concurrentCheck['passed']) {
            $approved = false;
            $vetoReason = $vetoReason ?? $concurrentCheck['reason'];
        }

        // RISK CHECK 7: Sector Concentration Limit
        $sectorCheck = $this->checkSectorConcentration($signal);
        $sectorCheck['name'] = 'Sector Concentration';
        $checks[] = $sectorCheck;
        if (!$sectorCheck['passed']) {
            $approved = false;
            $vetoReason = $vetoReason ?? $sectorCheck['reason'];
        }

        // RISK CHECK 8: Volatility Spike Filter
        $volatilityCheck = $this->checkVolatilitySpike($signal);
        $volatilityCheck['name'] = 'Volatility Spike Filter';
        $checks[] = $volatilityCheck;
        if (!$volatilityCheck['passed']) {
            $approved = false;
            $vetoReason = $vetoReason ?? $volatilityCheck['reason'];
        }

        // RISK CHECK 9: Earnings Window Filters
        $earningsCheck = $this->checkEarningsFilters($signal);
        $earningsCheck['name'] = 'Earnings Window Filter';
        $checks[] = $earningsCheck;
        if (!$earningsCheck['passed']) {
            $approved = false;
            $vetoReason = $vetoReason ?? $earningsCheck['reason'];
        }

        // Update signal risk validation status
        $this->updateRiskValidation($signalId, $approved, $checks, $vetoReason, $isJit);

        // Log decision
        $this->logDecision(
            $signal['ticker'],
            'risk_check',
            $approved ? 'approved' : 'rejected',
            $approved ? 'All risk checks passed' : "RISK VETO: $vetoReason",
            ['checks' => $checks],
            $signalId
        );

        return [
            'approved' => $approved,
            'veto_reason' => $vetoReason,
            'checks' => $checks,
            'summary' => $this->generateSummary($checks)
        ];
    }

    /**
     * RISK CHECK 1: Position size must not exceed maximum
     */
    private function checkPositionSize($signal)
    {
        $maxPositionPct = $this->rules['max_position_size_pct']['value'];
        $portfolioValue = $this->getPortfolioValue();
        $maxPositionValue = ($portfolioValue * $maxPositionPct) / 100;

        $proposedValue = $signal['suggested_position_size'];
        $positionPct = ($proposedValue / $portfolioValue) * 100;

        $passed = $proposedValue <= $maxPositionValue;

        return [
            'check_name' => 'Position Size Limit',
            'passed' => $passed,
            'reason' => $passed ? null : "Position size {$positionPct}% exceeds maximum {$maxPositionPct}%",
            'details' => [
                'proposed_value' => $proposedValue,
                'max_value' => $maxPositionValue,
                'proposed_pct' => round($positionPct, 2),
                'max_pct' => $maxPositionPct
            ],
            'severity' => 'critical'
        ];
    }

    /**
     * RISK CHECK 2: Total portfolio exposure must not exceed limit
     */
    private function checkPortfolioExposure($signal)
    {
        $maxExposurePct = $this->rules['max_portfolio_exposure_pct']['value'];
        $portfolioValue = $this->getPortfolioValue();

        // Get current exposure
        $currentExposure = $this->getCurrentExposure();
        $proposedExposure = $currentExposure + $signal['suggested_position_size'];
        $exposurePct = ($proposedExposure / $portfolioValue) * 100;

        $passed = $exposurePct <= $maxExposurePct;

        return [
            'check_name' => 'Portfolio Exposure Limit',
            'passed' => $passed,
            'reason' => $passed ? null : "Total exposure {$exposurePct}% would exceed maximum {$maxExposurePct}%",
            'details' => [
                'current_exposure' => $currentExposure,
                'proposed_exposure' => $proposedExposure,
                'exposure_pct' => round($exposurePct, 2),
                'max_pct' => $maxExposurePct
            ],
            'severity' => 'critical'
        ];
    }

    /**
     * RISK CHECK 3: Daily drawdown must not exceed limit
     */
    private function checkDailyDrawdown()
    {
        $maxDailyDrawdownPct = $this->rules['max_daily_drawdown_pct']['value'];

        // Get today's P&L
        $todayMetrics = $this->getTodayMetrics();
        $dailyDrawdownPct = abs($todayMetrics['daily_pnl_pct'] ?? 0);

        $passed = $dailyDrawdownPct < $maxDailyDrawdownPct;

        if (!$passed) {
            $this->haltSystem("Daily drawdown limit exceeded: {$dailyDrawdownPct}% (Limit: {$maxDailyDrawdownPct}%)");
        }

        return [
            'check_name' => 'Daily Drawdown Limit',
            'passed' => $passed,
            'reason' => $passed ? null : "Daily drawdown {$dailyDrawdownPct}% exceeds maximum {$maxDailyDrawdownPct}%",
            'details' => [
                'current_drawdown_pct' => $dailyDrawdownPct,
                'max_drawdown_pct' => $maxDailyDrawdownPct
            ],
            'severity' => 'critical'
        ];
    }

    /**
     * RISK CHECK 4: Cumulative drawdown must not exceed limit
     */
    private function checkCumulativeDrawdown()
    {
        $maxCumulativeDrawdownPct = $this->rules['max_cumulative_drawdown_pct']['value'];

        $metrics = $this->getLatestMetrics();
        $currentDrawdownPct = abs($metrics['current_drawdown_pct'] ?? 0);

        $passed = $currentDrawdownPct < $maxCumulativeDrawdownPct;

        if (!$passed) {
            $this->haltSystem("Cumulative drawdown ceiling breached: {$currentDrawdownPct}% (Limit: {$maxCumulativeDrawdownPct}%)");
        }

        return [
            'check_name' => 'Cumulative Drawdown Limit',
            'passed' => $passed,
            'reason' => $passed ? null : "Cumulative drawdown {$currentDrawdownPct}% exceeds maximum {$maxCumulativeDrawdownPct}%",
            'details' => [
                'current_drawdown_pct' => $currentDrawdownPct,
                'max_drawdown_pct' => $maxCumulativeDrawdownPct
            ],
            'severity' => 'critical'
        ];
    }

    /**
     * RISK CHECK 5: Cooldown period after losing trade
     */
    private function checkCooldownPeriod()
    {
        $cooldownHours = $this->rules['cooldown_hours_after_loss']['value'];

        // Get last losing trade
        $stmt = $this->db->query("
            SELECT executed_at 
            FROM trade_executions 
            WHERE pnl < 0 
            ORDER BY executed_at DESC 
            LIMIT 1
        ");
        $lastLoss = $stmt->fetch();

        if (!$lastLoss) {
            return [
                'check_name' => 'Cooldown Period',
                'passed' => true,
                'reason' => null,
                'details' => ['status' => 'No recent losses'],
                'severity' => 'medium'
            ];
        }

        $hoursSinceLoss = (time() - strtotime($lastLoss['executed_at'])) / 3600;
        $passed = $hoursSinceLoss >= $cooldownHours;

        return [
            'check_name' => 'Cooldown Period',
            'passed' => $passed,
            'reason' => $passed ? null : "Cooldown period active: " . round($cooldownHours - $hoursSinceLoss, 1) . " hours remaining",
            'details' => [
                'hours_since_loss' => round($hoursSinceLoss, 1),
                'required_hours' => $cooldownHours
            ],
            'severity' => 'medium'
        ];
    }

    /**
     * RISK CHECK 7: Sector concentration must not exceed limit
     */
    private function checkSectorConcentration($signal)
    {
        $maxSectorPct = $this->rules['max_sector_concentration_pct']['value'] ?? 25.0;
        $portfolioValue = $this->getPortfolioValue();

        $sector = $this->getSector($signal['ticker']);
        if ($sector === 'Other') {
            return [
                'check_name' => 'Sector Concentration',
                'passed' => true,
                'reason' => null,
                'details' => ['sector' => 'Other', 'status' => 'No restrictions for unknown sectors'],
                'severity' => 'low'
            ];
        }

        $currentSectorExposure = $this->getSectorExposure($sector);
        $proposedSectorExposure = $currentSectorExposure + $signal['suggested_position_size'];
        $sectorPct = ($proposedSectorExposure / $portfolioValue) * 100;

        $passed = $sectorPct <= $maxSectorPct;

        return [
            'check_name' => 'Sector Concentration',
            'passed' => $passed,
            'reason' => $passed ? null : "Sector concentration in '$sector' ({$sectorPct}%) would exceed maximum {$maxSectorPct}%",
            'details' => [
                'sector' => $sector,
                'current_exposure' => $currentSectorExposure,
                'proposed_exposure' => $proposedSectorExposure,
                'exposure_pct' => round($sectorPct, 2),
                'max_pct' => $maxSectorPct
            ],
            'severity' => 'high'
        ];
    }

    /**
     * Helper: Get sector for ticker
     */
    private function getSector($ticker)
    {
        // Re-use logic from RuleValidator (or move to common helper)
        $map = [
            'AAPL' => 'Technology',
            'MSFT' => 'Technology',
            'NVDA' => 'Technology',
            'JPM' => 'Finance',
            'BAC' => 'Finance',
            'PFE' => 'Healthcare',
            'JNJ' => 'Healthcare',
            'XOM' => 'Energy',
            'SPY' => 'ETF',
            'QQQ' => 'ETF',
            'TQQQ' => 'ETF'
        ];
        return $map[$ticker] ?? 'Other';
    }

    /**
     * Helper: Get total exposure for a specific sector
     */
    private function getSectorExposure($sector)
    {
        // We need to correlate current positions with their sectors
        $stmt = $this->db->query("SELECT ticker, market_value FROM positions WHERE quantity != 0");
        $total = 0;
        while ($row = $stmt->fetch()) {
            if ($this->getSector($row['ticker']) === $sector) {
                // Use ABS() because short positions (negative market value) still count towards exposure risk
                $total += abs($row['market_value']);
            }
        }
        return $total;
    }

    /**
     * RISK CHECK 6: Maximum concurrent positions
     */
    private function checkConcurrentPositions()
    {
        $stmt = $this->db->query("
            SELECT config_value 
            FROM system_config 
            WHERE config_key = 'max_concurrent_positions'
        ");
        $config = $stmt->fetch();
        $maxPositions = $config ? (int)$config['config_value'] : 5;

        $currentPositions = $this->getOpenPositionsCount();
        $passed = $currentPositions < $maxPositions;

        return [
            'check_name' => 'Concurrent Positions Limit',
            'passed' => $passed,
            'reason' => $passed ? null : "Maximum concurrent positions ({$maxPositions}) reached",
            'details' => [
                'current_positions' => $currentPositions,
                'max_positions' => $maxPositions
            ],
            'severity' => 'high'
        ];
    }

    /**
     * Helper: Get portfolio value
     */
    private function getPortfolioValue()
    {
        // In production, fetch from Alpaca API
        // For now, use default from config
        $stmt = $this->db->query("
            SELECT config_value 
            FROM system_config 
            WHERE config_key = 'default_portfolio_value'
        ");
        $config = $stmt->fetch();
        return $config ? (float)$config['config_value'] : 100000;
    }

    /**
     * Helper: Get current exposure
     */
    private function getCurrentExposure()
    {
        $stmt = $this->db->query("
            SELECT COALESCE(SUM(ABS(market_value)), 0) as total_exposure 
            FROM positions 
            WHERE quantity != 0
        ");
        $result = $stmt->fetch();
        return $result['total_exposure'];
    }

    /**
     * Helper: Get today's metrics
     */
    private function getTodayMetrics()
    {
        $stmt = $this->db->prepare("
            SELECT * FROM risk_metrics 
            WHERE metric_date = CURDATE()
        ");
        $stmt->execute();
        return $stmt->fetch() ?: [];
    }

    /**
     * Helper: Get latest metrics
     */
    private function getLatestMetrics()
    {
        $stmt = $this->db->query("
            SELECT * FROM risk_metrics 
            ORDER BY metric_date DESC 
            LIMIT 1
        ");
        return $stmt->fetch() ?: [];
    }

    /**
     * Helper: Get open positions count
     */
    private function getOpenPositionsCount()
    {
        $stmt = $this->db->query("
            SELECT COUNT(*) as count 
            FROM positions 
            WHERE quantity != 0
        ");
        $result = $stmt->fetch();
        return $result['count'];
    }

    /**
     * Get signal details
     */
    private function getSignal($signalId)
    {
        $stmt = $this->db->prepare("SELECT * FROM trade_signals WHERE id = ?");
        $stmt->execute([$signalId]);
        return $stmt->fetch();
    }

    /**
     * Update risk validation status
     */
    private function updateRiskValidation($signalId, $approved, $checks, $vetoReason, $isJit = false)
    {
        $status = $approved ? 'approved' : ($isJit ? 'vetoed_by_risk_jit' : 'rejected');
        $notes = json_encode([
            'checks' => $checks,
            'veto_reason' => $vetoReason
        ]);

        // Also update final status if rejected
        $finalStatus = $approved ? 'approved' : ($isJit ? 'vetoed_by_risk_jit' : 'rejected');

        $riskCheckResults = json_encode($checks);

        $stmt = $this->db->prepare("
            UPDATE trade_signals 
            SET risk_validation_status = ?,
                risk_validation_notes = ?,
                risk_check_results = ?,
                final_status = ?
            WHERE id = ?
        ");
        $stmt->execute([$status, $notes, $riskCheckResults, $finalStatus, $signalId]);
    }

    /**
     * Generate summary
     */
    private function generateSummary($checks)
    {
        $passed = array_filter($checks, fn($c) => $c['passed']);
        $failed = array_filter($checks, fn($c) => !$c['passed']);

        return [
            'total_checks' => count($checks),
            'passed' => count($passed),
            'failed' => count($failed),
            'critical_failures' => count(array_filter($failed, fn($c) => $c['severity'] === 'critical'))
        ];
    }

    /**
     * Log decision
     */
    private function logDecision($ticker, $type, $outcome, $reason, $data, $signalId = null)
    {
        $stmt = $this->db->prepare("
            INSERT INTO decision_logs (
                ticker, decision_type, decision_outcome, decision_reason, 
                decision_data, related_signal_id
            ) VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $ticker,
            $type,
            $outcome,
            $reason,
            json_encode($data),
            $signalId
        ]);
    }
    /**
     * Update/Calculate Risk Metrics (Daily P&L, Drawdown)
     * Called by Dashboard or scheduled task
     */
    public function updateRiskMetrics($currentEquity)
    {
        $today = date('Y-m-d');

        // 1. Get previous day record for baseline
        $stmt = $this->db->prepare("
            SELECT * FROM risk_metrics 
            WHERE metric_date < ? 
            ORDER BY metric_date DESC 
            LIMIT 1
        ");
        $stmt->execute([$today]);
        $prevMetric = $stmt->fetch();

        // 2. Determine baselines
        $startOfDayEquity = $prevMetric ? $prevMetric['total_portfolio_value'] : $currentEquity;

        // Load initial peak from config if no history
        $portfolioValue = $this->getPortfolioValue();
        $peakEquity = $prevMetric ? max($prevMetric['peak_equity'], $currentEquity) : max($portfolioValue, $currentEquity);
        $initialCapital = $portfolioValue;

        // 3. Calculate Metrics
        $dailyPnl = $currentEquity - $startOfDayEquity;
        $dailyPnlPct = $startOfDayEquity > 0 ? ($dailyPnl / $startOfDayEquity) * 100 : 0;

        $cumulativePnl = $currentEquity - $initialCapital;
        $cumulativePnlPct = ($cumulativePnl / $initialCapital) * 100;

        $drawdownPct = $peakEquity > 0 ? (($peakEquity - $currentEquity) / $peakEquity) * 100 : 0;

        // 4. Upsert into database
        $stmt = $this->db->prepare("
            INSERT INTO risk_metrics (
                metric_date, total_portfolio_value, daily_pnl, daily_pnl_pct,
                cumulative_pnl, cumulative_pnl_pct, current_drawdown_pct, peak_equity
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                total_portfolio_value = VALUES(total_portfolio_value),
                daily_pnl = VALUES(daily_pnl),
                daily_pnl_pct = VALUES(daily_pnl_pct),
                cumulative_pnl = VALUES(cumulative_pnl),
                cumulative_pnl_pct = VALUES(cumulative_pnl_pct),
                current_drawdown_pct = VALUES(current_drawdown_pct),
                peak_equity = VALUES(peak_equity)
        ");

        $stmt->execute([
            $today,
            $currentEquity,
            $dailyPnl,
            $dailyPnlPct,
            $cumulativePnl,
            $cumulativePnlPct,
            $drawdownPct,
            $peakEquity
        ]);

        return [
            'daily_pnl' => $dailyPnl,
            'daily_pnl_pct' => $dailyPnlPct,
            'cumulative_pnl' => $cumulativePnl,
            'cumulative_pnl_pct' => $cumulativePnlPct,
            'max_drawdown_pct' => $drawdownPct
        ];
    }

    /**
     * Globally halt trading (Circuit Breaker)
     */
    private function haltSystem($reason)
    {
        // 1. Set halt flag in DB
        $stmt = $this->db->prepare("
            UPDATE system_config 
            SET config_value = 'true' 
            WHERE config_key = 'system_halted'
        ");
        $stmt->execute();

        // 2. Log a critical audit event
        $this->logDecision(
            'SYSTEM',
            'manual_override',
            'rejected',
            "CRITICAL: System halted due to: $reason",
            ['halt_trigger' => $reason],
            null
        );

        return true;
    }

    /**
     * RISK CHECK 8: Volatility Spike Filter
     * Veto if current ATR (3-day) > threshold * historical ATR (20-day)
     */
    private function checkVolatilitySpike($signal)
    {
        $threshold = $this->rules['volatility_spike_threshold']['value'] ?? 2.0;
        $ticker = $signal['ticker'];

        // Get 25 days of bars to calculate both short and long ATR
        $barResult = $this->alpacaClient->getBars($ticker, 25);
        if (!$barResult['success'] || !isset($barResult['data']['bars']) || count($barResult['data']['bars']) < 21) {
            return [
                'check_name' => 'Volatility Spike',
                'passed' => true, // Fallback: allow if data missing
                'reason' => null,
                'details' => ['status' => 'Insufficient data for volatility calculation'],
                'severity' => 'low'
            ];
        }

        $bars = $barResult['data']['bars'];
        $trueRanges = [];
        for ($i = 1; $i < count($bars); $i++) {
            $h = $bars[$i]['h'];
            $l = $bars[$i]['l'];
            $pc = $bars[$i - 1]['c'];
            $trueRanges[] = max($h - $l, abs($h - $pc), abs($l - $pc));
        }

        // Calculate Long-term ATR (20-day)
        $historicalATR = array_sum(array_slice($trueRanges, -20)) / 20;

        // Calculate Short-term ATR (3-day)
        $currentATR = array_sum(array_slice($trueRanges, -3)) / 3;

        if ($historicalATR <= 0) {
            return [
                'check_name' => 'Volatility Spike',
                'passed' => true,
                'reason' => null,
                'severity' => 'low'
            ];
        }

        $ratio = $currentATR / $historicalATR;
        $passed = $ratio <= $threshold;

        return [
            'check_name' => 'Volatility Spike',
            'passed' => $passed,
            'reason' => $passed ? null : "Extreme volatility spike detected: {$ratio}x historical average (Limit: {$threshold}x)",
            'details' => [
                'current_atr' => round($currentATR, 2),
                'historical_atr' => round($historicalATR, 2),
                'spike_ratio' => round($ratio, 2),
                'max_ratio' => $threshold
            ],
            'severity' => 'high'
        ];
    }

    /**
     * RISK CHECK 9: Earnings Window Filters
     * Veto if trade is too close to an earnings announcement
     */
    private function checkEarningsFilters($signal)
    {
        $preBuffer = $this->rules['pre_earnings_buffer_days']['value'] ?? 3;
        $postWait = $this->rules['post_earnings_wait_days']['value'] ?? 1;
        $ticker = $signal['ticker'];

        // 1. Check for PRE-EARNINGS window
        $stmt = $this->db->prepare("
            SELECT earnings_date 
            FROM earnings_transcripts 
            WHERE ticker = ? AND earnings_date > NOW()
            ORDER BY earnings_date ASC LIMIT 1
        ");
        $stmt->execute([$ticker]);
        $upcoming = $stmt->fetch();

        if ($upcoming) {
            $daysToEarnings = (strtotime($upcoming['earnings_date']) - time()) / 86400;
            if ($daysToEarnings <= $preBuffer) {
                return [
                    'check_name' => 'Earnings Filter (Pre)',
                    'passed' => false,
                    'reason' => "Ticker '$ticker' has earnings in " . round($daysToEarnings, 1) . " days (Buffer: $preBuffer)",
                    'details' => ['earnings_date' => $upcoming['earnings_date']],
                    'severity' => 'high'
                ];
            }
        }

        // 2. Check for POST-EARNINGS window 
        // We only enforce this if the signal source is NEWS (not earnings itself)
        $stmt = $this->db->prepare("
            SELECT source_type FROM ai_sentiment_analysis WHERE id = ?
        ");
        $stmt->execute([$signal['sentiment_analysis_id']]);
        $sourceType = $stmt->fetchColumn();

        if ($sourceType === 'news') {
            $stmt = $this->db->prepare("
                SELECT earnings_date 
                FROM earnings_transcripts 
                WHERE ticker = ? AND earnings_date < NOW()
                ORDER BY earnings_date DESC LIMIT 1
            ");
            $stmt->execute([$ticker]);
            $recent = $stmt->fetch();

            if ($recent) {
                $daysSinceEarnings = (time() - strtotime($recent['earnings_date'])) / 86400;
                if ($daysSinceEarnings < $postWait) {
                    $lastEarnings = round($daysSinceEarnings, 1);
                    return [
                        'check_name' => 'Earnings Filter (Post)',
                        'passed' => false,
                        'reason' => "Waiting for post-earnings dust to settle. Last earnings was {$lastEarnings} days ago (Wait: $postWait)",
                        'details' => ['last_earnings_date' => $recent['earnings_date']],
                        'severity' => 'medium'
                    ];
                }
            }
        }

        return [
            'check_name' => 'Earnings Window',
            'passed' => true,
            'reason' => null,
            'details' => ['status' => 'Outside restricted earnings windows'],
            'severity' => 'low'
        ];
    }

    private function isRiskControlEnabled()
    {
        $stmt = $this->db->prepare("SELECT config_value FROM system_config WHERE config_key = 'risk_controls_enabled'");
        $stmt->execute();
        $val = $stmt->fetchColumn();
        return $val === 'true' || $val === '1' || $val === true;
    }
}
