<?php

/**
 * Exit Manager for AlphaLens AI
 * Monitors open positions for Stop Loss and Take Profit triggers locally
 * Feature 4.4: Portfolio Rebalancing
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../trading/trade_executor.php';
require_once __DIR__ . '/../trading/position_manager.php';

class ExitManager
{
    private $db;
    private $tradeExecutor;
    private $positionManager;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
        $this->tradeExecutor = new TradeExecutor();
        $this->positionManager = new PositionManager();
    }

    /**
     * Run checks for all open positions
     */
    public function runChecks()
    {
        $results = [
            'exit_triggers' => 0,
            'errors' => []
        ];

        try {
            // First, sync positions from Alpaca to get latest prices
            $this->positionManager->syncPositions();

            $positions = $this->positionManager->getOpenPositions();

            foreach ($positions as $pos) {
                $trigger = $this->checkPosition($pos);
                if ($trigger['triggered']) {
                    $this->executeExit($pos, $trigger['reason']);
                    $results['exit_triggers']++;
                }
            }
        } catch (Exception $e) {
            $results['errors'][] = $e->getMessage();
        }

        return $results;
    }

    /**
     * Check if a single position has hit SL or TP
     */
    private function checkPosition($pos)
    {
        $ticker = $pos['ticker'];
        $currentPrice = (float)$pos['current_price'];
        $qty = (float)$pos['quantity'];
        $sl = (float)$pos['stop_loss'];
        $tp = (float)$pos['take_profit'];

        if ($qty > 0) {
            // Long position
            if ($sl > 0 && $currentPrice <= $sl) {
                return ['triggered' => true, 'reason' => "STOP LOSS HIT: Live price ($$currentPrice) <= SL ($$sl)"];
            }
            if ($tp > 0 && $currentPrice >= $tp) {
                return ['triggered' => true, 'reason' => "TAKE PROFIT HIT: Live price ($$currentPrice) >= TP ($$tp)"];
            }
        } elseif ($qty < 0) {
            // Short position (not fully supported by AlphaLens yet but good to have)
            if ($sl > 0 && $currentPrice >= $sl) {
                return ['triggered' => true, 'reason' => "STOP LOSS HIT (SHORT): Live price ($$currentPrice) >= SL ($$sl)"];
            }
            if ($tp > 0 && $currentPrice <= $tp) {
                return ['triggered' => true, 'reason' => "TAKE PROFIT HIT (SHORT): Live price ($$currentPrice) <= TP ($$tp)"];
            }
        }

        return ['triggered' => false];
    }

    /**
     * Execute a market exit for a triggered position
     */
    private function executeExit($position, $reason)
    {
        $qty = $position['quantity'];
        $side = $qty > 0 ? 'sell' : 'buy';
        $absQty = abs($qty);

        // 1. Create an "automated exit" signal
        $stmt = $this->db->prepare("
            INSERT INTO trade_signals (
                ticker, signal_type, ai_confidence, trade_thesis, 
                suggested_position_size, suggested_entry_price, 
                final_status, created_at
            ) VALUES (?, ?, 100, ?, 0.0, ?, 'approved', NOW())
        ");

        $thesis = "🤖 AUTO-EXIT TRIGGERED: $reason. Closing $absQty shares.";

        $stmt->execute([
            $position['ticker'],
            $side,
            $thesis,
            $position['current_price']
        ]);

        $signalId = $this->db->lastInsertId();

        // 2. Execute via Trade Executor (it will calculate delta -> 0)
        $this->tradeExecutor->executeSignal($signalId);
    }
}
