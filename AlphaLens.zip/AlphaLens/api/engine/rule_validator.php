<?php

/**
 * Rule Validator for AlphaLens AI
 * Validates AI-generated signals against trading rules
 * AI outputs must pass these deterministic checks
 */

require_once __DIR__ . '/../../config/database.php';

class RuleValidator
{
    private $db;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Validate a trade signal against all trading rules
     * 
     * @param int $signalId Trade signal ID
     * @return array Validation result
     */
    public function validateSignal($signalId)
    {
        // Get signal details
        $signal = $this->getSignal($signalId);

        if (!$signal) {
            return [
                'passed' => false,
                'reason' => 'Signal not found'
            ];
        }

        $checks = [];
        $allPassed = true;

        // Check 1: Confidence threshold
        $confidenceCheck = $this->checkConfidenceThreshold($signal);
        $checks[] = $confidenceCheck;
        if (!$confidenceCheck['passed']) $allPassed = false;

        // Check 2: Event window validation
        $eventCheck = $this->checkEventWindow($signal);
        $checks[] = $eventCheck;
        if (!$eventCheck['passed']) $allPassed = false;

        // Check 3: Liquidity check
        $liquidityCheck = $this->checkLiquidity($signal);
        $checks[] = $liquidityCheck;
        if (!$liquidityCheck['passed']) $allPassed = false;

        // Check 4: Signal quality
        $qualityCheck = $this->checkSignalQuality($signal);
        $checks[] = $qualityCheck;
        if (!$qualityCheck['passed']) $allPassed = false;

        // Check 5: Asset Group Whitelist
        $groupCheck = $this->checkAssetGroup($signal);
        $checks[] = $groupCheck;
        if (!$groupCheck['passed']) $allPassed = false;

        // Update signal status
        $this->updateSignalValidation($signalId, $allPassed, $checks);

        // Log decision
        $this->logDecision(
            $signal['ticker'],
            'rule_validation',
            $allPassed ? 'approved' : 'rejected',
            $allPassed ? 'All rule checks passed' : 'One or more rule checks failed',
            ['checks' => $checks],
            $signalId
        );

        return [
            'passed' => $allPassed,
            'checks' => $checks,
            'summary' => $this->generateSummary($checks)
        ];
    }

    /**
     * Check if AI confidence meets minimum threshold
     */
    private function checkConfidenceThreshold($signal)
    {
        $minConfidence = 60; // Minimum 60% confidence required

        $passed = $signal['ai_confidence'] >= $minConfidence;

        return [
            'check_name' => 'Confidence Threshold',
            'passed' => $passed,
            'details' => "AI confidence: {$signal['ai_confidence']}%, Required: {$minConfidence}%",
            'severity' => 'high'
        ];
    }

    /**
     * Check if signal is within allowed event window
     * Only trade around earnings/news events
     */
    private function checkEventWindow($signal)
    {
        // Get sentiment analysis source
        $stmt = $this->db->prepare("
            SELECT source_type, analyzed_at 
            FROM ai_sentiment_analysis 
            WHERE id = ?
        ");
        $stmt->execute([$signal['sentiment_analysis_id']]);
        $analysis = $stmt->fetch();

        if (!$analysis) {
            return [
                'check_name' => 'Event Window',
                'passed' => false,
                'details' => 'No sentiment analysis found',
                'severity' => 'high'
            ];
        }

        // Check if analysis is recent (within 48 hours)
        $analysisTime = strtotime($analysis['analyzed_at']);
        $currentTime = time();
        $hoursSinceAnalysis = ($currentTime - $analysisTime) / 3600;

        $passed = $hoursSinceAnalysis <= 48;

        return [
            'check_name' => 'Event Window',
            'passed' => $passed,
            'details' => "Analysis age: " . round($hoursSinceAnalysis, 1) . " hours (max 48 hours)",
            'severity' => 'medium'
        ];
    }

    /**
     * Check if ticker has sufficient liquidity
     */
    private function checkLiquidity($signal)
    {
        // Get minimum liquidity requirement from risk rules
        $stmt = $this->db->prepare("
            SELECT rule_value 
            FROM risk_rules 
            WHERE rule_name = 'min_liquidity_volume' AND is_active = TRUE
        ");
        $stmt->execute();
        $rule = $stmt->fetch();

        $minVolume = $rule ? $rule['rule_value'] : 1000000;

        // In production, you would fetch actual volume from market data API
        // For now, we'll assume stocks pass this check
        // TODO: Integrate with Alpaca/Polygon for real volume data

        $passed = true; // Placeholder

        return [
            'check_name' => 'Liquidity Check',
            'passed' => $passed,
            'details' => "Minimum volume required: " . number_format($minVolume) . " shares",
            'severity' => 'medium'
        ];
    }

    /**
     * Check overall signal quality
     */
    private function checkSignalQuality($signal)
    {
        $issues = [];

        // Check if trade thesis exists and is meaningful
        if (empty($signal['trade_thesis']) || strlen($signal['trade_thesis']) < 50) {
            $issues[] = 'Trade thesis too short or missing';
        }

        // Check if position sizing is reasonable
        if ($signal['suggested_position_size'] <= 0) {
            $issues[] = 'Invalid position size';
        }

        // Check if entry price is set
        if (empty($signal['suggested_entry_price']) || $signal['suggested_entry_price'] <= 0) {
            $issues[] = 'Invalid entry price';
        }

        $passed = empty($issues);

        return [
            'check_name' => 'Signal Quality',
            'passed' => $passed,
            'details' => $passed ? 'Signal quality acceptable' : implode(', ', $issues),
            'severity' => 'medium'
        ];
    }

    /**
     * Get signal details
     */
    private function getSignal($signalId)
    {
        $stmt = $this->db->prepare("
            SELECT * FROM trade_signals WHERE id = ?
        ");
        $stmt->execute([$signalId]);
        return $stmt->fetch();
    }

    /**
     * Update signal validation status
     */
    private function updateSignalValidation($signalId, $passed, $checks)
    {
        $status = $passed ? 'passed' : 'failed';
        $notes = json_encode($checks);

        $stmt = $this->db->prepare("
            UPDATE trade_signals 
            SET rule_validation_status = ?,
                rule_validation_notes = ?
            WHERE id = ?
        ");
        $stmt->execute([$status, $notes, $signalId]);
    }

    /**
     * Generate summary of validation results
     */
    private function generateSummary($checks)
    {
        $passed = array_filter($checks, fn($c) => $c['passed']);
        $failed = array_filter($checks, fn($c) => !$c['passed']);

        return [
            'total_checks' => count($checks),
            'passed' => count($passed),
            'failed' => count($failed),
            'pass_rate' => round((count($passed) / count($checks)) * 100, 1) . '%'
        ];
    }

    /**
     * Log decision to audit trail
     */
    private function logDecision($ticker, $type, $outcome, $reason, $data, $signalId = null)
    {
        $stmt = $this->db->prepare("
            INSERT INTO decision_logs (
                ticker, decision_type, decision_outcome, decision_reason, 
                decision_data, related_signal_id
            ) VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $ticker,
            $type,
            $outcome,
            $reason,
            json_encode($data),
            $signalId
        ]);
    }

    /**
     * Check if ticker belongs to an allowed asset group
     */
    private function checkAssetGroup($signal)
    {
        // 1. Get Allowed Groups
        $stmt = $this->db->query("SELECT config_value FROM system_config WHERE config_key = 'allowed_asset_groups'");
        $row = $stmt->fetch();
        $allowedGroups = $row ? json_decode($row['config_value'], true) : [];

        // If no groups are defined, default to allowing all (or specific default)
        if (empty($allowedGroups)) {
            return ['check_name' => 'Asset Group', 'passed' => true, 'details' => 'No restrictions', 'severity' => 'low'];
        }

        // 2. Identify Ticker's Sector (Mock Logic for MVP)
        // In production, this would come from a 'tickers' table or Alpaca API
        $sector = $this->mockSectorLookup($signal['ticker']);

        // 3. Validate
        $passed = in_array($sector, $allowedGroups);

        return [
            'check_name' => 'Asset Group',
            'passed' => $passed,
            'details' => $passed ? "Sector '$sector' is allowed" : "Sector '$sector' is NOT in allowed groups (" . implode(', ', $allowedGroups) . ")",
            'severity' => 'high'
        ];
    }

    private function mockSectorLookup($ticker)
    {
        // Simple mock mapping for demo
        $map = [
            'AAPL' => 'Technology',
            'MSFT' => 'Technology',
            'NVDA' => 'Technology',
            'JPM' => 'Finance',
            'BAC' => 'Finance',
            'PFE' => 'Healthcare',
            'JNJ' => 'Healthcare',
            'XOM' => 'Energy',
            'SPY' => 'ETF',
            'QQQ' => 'ETF',
            'TQQQ' => 'ETF'
        ];
        return $map[$ticker] ?? 'Other';
    }
}
