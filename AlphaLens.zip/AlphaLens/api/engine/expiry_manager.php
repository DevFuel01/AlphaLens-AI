<?php

/**
 * Expiry Manager for AlphaLens AI
 * Handles time-based invalidation of signals and forced exits for stale positions
 * Feature 2.2: Event-Driven Trading Logic
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../trading/trade_executor.php';

class ExpiryManager
{
    private $db;
    private $tradeExecutor;
    private $expiryHours = 48; // Signal expiry
    private $maxHoldHours = 72; // Max holding period

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
        $this->tradeExecutor = new TradeExecutor();
    }

    /**
     * Run all expiry checks
     */
    public function runChecks()
    {
        $results = [
            'expired_signals' => 0,
            'forced_exits' => 0,
            'errors' => []
        ];

        try {
            $results['expired_signals'] = $this->expireOldSignals();
            $results['forced_exits'] = $this->checkTimeBasedExits();
        } catch (Exception $e) {
            $results['errors'][] = $e->getMessage();
        }

        return $results;
    }

    /**
     * invalidates pending signals older than 48 hours
     */
    private function expireOldSignals()
    {
        $stmt = $this->db->prepare("
            UPDATE trade_signals 
            SET final_status = 'expired',
                risk_validation_notes = CONCAT(COALESCE(risk_validation_notes, ''), ' Expired by system (> 48h).')
            WHERE final_status IN ('pending', 'awaiting_manual_approval')
            AND created_at < NOW() - INTERVAL ? HOUR
        ");

        $stmt->execute([$this->expiryHours]);
        return $stmt->rowCount();
    }

    /**
     * Closes positions held longer than 72 hours
     */
    private function checkTimeBasedExits()
    {
        // Find stale positions
        $stmt = $this->db->prepare("
            SELECT * FROM positions 
            WHERE quantity != 0 
            AND opened_at < NOW() - INTERVAL ? HOUR
        ");
        $stmt->execute([$this->maxHoldHours]);
        $stalePositions = $stmt->fetchAll();

        $exitCount = 0;

        foreach ($stalePositions as $pos) {
            $this->forceExit($pos);
            $exitCount++;
        }

        return $exitCount;
    }

    /**
     * Execute a forced exit for a stale position
     */
    private function forceExit($position)
    {
        $qty = $position['quantity'];
        $side = $qty > 0 ? 'sell' : 'buy';
        $absQty = abs($qty);

        // 1. Create a "forced exit" signal
        $stmt = $this->db->prepare("
            INSERT INTO trade_signals (
                ticker, signal_type, ai_confidence, trade_thesis, 
                suggested_position_size, suggested_entry_price, 
                final_status, created_at, suggested_stop_loss, suggested_take_profit
            ) VALUES (?, ?, 100, ?, ?, ?, 'approved', NOW(), NULL, NULL)
        ");

        $thesis = "⚠️ TIME-BOXED EXIT: Position held > {$this->maxHoldHours} hours. Closing position.";

        $stmt->execute([
            $position['ticker'],
            $side,
            $thesis,
            $absQty * $position['current_price'], // Estimate value
            $position['current_price']
        ]);

        $signalId = $this->db->lastInsertId();

        // 2. Execute it immediately via Trade Executor
        $this->tradeExecutor->executeSignal($signalId);
    }
}
