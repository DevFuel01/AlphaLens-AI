<?php

/**
 * Decision Orchestrator for AlphaLens AI
 * Coordinates the complete decision flow:
 * AI Analysis → Rule Validation → Risk Check → Execution Decision
 */

require_once __DIR__ . '/../ai/sentiment_analyzer.php';
require_once __DIR__ . '/rule_validator.php';
require_once __DIR__ . '/risk_controller.php';
require_once __DIR__ . '/../../config/database.php';

class DecisionOrchestrator
{
    private $db;
    private $sentimentAnalyzer;
    private $ruleValidator;
    private $riskController;
    private $alpacaClient;

    public function __construct($analyzer = null, $validator = null, $controller = null)
    {
        $this->db = Database::getInstance()->getConnection();
        $this->sentimentAnalyzer = $analyzer ?: new SentimentAnalyzer();
        $this->ruleValidator = $validator ?: new RuleValidator();
        $this->riskController = $controller ?: new RiskController();
        require_once __DIR__ . '/../trading/alpaca_client.php';
        $this->alpacaClient = new AlpacaClient();
    }

    /**
     * Process earnings transcript through complete decision flow
     * 
     * @param int $transcriptId Earnings transcript ID
     * @return array Complete decision result
     */
    public function processEarnings($transcriptId)
    {
        $result = [
            'success' => false,
            'steps' => [],
            'final_decision' => null
        ];

        // STEP 0: Check System Halt (Global Circuit Breaker)
        if ($this->isSystemHalted()) {
            $result['final_decision'] = 'rejected';
            $result['reason'] = 'TRADING HALTED: Global circuit breaker is active.';
            return $result;
        }

        // STEP 1: AI Sentiment Analysis
        $analysisResult = $this->sentimentAnalyzer->analyzeEarnings($transcriptId);
        $result['steps']['ai_analysis'] = $analysisResult;

        if (!$analysisResult['success']) {
            $result['final_decision'] = 'rejected';
            $result['reason'] = 'AI analysis failed: ' . $analysisResult['error'];
            return $result;
        }

        // STEP 2: Generate Trade Signal
        $signalId = $this->generateTradeSignal($analysisResult);
        $result['steps']['signal_generation'] = ['signal_id' => $signalId];

        if (!$signalId) {
            $result['final_decision'] = 'rejected';
            $result['reason'] = 'Failed to generate trade signal';
            return $result;
        }

        // STEP 3: Rule Validation
        $ruleResult = $this->ruleValidator->validateSignal($signalId);
        $result['steps']['rule_validation'] = $ruleResult;

        if (!$ruleResult['passed']) {
            $result['final_decision'] = 'rejected';
            $result['reason'] = 'Failed rule validation: ' . $ruleResult['summary']['failed'] . ' checks failed';
            $result['signal_id'] = $signalId;
            return $result;
        }

        // STEP 4: Risk Control Check
        if ($this->isRiskControlEnabled()) {
            $riskResult = $this->riskController->checkRisk($signalId);
            $result['steps']['risk_check'] = $riskResult;

            if (!$riskResult['approved']) {
                $result['final_decision'] = 'vetoed_by_risk';
                $result['reason'] = 'RISK VETO: ' . $riskResult['veto_reason'];
                $result['signal_id'] = $signalId;
                return $result;
            }
        } else {
            $result['steps']['risk_check'] = ['status' => 'bypassed', 'reason' => 'Risk controls globally disabled'];
        }

        // STEP 5: Check Trading Mode
        $tradingMode = $this->getTradingMode();
        $result['steps']['trading_mode'] = $tradingMode;

        if ($tradingMode === 'advisory') {
            // Advisory mode: Keep as pending, signal only
            $result['success'] = true;
            $result['final_decision'] = 'advisory_signal';
            $result['signal_id'] = $signalId;
            $result['message'] = 'Signal generated in Advisory Mode. No execution permitted.';
        } elseif ($tradingMode === 'semi_automated') {
            // Update DB status to approved
            $stmt = $this->db->prepare("UPDATE trade_signals SET final_status = 'approved' WHERE id = ?");
            $stmt->execute([$signalId]);

            $result['success'] = true;
            $result['final_decision'] = 'awaiting_manual_approval';
            $result['signal_id'] = $signalId;
            $result['message'] = 'Signal passed all checks. Awaiting manual approval for execution.';
        } else {
            // Fully automated - EXECUTE IMMEDIATELY
            require_once __DIR__ . '/../trading/trade_executor.php';
            $executor = new TradeExecutor();
            $execResult = $executor->executeSignal($signalId);

            $result['success'] = $execResult['success'];
            $result['final_decision'] = $execResult['success'] ? 'executed' : 'execution_failed';
            $result['signal_id'] = $signalId;
            $result['message'] = $execResult['success'] ? 'Signal approved and EXECUTED automatically.' : 'Automated execution failed: ' . ($execResult['error'] ?? 'Unknown error');
            $result['execution_details'] = $execResult;
        }

        return $result;
    }

    /**
     * Process news article through complete decision flow
     * 
     * @param int $articleId News article ID
     * @return array Complete decision result
     */
    public function processNews($articleId)
    {
        $result = [
            'success' => false,
            'steps' => [],
            'final_decision' => null
        ];

        // STEP 0: Check System Halt (Global Circuit Breaker)
        if ($this->isSystemHalted()) {
            $result['final_decision'] = 'rejected';
            $result['reason'] = 'TRADING HALTED: Global circuit breaker is active.';
            return $result;
        }

        // STEP 1: AI Sentiment Analysis
        $analysisResult = $this->sentimentAnalyzer->analyzeNews($articleId);
        $result['steps']['ai_analysis'] = $analysisResult;

        if (!$analysisResult['success']) {
            $result['final_decision'] = 'rejected';
            $result['reason'] = 'AI analysis failed: ' . $analysisResult['error'];
            return $result;
        }

        // STEP 2: Generate Trade Signal
        $signalId = $this->generateTradeSignal($analysisResult);
        $result['steps']['signal_generation'] = ['signal_id' => $signalId];

        if (!$signalId) {
            $result['final_decision'] = 'rejected';
            $result['reason'] = 'Failed to generate trade signal';
            return $result;
        }

        // STEP 3: Rule Validation
        $ruleResult = $this->ruleValidator->validateSignal($signalId);
        $result['steps']['rule_validation'] = $ruleResult;

        if (!$ruleResult['passed']) {
            $result['final_decision'] = 'rejected';
            $result['reason'] = 'Failed rule validation';
            $result['signal_id'] = $signalId;
            return $result;
        }

        // STEP 4: Risk Control Check
        if ($this->isRiskControlEnabled()) {
            $riskResult = $this->riskController->checkRisk($signalId);
            $result['steps']['risk_check'] = $riskResult;

            if (!$riskResult['approved']) {
                $result['final_decision'] = 'vetoed_by_risk';
                $result['reason'] = 'RISK VETO: ' . $riskResult['veto_reason'];
                $result['signal_id'] = $signalId;
                return $result;
            }
        } else {
            $result['steps']['risk_check'] = ['status' => 'bypassed', 'reason' => 'Risk controls globally disabled'];
        }

        // STEP 5: Check Trading Mode
        $tradingMode = $this->getTradingMode();

        if ($tradingMode === 'advisory') {
            $result['success'] = true;
            $result['final_decision'] = 'advisory_signal';
            $result['signal_id'] = $signalId;
        } elseif ($tradingMode === 'semi_automated') {
            // Update DB status to approved
            $stmt = $this->db->prepare("UPDATE trade_signals SET final_status = 'approved' WHERE id = ?");
            $stmt->execute([$signalId]);

            $result['success'] = true;
            $result['final_decision'] = 'awaiting_manual_approval';
            $result['signal_id'] = $signalId;
        } else {
            // Fully automated - EXECUTE IMMEDIATELY
            require_once __DIR__ . '/../trading/trade_executor.php';
            $executor = new TradeExecutor();
            $execResult = $executor->executeSignal($signalId);

            $result['success'] = $execResult['success'];
            $result['final_decision'] = $execResult['success'] ? 'executed' : 'execution_failed';
            $result['signal_id'] = $signalId;
            $result['execution_details'] = $execResult;
        }

        return $result;
    }

    /**
     * Generate trade signal from AI analysis
     */
    private function generateTradeSignal($analysisResult)
    {
        $analysis = $analysisResult['analysis'];
        $analysisId = $analysisResult['analysis_id'];

        // Get ticker from sentiment analysis
        $stmt = $this->db->prepare("SELECT ticker FROM ai_sentiment_analysis WHERE id = ?");
        $stmt->execute([$analysisId]);
        $sentimentData = $stmt->fetch();
        $ticker = $sentimentData['ticker'];

        // Determine signal type from sentiment
        $signalType = 'hold';
        if ($analysis['sentiment'] === 'bullish' && $analysis['confidence_level'] >= 60) {
            $signalType = 'buy';
        } elseif ($analysis['sentiment'] === 'bearish' && $analysis['confidence_level'] >= 60) {
            $signalType = 'sell';
        }

        // Calculate suggested position size (Institutional Grade: ATR-Adjusted)
        $portfolioValue = $this->getPortfolioValue();
        $riskPerTradePct = 1.0; // Risk 1% of total capital on this trade
        $riskAmount = ($portfolioValue * $riskPerTradePct) / 100;

        // Fetch volatility (ATR)
        $atr = $this->calculateATR($ticker);

        if ($atr > 0) {
            // Sizing Formula: Position Size = Risk Amount / ATR
            // This ensures we lose roughly the same $ amount if ATR is hit
            // We'll use 2x ATR as the "Risk Unit" for safety
            $positionSize = $riskAmount / ($atr * 2);
        } else {
            // Fallback to simple confidence-based sizing if ATR fails
            $basePositionPct = 3;
            $confidenceMultiplier = $analysis['confidence_level'] / 100;
            $positionPct = $basePositionPct * $confidenceMultiplier;
            $positionSize = ($portfolioValue * $positionPct) / 100;
        }

        // Final sanity check: never exceed max_position_size_pct (e.g., 5%)
        $maxPositionPct = 5.0;
        $maxPositionValue = ($portfolioValue * $maxPositionPct) / 100;
        $positionSize = min($positionSize, $maxPositionValue);

        // Get current market price with multi-source fallback
        $entryPrice = 0;
        $priceSource = 'none';

        // 1. Try Quote (Best for live ask price)
        $quoteResult = $this->alpacaClient->getQuote($ticker);
        if ($quoteResult['success'] && isset($quoteResult['data']['quote']['ap']) && $quoteResult['data']['quote']['ap'] > 0) {
            $entryPrice = (float)$quoteResult['data']['quote']['ap'];
            $priceSource = 'quote';
        }

        // 2. Fallback to Snapshot (Latest trade)
        if ($entryPrice <= 0) {
            $snapshot = $this->alpacaClient->getSnapshot($ticker);
            if ($snapshot['success'] && isset($snapshot['data']['latestTrade']['p']) && $snapshot['data']['latestTrade']['p'] > 0) {
                $entryPrice = (float)$snapshot['data']['latestTrade']['p'];
                $priceSource = 'snapshot';
            }
        }

        // 3. Fallback to Bars (Most recent close)
        if ($entryPrice <= 0) {
            $barResult = $this->alpacaClient->getBars($ticker, '1Min', 1);
            if ($barResult['success'] && !empty($barResult['data']['bars'])) {
                $entryPrice = (float)$barResult['data']['bars'][0]['c'];
                $priceSource = 'bars';
            }
        }

        // If price discovery fails completely, do not default to $100
        if ($entryPrice <= 0) {
            throw new Exception("Price discovery failed for {$ticker}. All sources (Quote, Snapshot, Bars) returned invalid data.");
        }

        error_log("Price discovery for {$ticker} successful: \${$entryPrice} via {$priceSource}");

        // Calculate stop loss and take profit (ATR-based if available)
        if ($atr > 0) {
            $atrMultiplier = 2.0; // Stop at 2x ATR
            $rewardRatio = 2.0;   // Target 2:1 reward/risk

            if ($signalType === 'buy') {
                $stopLoss = $entryPrice - ($atr * $atrMultiplier);
                $takeProfit = $entryPrice + ($atr * $atrMultiplier * $rewardRatio);
            } else {
                $stopLoss = $entryPrice + ($atr * $atrMultiplier);
                $takeProfit = $entryPrice - ($atr * $atrMultiplier * $rewardRatio);
            }
        } else {
            // Default 2%/5% fallback
            $stopLoss = ($signalType === 'buy') ? $entryPrice * 0.98 : $entryPrice * 1.02;
            $takeProfit = ($signalType === 'buy') ? $entryPrice * 1.05 : $entryPrice * 0.95;
        }

        // Check for Price-Sentiment Divergence
        $divergencePrefix = "";
        $snapshot = $this->alpacaClient->getSnapshot($ticker);
        if ($snapshot['success'] && isset($snapshot['data']['dailyBar']['c'], $snapshot['data']['prevDailyBar']['c'])) {
            $currentPrice = $snapshot['data']['dailyBar']['c'];
            $prevClose = $snapshot['data']['prevDailyBar']['c'];
            $priceChangePct = (($currentPrice - $prevClose) / $prevClose) * 100;

            if ($analysis['sentiment_score'] >= 50 && $priceChangePct < -1.0) {
                $divergencePrefix = "⚠️ BULLISH DIVERGENCE (Oversold): Price down " . number_format($priceChangePct, 1) . "% despite strong sentiment. ";
            } elseif ($analysis['sentiment_score'] <= -50 && $priceChangePct > 1.0) {
                $divergencePrefix = "⚠️ BEARISH DIVERGENCE (Overbought): Price up " . number_format($priceChangePct, 1) . "% despite negative sentiment. ";
            }
        }

        // Insert trade signal
        $stmt = $this->db->prepare("
            INSERT INTO trade_signals (
                ticker, signal_type, sentiment_analysis_id, ai_confidence,
                trade_thesis, suggested_position_size, suggested_entry_price,
                suggested_stop_loss, suggested_take_profit, final_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
        ");

        $stmt->execute([
            $ticker,
            $signalType,
            $analysisId,
            $analysis['confidence_level'],
            $divergencePrefix . $analysis['trade_thesis'],
            $positionSize,
            $entryPrice,
            $stopLoss,
            $takeProfit
        ]);

        return $this->db->lastInsertId();
    }

    /**
     * Get trading mode from config
     */
    private function getTradingMode()
    {
        $stmt = $this->db->query("
            SELECT config_value 
            FROM system_config 
            WHERE config_key = 'trading_mode'
        ");
        $result = $stmt->fetch();
        return $result ? $result['config_value'] : 'semi_automated';
    }

    /**
     * Calculate 14-day Average True Range (ATR)
     */
    private function calculateATR($ticker)
    {
        $barResult = $this->alpacaClient->getBars($ticker, 21); // 21 bars to get 20 TRs/SMA
        if (!$barResult['success'] || !isset($barResult['data']['bars'])) {
            return 0;
        }

        $bars = $barResult['data']['bars'];
        $count = count($bars);
        if ($count < 2) return 0;

        $trueRanges = [];
        for ($i = 1; $i < $count; $i++) {
            $h = $bars[$i]['h'];
            $l = $bars[$i]['l'];
            $pc = $bars[$i - 1]['c']; // Previous Close

            $tr = max(
                $h - $l,
                abs($h - $pc),
                abs($l - $pc)
            );
            $trueRanges[] = $tr;
        }

        if (empty($trueRanges)) return 0;
        return array_sum($trueRanges) / count($trueRanges);
    }

    /**
     * Get portfolio value
     */
    private function getPortfolioValue()
    {
        $stmt = $this->db->query("
            SELECT config_value 
            FROM system_config 
            WHERE config_key = 'default_portfolio_value'
        ");
        $result = $stmt->fetch();
        return $result ? (float)$result['config_value'] : 100000;
    }

    /**
     * Check if trading is globally halted
     */
    private function isSystemHalted()
    {
        $stmt = $this->db->query("
            SELECT config_value 
            FROM system_config 
            WHERE config_key = 'system_halted'
        ");
        $result = $stmt->fetch();
        return ($result && $result['config_value'] === 'true');
    }

    /**
     * Check if risk controls are enabled
     */
    private function isRiskControlEnabled()
    {
        $stmt = $this->db->query("
            SELECT config_value 
            FROM system_config 
            WHERE config_key = 'risk_controls_enabled'
        ");
        $result = $stmt->fetch();
        return ($result && $result['config_value'] === 'true');
    }
}
