<?php

/**
 * Research Replay Engine
 * Evaluates past AI decisions against actual market outcomes
 * and allows re-running analysis with new prompts.
 */

require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../trading/alpaca_client.php';
require_once __DIR__ . '/../ai/sentiment_analyzer.php';

class ResearchReplay
{
    private $db;
    private $alpaca;
    private $sentimentAnalyzer;

    public function __construct()
    {
        $this->db = Database::getInstance()->getConnection();
        $this->alpaca = new AlpacaClient();
        $this->sentimentAnalyzer = new SentimentAnalyzer();
    }

    /**
     * Evaluate a past signal against actual market return
     * 
     * @param int $signalId
     * @param int $days Horizon to check (e.g., 30 days)
     * @return array Evaluation result
     */
    public function evaluateSignal($signalId, $days = 30)
    {
        // 1. Fetch signal details
        $stmt = $this->db->prepare("
            SELECT ts.*, ais.sentiment_score, ais.confidence_level
            FROM trade_signals ts
            LEFT JOIN ai_sentiment_analysis ais ON ts.sentiment_analysis_id = ais.id
            WHERE ts.id = ?
        ");
        $stmt->execute([$signalId]);
        $signal = $stmt->fetch();

        if (!$signal) {
            return ['success' => false, 'error' => 'Signal not found'];
        }

        // 2. Calculate actual outcome
        $outcome = $this->calculateOutcome(
            $signal['ticker'],
            $signal['created_at'],
            $days
        );

        if (!$outcome['success']) {
            return $outcome;
        }

        // 3. Compare AI prediction vs Reality
        $isCorrect = false;
        if ($signal['signal_type'] === 'buy' && $outcome['return_pct'] > 0) {
            $isCorrect = true;
        } elseif ($signal['signal_type'] === 'sell' && $outcome['return_pct'] < 0) {
            $isCorrect = true;
        }

        return [
            'success' => true,
            'signal' => $signal,
            'outcome' => $outcome,
            'is_correct' => $isCorrect,
            'correlation' => $this->calculateCorrelation($signal['confidence_level'], $outcome['return_pct'])
        ];
    }

    /**
     * Calculate return of a stock over X days from a start date
     */
    private function calculateOutcome($ticker, $startDate, $days)
    {
        // Convert dates
        $start = new DateTime($startDate);
        $end = clone $start;
        $end->modify("+$days days");

        // Ideally we would query a historical_data table.
        // For now, we will use Alpaca to fetch bars if not in DB, or assume we can fetch live range.
        // Since we are replay mode, we assume $start is in the past.

        try {
            // Fetch daily bars from Alpaca
            $bars = $this->alpaca->getBars(
                $ticker,
                '1Day',
                100, // Limit
                $start->format('Y-m-d'),
                $end->format('Y-m-d')
            );

            if (empty($bars['bars'])) {
                return ['success' => false, 'error' => 'No market data found for period'];
            }

            $entryPrice = $bars['bars'][0]['c']; // Close of first day
            $exitPrice = end($bars['bars'])['c']; // Close of last day

            $returnPct = (($exitPrice - $entryPrice) / $entryPrice) * 100;

            return [
                'success' => true,
                'start_price' => $entryPrice,
                'end_price' => $exitPrice,
                'return_pct' => $returnPct,
                'max_drawdown' => $this->calculateDataDrawdown($bars['bars'])
            ];
        } catch (Exception $e) {
            return ['success' => false, 'error' => $e->getMessage()];
        }
    }

    private function calculateDataDrawdown($bars)
    {
        $maxPrice = 0;
        $maxDrawdown = 0;

        foreach ($bars as $bar) {
            if ($bar['h'] > $maxPrice) {
                $maxPrice = $bar['h'];
            }

            $drawdown = ($maxPrice - $bar['l']) / $maxPrice * 100;
            if ($drawdown > $maxDrawdown) {
                $maxDrawdown = $drawdown;
            }
        }
        return $maxDrawdown;
    }

    private function calculateCorrelation($confidence, $return)
    {
        // Simple heuristic: High confidence should map to higher absolute returns
        // This is a placeholder for a real statistical correlation
        return ($confidence / 100) * abs($return);
    }
}
