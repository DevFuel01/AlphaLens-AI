<?php
require_once __DIR__ . '/config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    echo "Applying sector column migration...\n";

    $sql = "ALTER TABLE positions ADD COLUMN sector VARCHAR(50) DEFAULT 'Unknown' AFTER ticker";
    $db->exec($sql);

    echo "✓ Migration successful!\n";
    echo "\nVerifying column was added...\n";

    $stmt = $db->query("DESCRIBE positions");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($columns as $col) {
        echo "  - {$col['Field']} ({$col['Type']})\n";
    }
} catch (PDOException $e) {
    if (strpos($e->getMessage(), 'Duplicate column') !== false) {
        echo "✓ Column 'sector' already exists!\n";
    } else {
        echo "✗ ERROR: " . $e->getMessage() . "\n";
    }
}
