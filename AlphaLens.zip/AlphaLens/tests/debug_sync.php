<?php
require_once __DIR__ . '/../api/trading/position_manager.php';
require_once __DIR__ . '/../api/trading/alpaca_client.php';

try {
    $alpaca = new AlpacaClient();
    $raw = $alpaca->getPositions();

    $pm = new PositionManager();
    $result = $pm->syncPositions();

    $db = Database::getInstance()->getConnection();
    $stmt = $db->query("SELECT * FROM positions");
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $output = "Raw Alpaca:\n" . print_r($raw, true) .
        "\n\nSync Result:\n" . print_r($result, true) .
        "\n\nDB Positions:\n" . print_r($rows, true);

    file_put_contents('debug_sync.log', $output);
    echo "Debug log written.\n";
} catch (Exception $e) {
    file_put_contents('debug_sync.log', "Error: " . $e->getMessage());
    echo "Error: " . $e->getMessage();
}
