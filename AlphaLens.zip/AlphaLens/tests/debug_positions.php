<?php
require_once __DIR__ . '/../api/trading/alpaca_client.php';
require_once __DIR__ . '/../api/trading/position_manager.php';
require_once __DIR__ . '/../config/database.php';

$alpaca = new AlpacaClient();
$posManager = new PositionManager();
$db = Database::getInstance()->getConnection();

echo "--- ALPACA POSITIONS ---\n";
$alpacaRes = $alpaca->getPositions();
if ($alpacaRes['success']) {
    foreach ($alpacaRes['data'] as $p) {
        echo "Ticker: {$p['symbol']}, Qty: {$p['qty']}, Side: {$p['side']}, Entry: {$p['avg_entry_price']}\n";
    }
} else {
    echo "Error fetching Alpaca positions: " . $alpacaRes['error'] . "\n";
}

echo "\n--- DATABASE POSITIONS ---\n";
$stmt = $db->query("SELECT * FROM positions");
while ($row = $stmt->fetch()) {
    echo "Ticker: {$row['ticker']}, Qty: {$row['quantity']}, MarketValue: {$row['market_value']}\n";
}

echo "\n--- OPEN ORDERS ---\n";
$ordersRes = $alpaca->getOpenOrders();
if ($ordersRes['success']) {
    foreach ($ordersRes['data'] as $o) {
        echo "ID: {$o['id']}, Ticker: {$o['symbol']}, Qty: {$o['qty']}, Side: {$o['side']}, Type: {$o['type']}, Status: {$o['status']}\n";
    }
} else {
    echo "Error fetching open orders: " . $ordersRes['error'] . "\n";
}
