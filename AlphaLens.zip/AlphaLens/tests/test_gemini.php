<?php

/**
 * Test Script for Gemini AI Connection
 * Access via: http://localhost/AlphaLens/tests/test_gemini.php
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🧠 Gemini AI Connection Test</h1>";

require_once '../api/ai/gemini_client.php';

try {
    echo "<p>Initializing Gemini Client...</p>";
    $gemini = new GeminiClient();

    $prompt = "Respond with 'Connection successful' if you can read this.";
    echo "<p>Sending Test Prompt: <em>'$prompt'</em></p>";

    $result = $gemini->generateContent($prompt);

    if ($result['success']) {
        echo "<div style='background-color: #d1fae5; padding: 15px; border-radius: 5px; border: 1px solid #10b981;'>";
        echo "<h3 style='color: #065f46; margin-top: 0;'>✓ Gemini AI Connected Successfully!</h3>";
        echo "<strong>AI Response:</strong><br>";
        echo "<blockquote style='background: white; padding: 10px; border-left: 4px solid #10b981; margin: 10px 0;'>" . htmlspecialchars($result['content']) . "</blockquote>";
        echo "</div>";
    } else {
        throw new Exception($result['error']);
    }
} catch (Exception $e) {
    echo "<div style='background-color: #fee2e2; padding: 15px; border-radius: 5px; border: 1px solid #ef4444;'>";
    echo "<h3 style='color: #991b1b; margin-top: 0;'>✗ Connection Failed</h3>";
    echo "<strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "<br>";
    echo "<hr>";
    echo "<strong>Troubleshooting:</strong><br>";
    echo "1. Check your API key in <code>config/gemini.php</code><br>";
    echo "2. Ensure the key has permissions for 'gemini-pro'<br>";
    echo "</div>";
}
