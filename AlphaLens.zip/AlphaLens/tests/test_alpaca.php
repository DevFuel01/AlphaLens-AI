<?php

/**
 * Test Script for Alpaca API Connection
 * Access via: http://localhost/AlphaLens/tests/test_alpaca.php
 */

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🔍 Alpaca Connection Test</h1>";

// Check file existence
$params = [
    '../api/trading/alpaca_client.php'
];

foreach ($params as $file) {
    if (!file_exists($file)) {
        die("❌ Critical Error: Required file not found: $file<br>Current directory: " . getcwd());
    }
}

require_once '../api/trading/alpaca_client.php';

try {
    echo "<p>Initializing Alpaca Client...</p>";
    $alpaca = new AlpacaClient();

    echo "<p>Fetching Account Information...</p>";
    $result = $alpaca->getAccount();

    if ($result['success']) {
        $account = $result['data'];
        echo "<div style='background-color: #d1fae5; padding: 15px; border-radius: 5px; border: 1px solid #10b981;'>";
        echo "<h3 style='color: #065f46; margin-top: 0;'>✓ Alpaca Connected Successfully!</h3>";
        echo "<strong>Status:</strong> " . htmlspecialchars($account['status']) . "<br>";
        echo "<strong>Currency:</strong> " . htmlspecialchars($account['currency']) . "<br>";
        echo "<strong>Buying Power:</strong> $" . number_format($account['buying_power'], 2) . "<br>";
        echo "<strong>Portfolio Value:</strong> $" . number_format($account['portfolio_value'], 2) . "<br>";
        echo "<strong>Cash:</strong> $" . number_format($account['cash'], 2) . "<br>";
        echo "</div>";
    } else {
        throw new Exception($result['error']);
    }
} catch (Exception $e) {
    echo "<div style='background-color: #fee2e2; padding: 15px; border-radius: 5px; border: 1px solid #ef4444;'>";
    echo "<h3 style='color: #991b1b; margin-top: 0;'>✗ Connection Failed</h3>";
    echo "<strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "<br>";
    echo "<hr>";
    echo "<strong>Troubleshooting:</strong><br>";
    echo "1. Check your API keys in <code>config/alpaca.php</code><br>";
    echo "2. Ensure you are using Paper Trading keys (starting with 'PK')<br>";
    echo "3. Verify your endpoint URL is <code>https://paper-api.alpaca.markets</code>";
    echo "</div>";
}
