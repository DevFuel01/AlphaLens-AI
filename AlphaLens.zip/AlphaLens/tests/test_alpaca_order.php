<?php
require_once __DIR__ . '/../config/alpaca.php';
require_once __DIR__ . '/../api/trading/alpaca_client.php';

try {
    echo "Initializing Alpaca Client...\n";
    $alpaca = new AlpacaClient();

    echo "Attempting to place Limit Buy Order for 1 AAPL at $1.00...\n";
    $order = [
        'symbol' => 'AAPL',
        'qty' => 1,
        'side' => 'buy',
        'type' => 'limit',
        'time_in_force' => 'day',
        'limit_price' => 1.00
    ];

    $result = $alpaca->createOrder($order['symbol'], $order['qty'], $order['side'], $order['type'], $order['time_in_force'], $order['limit_price']);

    echo "Response:\n";
    print_r($result);

    if ($result['success']) {
        echo "SUCCESS: Order placed.\n";
        // Cancel it to be clean
        if (isset($result['data']['id'])) {
            $alpaca->cancelOrder($result['data']['id']);
            echo "Order cancelled.\n";
        }
    } else {
        echo "FAILURE: " . $result['error'] . "\n";
    }
} catch (Exception $e) {
    echo "EXCEPTION: " . $e->getMessage() . "\n";
}
