<?php
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance()->getConnection();
$res = $db->query("SELECT id, ticker, suggested_entry_price, created_at FROM trade_signals ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
echo "--- TRADE SIGNALS ---\n";
echo json_encode($res, JSON_PRETTY_PRINT);

$res2 = $db->query("SELECT * FROM trade_executions ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
echo "\n--- TRADE EXECUTIONS ---\n";
echo json_encode($res2, JSON_PRETTY_PRINT);
