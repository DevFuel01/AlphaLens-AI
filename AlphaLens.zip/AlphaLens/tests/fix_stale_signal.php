<?php
require_once __DIR__ . '/../api/trading/alpaca_client.php';
require_once __DIR__ . '/../config/database.php';

$alpaca = new AlpacaClient();
$db = Database::getInstance()->getConnection();

$ticker = 'NVDA';
$snap = $alpaca->getSnapshot($ticker);

if (!$snap['success']) {
    die("Failed to fetch price for {$ticker}: " . $snap['error'] . "\n");
}

$price = (float)$snap['data']['latestTrade']['p'];
echo "Current Price for {$ticker}: \${$price}\n";

if ($price <= 0) {
    die("Invalid price received.\n");
}

// Signal 4 was a "sell" signal. Let's update it.
// Suggested SL: +2%, TP: -5%
$sl = $price * 1.02;
$tp = $price * 0.95;

$stmt = $db->prepare("
    UPDATE trade_signals 
    SET suggested_entry_price = ?, 
        suggested_stop_loss = ?, 
        suggested_take_profit = ? 
    WHERE id = 4
");

$stmt->execute([$price, $sl, $tp]);

echo "Signal ID 4 updated to \${$price} (SL: \${$sl}, TP: \${$tp})\n";
