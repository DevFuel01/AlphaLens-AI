<?php
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance()->getConnection();
if (!$db) {
    die("Database connection failed\n");
}

try {
    echo "--- LATEST SIGNAL ---\n";
    $signal = $db->query("SELECT id, ticker, suggested_entry_price, final_status, created_at FROM trade_signals ORDER BY id DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC);
    print_r($signal);

    echo "\n--- LATEST DECISION LOGS ---\n";
    $logs = $db->query("SELECT * FROM decision_logs ORDER BY id DESC LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
    print_r($logs);

    echo "\n--- LATEST EXECUTION LOGS ---\n";
    $execs = $db->query("SELECT id, ticker, status, error_message, created_at FROM trade_executions ORDER BY id DESC LIMIT 3")->fetchAll(PDO::FETCH_ASSOC);
    print_r($execs);
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
