<?php
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance()->getConnection();

echo "--- RECENT SIGNALS (JSON) ---\n";
$sigs = $db->query("SELECT id, ticker, suggested_entry_price, created_at, final_status FROM trade_signals ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($sigs, JSON_PRETTY_PRINT) . "\n";

echo "\n--- SYSTEM CONFIG (SLIPPAGE) ---\n";
$stmt = $db->prepare("SELECT * FROM system_config WHERE config_key = 'max_slippage_pct'");
$stmt->execute();
echo json_encode($stmt->fetch(PDO::FETCH_ASSOC), JSON_PRETTY_PRINT) . "\n";

echo "\n--- TESTING ALPACA CONNECTION ---\n";
require_once __DIR__ . '/../api/trading/alpaca_client.php';
$alpaca = new AlpacaClient();
$resp = $alpaca->getAccount();
echo "Account Test: " . json_encode($resp, JSON_PRETTY_PRINT) . "\n";

$sym = $sigs[0]['ticker'] ?? 'NVDA';
$snap = $alpaca->getSnapshot($sym);
echo "Snapshot Test ({$sym}): " . json_encode($snap, JSON_PRETTY_PRINT) . "\n";
