<?php
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance()->getConnection();
$res = $db->query("SELECT * FROM trade_signals WHERE id = 4")->fetch(PDO::FETCH_ASSOC);
file_put_contents(__DIR__ . '/latest_signal.txt', print_r($res, true));
echo "Saved to latest_signal.txt\n";
