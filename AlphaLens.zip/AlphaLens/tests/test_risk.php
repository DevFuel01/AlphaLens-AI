<?php

/**
 * Test Script for Risk Controller
 * Access via: http://localhost/AlphaLens/tests/test_risk.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>🛡️ Risk Controller Validation Test</h1>";

require_once '../config/database.php';
require_once '../api/engine/risk_controller.php';

try {
    $db = Database::getInstance()->getConnection();

    // Create a mock signal for testing
    echo "<p>Creating Test Signal (Position Size: $1,000,000)...</p>";
    $stmt = $db->prepare("
        INSERT INTO trade_signals (ticker, signal_type, ai_confidence, suggested_position_size, final_status)
        VALUES ('TEST_RISK', 'buy', 95, 1000000.00, 'pending')
    ");
    $stmt->execute();
    $signalId = $db->lastInsertId();

    echo "<p>Test Signal Created (ID: $signalId)</p>";

    // Run Risk Check
    echo "<p>Running Risk Check...</p>";
    $riskController = new RiskController();
    $result = $riskController->checkRisk($signalId);

    echo "<pre>";
    print_r($result);
    echo "</pre>";
    file_put_contents('debug.log', print_r($result, true));

    // Clean up test data
    $db->exec("DELETE FROM trade_signals WHERE id = $signalId");

    if (!$result['approved']) {
        echo "<div style='background-color: #d1fae5; padding: 15px; border-radius: 5px; border: 1px solid #10b981;'>";
        echo "<h3 style='color: #065f46; margin-top: 0;'>✓ Risk Controller Working Correctly!</h3>";
        echo "<strong>Outcome:</strong> Trade Vetoed (As Expected for excessive size)<br>";
        echo "<strong>Veto Reason:</strong> " . htmlspecialchars($result['veto_reason']) . "<br>";
        echo "</div>";
    } else {
        echo "<div style='background-color: #fee2e2; padding: 15px; border-radius: 5px; border: 1px solid #ef4444;'>";
        echo "<h3 style='color: #991b1b; margin-top: 0;'>⚠ Warning: Risk Check Failed to Veto</h3>";
        echo "The huge position should have been rejected but was approved.<br>";
        echo "</div>";
    }
} catch (Exception $e) {
    echo "<div style='background-color: #fee2e2; padding: 15px; border-radius: 5px; border: 1px solid #ef4444;'>";
    echo "<h3 style='color: #991b1b; margin-top: 0;'>✗ Test Error</h3>";
    echo "<strong>Error:</strong> " . htmlspecialchars($e->getMessage()) . "<br>";
    echo "</div>";
}
