<?php
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance()->getConnection();
$res = $db->query("SELECT id, ticker, suggested_entry_price, created_at FROM trade_signals ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
foreach ($res as $r) {
    echo "SIGNAL_ID: " . $r['id'] . " | TICKER: " . $r['ticker'] . " | SUGGESTED_PRICE: " . $r['suggested_entry_price'] . " | CREATED: " . $r['created_at'] . "\n";
}
