<?php
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance()->getConnection();

echo "--- RECENT SIGNALS ---\n";
$sigs = $db->query("SELECT id, ticker, suggested_entry_price, created_at, final_status FROM trade_signals ORDER BY id DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
foreach ($sigs as $sig) {
    echo "ID: {$sig['id']} | Ticker: {$sig['ticker']} | Price: {$sig['suggested_entry_price']} | Created: {$sig['created_at']} | Status: {$sig['final_status']}\n";
}

echo "\n--- SLIPPAGE CONFIG ---\n";
$stmt = $db->prepare("SELECT config_value FROM system_config WHERE config_key = 'max_slippage_pct'");
$stmt->execute();
$val = $stmt->fetchColumn();
echo "max_slippage_pct: " . ($val ?: 'NOT SET (Default 1.0)') . "\n";

echo "\n--- LIVE PRICES (TOP 3) ---\n";
require_once __DIR__ . '/../api/trading/alpaca_client.php';
$alpaca = new AlpacaClient();
foreach (array_unique(array_column($sigs, 'ticker')) as $symbol) {
    if (empty($symbol)) continue;
    $snap = $alpaca->getSnapshot($symbol);
    if ($snap['success']) {
        $price = $snap['data']['latestTrade']['p'] ?? 'N/A';
        echo "{$symbol}: Live Price = {$price}\n";
    } else {
        echo "{$symbol}: API Error: {$snap['error']}\n";
    }
}
