<?php
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance()->getConnection();
$tables = ['earnings_transcripts', 'news_articles', 'ai_sentiment_analysis', 'trade_executions', 'performance_metrics', 'prompt_versions'];
foreach ($tables as $table) {
    try {
        $stmt = $db->query("DESCRIBE $table");
        echo "Table '$table' exists.\n";
    } catch (PDOException $e) {
        echo "Table '$table' DOES NOT EXIST.\n";
    }
}
