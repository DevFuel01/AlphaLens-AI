<?php
require_once __DIR__ . '/../config/database.php';

$db = Database::getInstance()->getConnection();

echo "Initializing Prompt Versions...\n";

// Check if prompt exists
$stmt = $db->query("SELECT COUNT(*) FROM prompt_versions WHERE prompt_name = 'earnings_sentiment_analysis'");
$count = $stmt->fetchColumn();

if ($count == 0) {
    echo "Inserting default earnings prompt (v1.0)...\n";
    $sql = "INSERT INTO prompt_versions (prompt_name, prompt_version, prompt_template, is_active) VALUES
    ('earnings_sentiment_analysis', 'v1.0', 
    'Analyze the following earnings transcript and provide a structured sentiment analysis.

COMPANY: {company_name}
TICKER: {ticker}
QUARTER: {quarter}
EARNINGS DATE: {earnings_date}

TRANSCRIPT:
{transcript_text}

GUIDANCE:
{guidance_text}

Please provide:
1. Overall sentiment (bullish/neutral/bearish)
2. Sentiment score (-100 to +100)
3. Confidence level (0-100)
4. Key insights (3-5 bullet points)
5. Trade thesis (2-3 sentences explaining potential trade opportunity)
6. Tone shift (identifying management confidence, caution, or uncertainty)
7. Narrative risks (potential headwinds mentioned)
8. Key quotes (2-3 direct impactful quotes from management)

Format as JSON with keys: sentiment, sentiment_score, confidence_level, key_insights, trade_thesis, tone_shift, narrative_risk, key_quotes', TRUE)";

    $db->exec($sql);
    echo "✅ Default prompt inserted.\n";
} else {
    echo "✓ Default prompt already exists.\n";
}
