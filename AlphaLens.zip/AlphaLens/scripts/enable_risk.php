<?php
require_once __DIR__ . '/../config/database.php';

try {
    $db = Database::getInstance()->getConnection();

    // Check current value
    $stmt = $db->query("SELECT config_value FROM system_config WHERE config_key = 'risk_controls_enabled'");
    $current = $stmt->fetchColumn();
    echo "Current value: " . var_export($current, true) . "\n";

    // Update to true
    $stmt = $db->prepare("INSERT INTO system_config (config_key, config_value, config_type, description) VALUES ('risk_controls_enabled', 'true', 'boolean', 'Enable risk control framework') ON DUPLICATE KEY UPDATE config_value = 'true'");
    $stmt->execute();

    echo "Updated 'risk_controls_enabled' to 'true'.\n";
} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
