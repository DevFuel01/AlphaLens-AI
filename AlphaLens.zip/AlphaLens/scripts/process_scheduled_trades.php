<?php

/**
 * Scheduled Trade Processor
 * Checks for scheduled trades that are due and executes them.
 * Run via cron every minute.
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../api/trading/trade_executor.php';

echo "Checking for scheduled trades...\n";

$db = Database::getInstance()->getConnection();
$executor = new TradeExecutor();

// Find due trades
$stmt = $db->prepare("
    SELECT id, ticker, scheduled_at 
    FROM trade_signals 
    WHERE final_status = 'scheduled' 
    AND scheduled_at <= NOW()
");
$stmt->execute();
$dueTrades = $stmt->fetchAll();

if (empty($dueTrades)) {
    echo "No scheduled trades due.\n";
    exit;
}

echo "Found " . count($dueTrades) . " trades due for execution.\n";

foreach ($dueTrades as $trade) {
    echo "Executing trade #{$trade['id']} ({$trade['ticker']})...\n";

    // Update status to prevent double execution (optimistic lock)
    // We mark it approved right before execution
    $update = $db->prepare("UPDATE trade_signals SET final_status = 'approved' WHERE id = ?");
    $update->execute([$trade['id']]);

    $result = $executor->executeSignal($trade['id']);

    if ($result['success']) {
        echo "✅ Success: {$result['message']}\n";
    } else {
        echo "❌ Failed: {$result['error']}\n";

        // Log failure
        $log = $db->prepare("INSERT INTO decision_logs (ticker, decision_type, decision_outcome, decision_reason, related_signal_id) VALUES (?, 'execution_error', 'failed', ?, ?)");
        $log->execute([$trade['ticker'], "Scheduled execution failed: " . $result['error'], $trade['id']]);
    }
}
echo "Done.\n";
