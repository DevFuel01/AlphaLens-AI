<?php

require_once __DIR__ . '/../api/research/ResearchReplay.php';

// Parse command line arguments
$options = getopt("", ["days::", "limit::"]);
$days = isset($options['days']) ? (int)$options['days'] : 30;
$limit = isset($options['limit']) ? (int)$options['limit'] : 10;

echo "\n🔍 AlphaLens AI Accuracy Evaluator\n";
echo "===================================\n";
echo "Evaluating past $limit signals against $days-day market outcomes...\n\n";

$replay = new ResearchReplay();
$db = Database::getInstance()->getConnection();

// Fetch past signals
$stmt = $db->prepare("SELECT id FROM trade_signals ORDER BY created_at DESC LIMIT ?");
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->execute();
$signalIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

$correctCount = 0;
$totalProcessed = 0;
$confidenceSum = 0;
$returnSum = 0;

echo sprintf("%-10s | %-6s | %-6s | %-12s | %-12s | %s\n", "Ticker", "Type", "Conf%", "Return%", "Outcome", "Result");
echo str_repeat("-", 80) . "\n";

foreach ($signalIds as $id) {
    $result = $replay->evaluateSignal($id, $days);

    if (!$result['success']) {
        echo "Signal #$id: " . $result['error'] . "\n";
        continue;
    }

    $signal = $result['signal'];
    $outcome = $result['outcome'];
    $isCorrect = $result['is_correct'];

    $ticker = $signal['ticker'];
    $type = strtoupper($signal['signal_type']);
    $confidence = $signal['confidence_level'];
    $returnPct = number_format($outcome['return_pct'], 2);
    $resultStr = $isCorrect ? "✅ CORRECT" : "❌ INCORRECT";

    // Colorize output if supported (simple ANSI codes)
    $colorReturn = $outcome['return_pct'] > 0 ? "\033[32m+$returnPct%\033[0m" : "\033[31m$returnPct%\033[0m";

    echo sprintf(
        "%-10s | %-6s | %-6d | %-12s | %-12s | %s\n",
        $ticker,
        $type,
        $confidence,
        $returnPct . '%',
        $returnPct > 0 ? 'Gain' : 'Loss',
        $resultStr
    );

    $totalProcessed++;
    if ($isCorrect) $correctCount++;
}

echo "\n" . str_repeat("=", 40) . "\n";
if ($totalProcessed > 0) {
    $accuracy = number_format(($correctCount / $totalProcessed) * 100, 1);
    echo "📊 Summary Results:\n";
    echo "Total Signals Analyzed: $totalProcessed\n";
    echo "Accuracy (Win Rate):    $accuracy%\n";
    echo "Evaluation Period:      $days Days\n";
} else {
    echo "No signals processed.\n";
}
echo str_repeat("=", 40) . "\n";
