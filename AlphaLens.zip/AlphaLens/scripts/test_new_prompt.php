<?php

require_once __DIR__ . '/../api/ai/sentiment_analyzer.php';
require_once __DIR__ . '/../config/database.php';

// Parse command line arguments
$options = getopt("", ["prompt::", "limit::"]);
$promptName = isset($options['prompt']) ? $options['prompt'] : 'earnings_sentiment_analysis';
$limit = isset($options['limit']) ? (int)$options['limit'] : 5;

echo "\n🧪 AlphaLens AI Prompt Testing Utility\n";
echo "======================================\n";
echo "Testing prompt '$promptName' against last $limit transcripts...\n\n";

$db = Database::getInstance()->getConnection();
$analyzer = new SentimentAnalyzer();

// 1. Fetch recent transcripts
$stmt = $db->prepare("SELECT * FROM earnings_transcripts ORDER BY created_at DESC LIMIT ?");
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->execute();
$transcripts = $stmt->fetchAll();

if (empty($transcripts)) {
    echo "No transcripts found.\n";
    exit;
}

echo sprintf("%-10s | %-10s | %-12s | %-12s | %s\n", "Ticker", "Quarter", "Old Score", "New Score", "Drift");
echo str_repeat("-", 70) . "\n";

foreach ($transcripts as $transcript) {
    // 2. Fetch original analysis for comparison
    $stmt = $db->prepare("SELECT sentiment_score FROM ai_sentiment_analysis WHERE source_id = ? AND source_type = 'earnings' ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$transcript['id']]);
    $oldAnalysis = $stmt->fetch();
    $oldScore = $oldAnalysis ? $oldAnalysis['sentiment_score'] : 'N/A';

    // 3. Run analysis with NEW prompt (Simulated)
    // Note: In a real scenario, we would inject the *new* prompt template here.
    // For this utility, we just re-run the current active prompt to verify consistency.

    // To make this a true "test new prompt" tool, we would add a method to SentimentAnalyzer
    // to accept an override prompt template. For now, this acts as a regression test.

    $result = $analyzer->analyzeEarnings($transcript['id']);

    if (!$result['success']) {
        echo sprintf(
            "%-10s | %-10s | %-12s | %-12s | %s\n",
            $transcript['ticker'],
            $transcript['quarter'],
            $oldScore,
            "ERROR",
            $result['error']
        );
        continue;
    }

    $newScore = $result['analysis']['sentiment_score'];
    $drift = ($oldScore !== 'N/A') ? ($newScore - $oldScore) : 0;

    $driftStr = ($drift > 0 ? "+" : "") . $drift;
    if (abs($drift) > 10) $driftStr = "\033[31m$driftStr\033[0m"; // Highlight large drift

    echo sprintf(
        "%-10s | %-10s | %-12s | %-12s | %s\n",
        $transcript['ticker'],
        $transcript['quarter'],
        $oldScore !== 'N/A' ? $oldScore : '-',
        $newScore,
        $oldScore !== 'N/A' ? $driftStr : '-'
    );
}

echo str_repeat("=", 70) . "\n";
echo "Test Complete.\n";
