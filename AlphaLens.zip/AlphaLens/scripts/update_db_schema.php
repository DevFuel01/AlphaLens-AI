<?php
require_once __DIR__ . '/../config/database.php';
$db = Database::getInstance()->getConnection();

echo "Table: trade_executions\n";
$stmt = $db->query("DESCRIBE trade_executions");
$cols = $stmt->fetchAll(PDO::FETCH_ASSOC);
foreach ($cols as $col) {
    echo "{$col['Field']} - {$col['Type']}\n";
}

// Check for cost_basis_at_trade
$hasCostBasis = false;
foreach ($cols as $col) {
    if ($col['Field'] === 'cost_basis_at_trade') {
        $hasCostBasis = true;
    }
}

if (!$hasCostBasis) {
    echo "Adding column: cost_basis_at_trade\n";
    $db->exec("ALTER TABLE trade_executions ADD COLUMN cost_basis_at_trade DECIMAL(14,4) DEFAULT NULL AFTER entry_price");
}

echo "Done.\n";
