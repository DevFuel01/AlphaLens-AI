<?php

/**
 * Prompt Management Utility
 * List versions and rollback to previous prompts.
 * 
 * Usage:
 * php manage_prompts.php list
 * php manage_prompts.php rollback --id=5
 */

require_once __DIR__ . '/../config/database.php';

$options = getopt("", ["id::"]);
$command = $argv[1] ?? 'help';
$db = Database::getInstance()->getConnection();

echo "\n🛠️ AlphaLens Prompt Manager\n";
echo "============================\n";

switch ($command) {
    case 'list':
        listPrompts($db);
        break;

    case 'rollback':
        $id = $options['id'] ?? null;
        if (!$id) {
            echo "Error: Please specify version ID to rollback to using --id=<ID>\n";
            exit(1);
        }
        rollbackPrompt($db, $id);
        break;

    default:
        echo "Usage:\n";
        echo "  php manage_prompts.php list             List all prompt versions\n";
        echo "  php manage_prompts.php rollback --id=N  Activate version N\n";
        break;
}

function listPrompts($db)
{
    $stmt = $db->query("
        SELECT id, prompt_name, prompt_version, is_active, created_at, LENGTH(prompt_template) as len 
        FROM prompt_versions 
        ORDER BY prompt_name, created_at DESC
    ");
    $prompts = $stmt->fetchAll();

    echo sprintf("%-4s | %-30s | %-10s | %-10s | %-20s | %s\n", "ID", "Name", "Version", "Active", "Created", "Size");
    echo str_repeat("-", 90) . "\n";

    foreach ($prompts as $p) {
        $activeObj = $p['is_active'] ? "✅ YES" : "  -";
        echo sprintf(
            "%-4d | %-30s | %-10s | %-10s | %-20s | %d chars\n",
            $p['id'],
            substr($p['prompt_name'], 0, 30),
            $p['prompt_version'],
            $activeObj,
            $p['created_at'],
            $p['len']
        );
    }
    echo str_repeat("-", 90) . "\n";
}

function rollbackPrompt($db, $id)
{
    // 1. Get the target prompt details
    $stmt = $db->prepare("SELECT prompt_name, prompt_version FROM prompt_versions WHERE id = ?");
    $stmt->execute([$id]);
    $target = $stmt->fetch();

    if (!$target) {
        echo "Error: Prompt version #$id not found.\n";
        return;
    }

    echo "Rolling back '{$target['prompt_name']}' to version '{$target['prompt_version']}'...\n";

    $db->beginTransaction();

    try {
        // 2. Deactivate all versions of this prompt
        $deactivate = $db->prepare("UPDATE prompt_versions SET is_active = FALSE WHERE prompt_name = ?");
        $deactivate->execute([$target['prompt_name']]);

        // 3. Activate the target version
        $activate = $db->prepare("UPDATE prompt_versions SET is_active = TRUE WHERE id = ?");
        $activate->execute([$id]);

        $db->commit();
        echo "✅ Success! Version #$id is now active.\n";
    } catch (Exception $e) {
        $db->rollBack();
        echo "❌ Error: " . $e->getMessage() . "\n";
    }
}
