# AlphaLens AI: Demo Video Script (5 Minutes)

**Target Audience:** Hackathon Judges / Financial Technology Explorers
**Theme:** Moving from "Black Box" AI to "Expert-in-the-Loop" Institutional Trading.

---

## 🕒 0:00 - 0:45 | The Hook: The Problem with Black-Box Trading
**Visuals:** Start with a close-up of the AlphaLens Dashboard showing "Exposure by Sector" or a "Signal Card" with a high sentiment score.

**Narrative:**
"The biggest barrier to AI in high-stakes trading isn't logic—it's **trust**. Most trading bots are 'black boxes'—they tell you to BUY or SELL, but they never tell you **why**. When thousands of dollars are on the line, 'Trust me' isn't a strategy. 

Meet **AlphaLens AI**. 

We didn't just build another trading bot. We built an **Explainable Trading Agent**. AlphaLens uses advanced Large Language Models to read news and earnings like a hedge fund analyst, but it reports its reasoning with 100% transparency."

---

## 🕒 0:45 - 2:00 | The AI Analyst: How Sentiment Becomes Signals
**Visuals:** Switch to the **News & Earnings Feed** (`feed.html`). Scroll through a few NVDIA or Apple headlines. Open a "Signal Detail" view.

**Narrative:**
"The heart of AlphaLens is our **Sentiment Engine**, powered by Google’s Gemini 2.5 Flash. 

Unlike traditional sentiment tools that just look for 'happy' or 'sad' words, AlphaLens performs deep analysis. It ingests thousands of news articles and raw earnings transcripts. It looks for guidance changes, management tone shifts, and analyst divergence.

Every signal generated comes with a **Trade Thesis**. You can see exactly which quotes from a CEO influenced the decision. It converts raw, messy data into structured, actionable intelligence—ranking everything from sentiment scores to AI confidence levels."

---

## 🕒 2:00 - 3:00 | The Risk Guardian: Safety First
**Visuals:** Switch to the **Configuration Page** (`settings.html`). Show the Max Position Size, Max Portfolio Exposure, and the "Trading Mode" toggle.

**Narrative:**
"But intelligence is nothing without discipline. AlphaLens features a multi-layered **Risk Guardian**. 

Before a trade even reaches your screen, it passes through our Rule Validator and Risk Controller. We enforce institutional-grade constraints:
1. **Concentration Limits:** No single stock can overwhelm your portfolio.
2. **Volatility Filters:** The system automatically 'cooldowns' if a stock becomes too erratic.
3. **Circuit Breakers:** If the daily drawdown hits a limit, the system halts.

You can run in **Advisory Mode**, where the AI suggests and you approve, or **Fully Automated**, where the AI executes within the guardrails you’ve set."

---

## 🕒 3:00 - 4:00 | The Execution Layer: Precision & Reliability
**Visuals:** Show the **Trade Approval** flow. Click 'Approve' on a signal. Show the **Pending Orders** table in the dashboard updating in real-time.

**Narrative:**
"Execution is where the rubber meets the road. AlphaLens is deeply integrated with the **Alpaca Trading API**.

We’ve solved the common 'API lag' problems with custom logic:
- **JIT Position Sync:** We verify your account state in milliseconds before every order.
- **Conflict Resolution:** We automatically cancel 'stale' or 'locked' orders to prevent share-insufficiency errors.
- **Bracket Orders:** We place 'Entry, Stop Loss, and Take Profit' all in one atomic move, ensuring your downside is protected the moment you enter a trade."

---

## 🕒 4:00 - 5:00 | Real-Time Insights & Conclusion
**Visuals:** Back to the **Dashboard** (`index.html`). Highlight the Win Rate, the realized P&L, and the Sector Exposure chart showing current positions.

**Narrative:**
"Finally, AlphaLens gives you a bird's-eye view of your success. Our custom analytics track every penny of **Realized P&L** and calculate your win rate in real-time. 

From the 'Audit Trail' where every AI thought is recorded, to the high-level sector breakdown, AlphaLens is built for the professional who demands results they can understand.

This is **AlphaLens AI**. Transparent. Disciplined. Explainable. Because in trading, the best lens is the one that lets you see exactly what's inside the machine. 

Thank you."

---

**[End Screen: "🔍 AlphaLens AI - Explainable Trading Agent"]**
